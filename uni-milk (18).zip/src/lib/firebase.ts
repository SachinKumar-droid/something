import { initializeApp, getApps } from 'firebase/app';
import {
  getFirestore,
  collection,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  onSnapshot,
  query,
  where,
  getDocs,
  serverTimestamp,
  getDocFromServer,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];

export const db = getFirestore(
  app,
  firebaseConfig.firestoreDatabaseId && firebaseConfig.firestoreDatabaseId.trim() !== ''
    ? firebaseConfig.firestoreDatabaseId
    : '(default)'
);

// Test Firestore connection on boot
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firebase connection notice: client is offline or initializing.');
    }
  }
}
testConnection();

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: null,
      email: null,
    },
    operationType,
    path,
  };
  console.error('Firestore Error:', JSON.stringify(errInfo));
  return errInfo;
}

export interface FirestoreOrder {
  id?: string;
  orderNumber: string;
  customerName: string;
  customerPhone: string;
  deliveryAddress: string;
  deliverySlot: string;
  paymentMethod: string;
  status: 'Pending' | 'Accepted (On The Way)' | 'Delivered' | 'Cancelled';
  totalAmount: number;
  items: Array<{
    name: string;
    size: string;
    quantity: number;
    price: number;
  }>;
  createdAt?: any;
  updatedAt?: any;
}

export interface FirestoreSubscription {
  id?: string;
  subscriptionNumber: string;
  customerName: string;
  customerPhone: string;
  deliveryAddress: string;
  deliverySlot: string;
  productName: string;
  variantSize: string;
  dailyQuantity: number;
  planDays: number;
  startDate: string;
  endDate: string;
  totalPrice: number;
  status: 'Pending' | 'Active' | 'Paused' | 'Completed';
  createdAt?: any;
  updatedAt?: any;
}

// Add Order to Firestore
export const saveOrderToFirestore = async (order: Omit<FirestoreOrder, 'id' | 'createdAt' | 'updatedAt'>) => {
  try {
    const ordersCol = collection(db, 'orders');
    const docRef = await addDoc(ordersCol, {
      ...order,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return docRef.id;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'orders');
    return null;
  }
};

// Add Subscription to Firestore
export const saveSubscriptionToFirestore = async (
  sub: Omit<FirestoreSubscription, 'id' | 'createdAt' | 'updatedAt'>
) => {
  try {
    const subsCol = collection(db, 'subscriptions');
    const docRef = await addDoc(subsCol, {
      ...sub,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return docRef.id;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'subscriptions');
    return null;
  }
};

// Update Order Status in Firestore
export const updateOrderStatusInFirestore = async (
  orderId: string,
  status: FirestoreOrder['status']
) => {
  try {
    const orderDoc = doc(db, 'orders', orderId);
    await updateDoc(orderDoc, {
      status,
      updatedAt: serverTimestamp(),
    });
    return true;
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `orders/${orderId}`);
    return false;
  }
};

// Update Subscription Status in Firestore
export const updateSubscriptionStatusInFirestore = async (
  subId: string,
  status: FirestoreSubscription['status']
) => {
  try {
    const subDoc = doc(db, 'subscriptions', subId);
    await updateDoc(subDoc, {
      status,
      updatedAt: serverTimestamp(),
    });
    return true;
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `subscriptions/${subId}`);
    return false;
  }
};

// Delete Order from Firestore (by Doc ID and/or Order Number)
export const deleteOrderFromFirestore = async (orderId?: string, orderNumber?: string) => {
  try {
    const ordersCol = collection(db, 'orders');

    // 1. Delete by document ID if provided
    if (orderId) {
      try {
        const orderDoc = doc(db, 'orders', orderId);
        await deleteDoc(orderDoc);
      } catch (e) {
        handleFirestoreError(e, OperationType.DELETE, `orders/${orderId}`);
      }
    }

    // 2. Also query by orderNumber or targetNum and delete matching docs
    const targetNum = orderNumber || orderId;
    if (targetNum) {
      try {
        const q = query(ordersCol, where('orderNumber', '==', targetNum));
        const querySnap = await getDocs(q);
        const deletePromises: Promise<void>[] = [];
        querySnap.forEach((d) => {
          deletePromises.push(deleteDoc(doc(db, 'orders', d.id)));
        });
        await Promise.all(deletePromises);
      } catch (e) {
        handleFirestoreError(e, OperationType.DELETE, `orders/query/${targetNum}`);
      }
    }
    return true;
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, 'orders');
    return false;
  }
};

// Delete Subscription from Firestore (by Doc ID and/or Subscription Number)
export const deleteSubscriptionFromFirestore = async (subId?: string, subNumber?: string) => {
  try {
    const subsCol = collection(db, 'subscriptions');

    // 1. Delete by document ID if provided
    if (subId) {
      try {
        const subDoc = doc(db, 'subscriptions', subId);
        await deleteDoc(subDoc);
      } catch (e) {
        handleFirestoreError(e, OperationType.DELETE, `subscriptions/${subId}`);
      }
    }

    // 2. Also query by subscriptionNumber / targetNum and delete matching docs
    const targetNum = subNumber || subId;
    if (targetNum) {
      try {
        const q = query(subsCol, where('subscriptionNumber', '==', targetNum));
        const querySnap = await getDocs(q);
        const deletePromises: Promise<void>[] = [];
        querySnap.forEach((d) => {
          deletePromises.push(deleteDoc(doc(db, 'subscriptions', d.id)));
        });
        await Promise.all(deletePromises);
      } catch (e) {
        handleFirestoreError(e, OperationType.DELETE, `subscriptions/query/${targetNum}`);
      }
    }
    return true;
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, 'subscriptions');
    return false;
  }
};

// Helper function to extract numeric timestamp safely
function getTimestampValue(item: any): number {
  if (!item?.createdAt) return 0;
  if (typeof item.createdAt === 'number') return item.createdAt;
  if (item.createdAt?.seconds) return item.createdAt.seconds * 1000;
  if (typeof item.createdAt?.toDate === 'function') return item.createdAt.toDate().getTime();
  if (typeof item.createdAt === 'string') return new Date(item.createdAt).getTime() || 0;
  return 0;
}

// Real-time listener for Orders
export const subscribeToOrders = (callback: (orders: FirestoreOrder[]) => void) => {
  const ordersCol = collection(db, 'orders');

  return onSnapshot(
    ordersCol,
    (snapshot) => {
      const ordersList: FirestoreOrder[] = [];
      snapshot.forEach((docSnap) => {
        ordersList.push({ id: docSnap.id, ...docSnap.data() } as FirestoreOrder);
      });

      // Sort newest first safely
      ordersList.sort((a, b) => getTimestampValue(b) - getTimestampValue(a));
      callback(ordersList);
    },
    (error) => {
      handleFirestoreError(error, OperationType.GET, 'orders');
    }
  );
};

// Real-time listener for Subscriptions
export const subscribeToSubscriptions = (callback: (subs: FirestoreSubscription[]) => void) => {
  const subsCol = collection(db, 'subscriptions');

  return onSnapshot(
    subsCol,
    (snapshot) => {
      const subsList: FirestoreSubscription[] = [];
      snapshot.forEach((docSnap) => {
        subsList.push({ id: docSnap.id, ...docSnap.data() } as FirestoreSubscription);
      });

      // Sort newest first safely
      subsList.sort((a, b) => getTimestampValue(b) - getTimestampValue(a));
      callback(subsList);
    },
    (error) => {
      handleFirestoreError(error, OperationType.GET, 'subscriptions');
    }
  );
};
