import React, { useState, useEffect } from 'react';
import { NamasteHeader } from './components/NamasteHeader';
import { GlassNavbar } from './components/GlassNavbar';
import { NoticeBoard } from './components/NoticeBoard';
import { HeroSection } from './components/HeroSection';
import { ProductCatalog } from './components/ProductCatalog';
import { DirectOrderModal } from './components/DirectOrderModal';
import { CartDrawer } from './components/CartDrawer';
import { AddressModal } from './components/AddressModal';
import { MyOrdersModal } from './components/MyOrdersModal';
import { MyProfileModal } from './components/MyProfileModal';
import { BulkOrderModal } from './components/BulkOrderModal';
import { SubscriptionModal } from './components/SubscriptionModal';
import { ReviewSection } from './components/ReviewSection';
import { ReportIssueSection } from './components/ReportIssueSection';
import { Footer } from './components/Footer';
import { LoadingOverlay } from './components/LoadingOverlay';
import { AuthModal } from './components/AuthModal';
import { AdminPanelModal } from './components/AdminPanelModal';
import { MobileBottomNav } from './components/MobileBottomNav';
import { BlinkitFloatingCartBar } from './components/BlinkitFloatingCartBar';
import { notifyOrderStatusChange } from './utils/notification';
import {
  saveOrderToFirestore,
  subscribeToOrders,
  subscribeToSubscriptions,
  FirestoreOrder,
  FirestoreSubscription,
} from './lib/firebase';
import { Bell, X } from 'lucide-react';

import { PRODUCTS } from './data/products';
import { INITIAL_REVIEWS } from './data/initialReviews';
import { Address, CartItem, Order, OrderStatus, Product, ProductVariant, Review, Subscription, UserProfile } from './types';

const DEFAULT_ADDRESS: Address = {
  fullName: 'Uni Milk Household',
  phone: '9837854627',
  area: 'Kanchan Nagar',
  streetAddress: 'Kanchan Nagar Main St',
  landmark: 'Near Water Tank',
  city: 'Hathras',
  pincode: '204101',
};

const DEFAULT_USER: UserProfile = {
  name: '',
  email: '',
  phone: '',
  isLoggedIn: false,
  authMethod: 'guest',
  address: DEFAULT_ADDRESS,
  subscriptions: [],
};

const DEFAULT_ORDER: Order = {
  id: 'UNI-84920',
  date: new Date().toLocaleDateString('en-IN'),
  items: [
    {
      productId: 'milk-regular',
      productName: 'Fresh Pure Milk (Regular)',
      category: 'milk',
      subCategory: 'regular',
      variant: { id: 'reg-1ltr', size: '1 Ltr', price: 65 },
      quantity: 2,
      image: 'https://raw.githubusercontent.com/SachinKumar-droid/something/main/IMG-20260729-WA0012.jpg',
    },
  ],
  totalAmount: 130,
  deliveryFee: 0,
  grandTotal: 130,
  status: 'Out for Delivery',
  deliveryAddress: DEFAULT_ADDRESS,
  paymentMethod: 'Cash on Delivery',
  deliverySlot: '6:00 AM - 7:00 AM',
  estimatedTime: '6:00 AM - 7:00 AM Today',
  driverName: 'Ramesh Kumar',
  driverPhone: '9837854627',
};

export default function App() {
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [toastNotification, setToastNotification] = useState<{
    title: string;
    body: string;
  } | null>(null);

  // Initial local storage load
  const [user, setUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('unimilk_user');
    return saved ? JSON.parse(saved) : DEFAULT_USER;
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('unimilk_cart');
    return saved ? JSON.parse(saved) : [];
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('unimilk_orders');
    return saved ? JSON.parse(saved) : [DEFAULT_ORDER];
  });

  const [reviews, setReviews] = useState<Review[]>(() => {
    const saved = localStorage.getItem('unimilk_reviews');
    return saved ? JSON.parse(saved) : INITIAL_REVIEWS;
  });

  // Modal Visibility States
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isAddressOpen, setIsAddressOpen] = useState(false);
  const [isOrdersOpen, setIsOrdersOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isBulkOrderOpen, setIsBulkOrderOpen] = useState(false);
  const [isSubscriptionOpen, setIsSubscriptionOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);

  // Firestore Database Real-time States
  const [firestoreOrders, setFirestoreOrders] = useState<FirestoreOrder[]>([]);
  const [firestoreSubs, setFirestoreSubs] = useState<FirestoreSubscription[]>([]);

  // Subscribe to real-time Firestore DB updates
  useEffect(() => {
    const unsubOrders = subscribeToOrders((data) => {
      setFirestoreOrders(data);

      setOrders((prevOrders) => {
        // Build map for quick lookup by order number or id
        const fsMap = new Map<string, FirestoreOrder>();
        data.forEach((fs) => {
          if (fs.orderNumber) fsMap.set(fs.orderNumber, fs);
          if (fs.id) fsMap.set(fs.id, fs);
        });

        // Update status of existing local orders if found in Firestore
        const updatedLocal = prevOrders.map((local) => {
          const matchedFs = fsMap.get(local.id);
          if (matchedFs) {
            let mappedStatus: OrderStatus = 'Order Placed';
            if (matchedFs.status === 'Accepted (On The Way)') mappedStatus = 'Out for Delivery';
            else if (matchedFs.status === 'Delivered') mappedStatus = 'Delivered';
            else if (matchedFs.status === 'Cancelled') mappedStatus = 'Cancelled';
            else if (matchedFs.status === 'Pending') mappedStatus = 'Order Placed';

            return {
              ...local,
              status: mappedStatus,
            };
          }
          return local;
        });

        // Add any Firestore orders that don't exist in local state yet
        const existingLocalIds = new Set(prevOrders.map((o) => o.id));
        const newFsOrders: Order[] = data
          .filter((fs) => !existingLocalIds.has(fs.orderNumber) && (!fs.id || !existingLocalIds.has(fs.id)))
          .map((fs) => {
            let mappedStatus: OrderStatus = 'Order Placed';
            if (fs.status === 'Accepted (On The Way)') mappedStatus = 'Out for Delivery';
            else if (fs.status === 'Delivered') mappedStatus = 'Delivered';
            else if (fs.status === 'Cancelled') mappedStatus = 'Cancelled';

            return {
              id: fs.orderNumber || fs.id || `UNI-${Math.floor(10000 + Math.random() * 90000)}`,
              date: new Date().toLocaleDateString('en-IN'),
              items: (fs.items || []).map((i) => ({
                productId: 'milk-regular',
                productName: i.name,
                category: 'milk',
                subCategory: 'regular',
                variant: { id: 'var-dynamic', size: i.size, price: i.price },
                quantity: i.quantity,
                image: 'https://raw.githubusercontent.com/SachinKumar-droid/something/main/IMG-20260729-WA0012.jpg',
              })),
              totalAmount: fs.totalAmount || 0,
              deliveryFee: 0,
              grandTotal: fs.totalAmount || 0,
              status: mappedStatus,
              deliveryAddress: DEFAULT_ADDRESS,
              paymentMethod: (fs.paymentMethod as any) || 'Cash on Delivery',
              deliverySlot: fs.deliverySlot || 'Morning Delivery',
              estimatedTime: fs.deliverySlot || 'Morning Delivery',
            };
          });

        return [...newFsOrders, ...updatedLocal];
      });
    });

    const unsubSubs = subscribeToSubscriptions((data) => {
      setFirestoreSubs(data);
    });

    return () => {
      unsubOrders();
      unsubSubs();
    };
  }, []);

  // Direct Order Target
  const [directOrderTarget, setDirectOrderTarget] = useState<{
    product: Product;
    variant: ProductVariant;
  } | null>(null);

  // Listen for in-app push notification toast events
  useEffect(() => {
    const handleToastEvent = (e: any) => {
      if (e.detail) {
        setToastNotification({
          title: e.detail.title,
          body: e.detail.body,
        });
      }
    };

    window.addEventListener('uni-milk-toast', handleToastEvent);
    return () => window.removeEventListener('uni-milk-toast', handleToastEvent);
  }, []);

  // Auto-hide toast after 5 seconds
  useEffect(() => {
    if (toastNotification) {
      const timer = setTimeout(() => {
        setToastNotification(null);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [toastNotification]);

  // Page Initial Loading simulation with "100% fresh product" banner
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);
    return () => clearTimeout(timer);
  }, []);

  // Sync state to localStorage
  useEffect(() => {
    localStorage.setItem('unimilk_user', JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem('unimilk_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('unimilk_orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('unimilk_reviews', JSON.stringify(reviews));
  }, [reviews]);

  // Cart Actions
  const handleAddToCart = (product: Product, variant: ProductVariant, quantity = 1) => {
    setCart((prevCart) => {
      const existingIndex = prevCart.findIndex(
        (item) => item.productId === product.id && item.variant.id === variant.id
      );

      if (existingIndex > -1) {
        const updated = [...prevCart];
        updated[existingIndex].quantity += quantity;
        return updated;
      }

      return [
        ...prevCart,
        {
          productId: product.id,
          productName: product.name,
          category: product.category,
          subCategory: product.subCategory,
          variant,
          quantity,
          image: product.image,
        },
      ];
    });

    setToastNotification({
      title: '🛒 Item Added to Cart!',
      body: `${product.name} (${variant.size}) added. Tap Cart at top to view & order.`,
    });
  };

  const handleUpdateCartQuantity = (productId: string, variantId: string, delta: number) => {
    setCart((prevCart) =>
      prevCart
        .map((item) => {
          if (item.productId === productId && item.variant.id === variantId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveCartItem = (productId: string, variantId: string) => {
    const itemToRemove = cart.find((i) => i.productId === productId && i.variant.id === variantId);
    setCart((prevCart) =>
      prevCart.filter((item) => !(item.productId === productId && item.variant.id === variantId))
    );
    if (itemToRemove) {
      setToastNotification({
        title: '🗑️ Item Removed',
        body: `${itemToRemove.productName} (${itemToRemove.variant.size}) cart se hata diya gaya hai.`,
      });
    }
  };

  const handleClearCart = () => {
    setCart([]);
  };

  // Direct Order Trigger
  const handleDirectOrder = (product: Product, variant: ProductVariant) => {
    setDirectOrderTarget({ product, variant });
  };

  // Order Placed Callback
  const handleOrderPlaced = (orderData: {
    items: CartItem[];
    address: Address;
    paymentMethod: 'Cash on Delivery' | 'Online on Delivery';
    deliverySlot?: string;
    customerName: string;
    customerEmail: string;
    customerPhone: string;
  }) => {
    const subtotal = orderData.items.reduce((acc, i) => acc + i.variant.price * i.quantity, 0);
    const baseDeliveryFee = subtotal >= 200 || subtotal === 0 ? 0 : 10;
    
    const slot = orderData.deliverySlot || 'Custom Time (7:00 AM)';
    let nightCharge = 0;
    if (slot.includes('PM')) {
      const match = slot.match(/(\d{1,2}):/);
      if (match) {
        const h = parseInt(match[1], 10);
        if (h >= 9 && h < 12) nightCharge = 30;
      }
    } else if (slot.includes('AM')) {
      const match = slot.match(/(\d{1,2}):/);
      if (match) {
        const h = parseInt(match[1], 10);
        if (h === 12 || h < 5) nightCharge = 30;
      }
    }

    const totalDeliveryFee = baseDeliveryFee + nightCharge;
    const grandTotal = subtotal + totalDeliveryFee;

    const newOrder: Order = {
      id: `UNI-${Math.floor(10000 + Math.random() * 90000)}`,
      date: new Date().toLocaleDateString('en-IN'),
      items: orderData.items,
      totalAmount: subtotal,
      deliveryFee: totalDeliveryFee,
      grandTotal,
      status: 'Order Placed',
      deliveryAddress: orderData.address,
      paymentMethod: orderData.paymentMethod,
      deliverySlot: slot,
      estimatedTime: slot,
    };

    setOrders((prev) => [newOrder, ...prev]);

    // Save order to Firestore Database
    const fullAddress = `${orderData.address.streetAddress || ''}, ${orderData.address.landmark ? orderData.address.landmark + ', ' : ''}${orderData.address.area || ''}, Hathras`;
    saveOrderToFirestore({
      orderNumber: newOrder.id,
      customerName: orderData.customerName || 'Valued Customer',
      customerPhone: orderData.customerPhone || '9837854627',
      deliveryAddress: fullAddress,
      deliverySlot: slot,
      paymentMethod: orderData.paymentMethod,
      status: 'Pending',
      totalAmount: grandTotal,
      items: orderData.items.map((i) => ({
        name: i.productName,
        size: i.variant.size,
        quantity: i.quantity,
        price: i.variant.price,
      })),
    });

    // Clear cart if this was a cart order
    if (!directOrderTarget) {
      setCart([]);
    }

    setDirectOrderTarget(null);
    setIsOrdersOpen(true);
  };

  // Address Save Callback
  const handleSaveAddress = (newAddress: Address) => {
    setUser((prev) => ({
      ...prev,
      address: newAddress,
    }));
  };

  // Subscription Callback
  const handleSubscribe = (newSubscription: Subscription) => {
    setUser((prev) => ({
      ...prev,
      subscriptions: [newSubscription, ...(prev.subscriptions || [])],
    }));
  };

  const handleToggleSubscriptionPause = (subId: string) => {
    setUser((prev) => ({
      ...prev,
      subscriptions: (prev.subscriptions || []).map((sub) => {
        if (sub.id === subId) {
          return {
            ...sub,
            status: sub.status === 'Active' ? 'Paused' : 'Active',
          };
        }
        return sub;
      }),
    }));
  };

  // User Auth Callbacks
  const handleLoginSuccess = (loggedInUser: UserProfile) => {
    setUser(loggedInUser);
    setIsAuthOpen(false);
  };

  const handleLogout = () => {
    setUser(DEFAULT_USER);
    localStorage.removeItem('unimilk_user');
  };

  // Add Review Callback (Keep only latest 3 reviews)
  const handleAddReview = (newRevData: Omit<Review, 'id' | 'date'>) => {
    const newRev: Review = {
      ...newRevData,
      id: `rev-${Date.now()}`,
      date: 'Just now',
    };

    setReviews((prev) => [newRev, ...prev].slice(0, 3));
  };

  const totalCartCount = cart.reduce((acc, item) => acc + item.quantity, 0);
  const activeOrdersCount = orders.filter((o) => o.status !== 'Delivered').length;
  const hasActiveSubscription = (user.subscriptions || []).some((s) => s.status === 'Active');

  return (
    <div className="min-h-screen w-full max-w-full overflow-x-hidden bg-gradient-to-br from-emerald-100/80 via-white to-emerald-50/90 text-slate-900 flex flex-col font-sans antialiased selection:bg-emerald-600 selection:text-white pb-20 md:pb-0">
      
      {/* 100% Fresh Loading Screen */}
      <LoadingOverlay isLoading={isLoading} />

      {/* Floating Push Notification Toast Banner */}
      {toastNotification && (
        <div className="fixed top-20 right-4 z-50 max-w-sm w-[calc(100vw-2rem)] bg-[#2D5A27] text-white p-4 rounded-2xl shadow-2xl border border-white/20 animate-in slide-in-from-top-5 duration-300">
          <div className="flex items-start gap-3">
            <div className="p-2 bg-amber-400 text-emerald-950 rounded-xl shrink-0 mt-0.5">
              <Bell className="w-5 h-5" />
            </div>
            <div className="flex-1 pr-2">
              <h4 className="font-extrabold text-xs sm:text-sm text-white">{toastNotification.title}</h4>
              <p className="text-xs text-emerald-100 mt-1 leading-relaxed">{toastNotification.body}</p>
            </div>
            <button
              onClick={() => setToastNotification(null)}
              className="p-1 hover:bg-white/10 rounded-full text-white/80 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Main Header with Uni Milk, WhatsApp, Phone, Cart, Login & NAMASTE BHARAT */}
      <NamasteHeader
        cartCount={totalCartCount}
        user={user}
        currentAddress={user.address || DEFAULT_ADDRESS}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenProfile={() => setIsProfileOpen(true)}
        onOpenAddress={() => setIsAddressOpen(true)}
        onOpenAuth={() => setIsAuthOpen(true)}
      />

      {/* Glassmorphism Sticky Navigation Bar */}
      <GlassNavbar
        currentAddress={user.address || DEFAULT_ADDRESS}
        user={user}
        activeOrdersCount={activeOrdersCount}
        hasActiveSubscription={hasActiveSubscription}
        onOpenAddress={() => setIsAddressOpen(true)}
        onOpenOrders={() => setIsOrdersOpen(true)}
        onOpenProfile={() => (user.isLoggedIn ? setIsProfileOpen(true) : setIsAuthOpen(true))}
        onOpenBulkOrder={() => setIsBulkOrderOpen(true)}
        onOpenSubscription={() => setIsSubscriptionOpen(true)}
        onOpenAdmin={() => setIsAdminOpen(true)}
        onOpenAuth={() => setIsAuthOpen(true)}
      />

      {/* Notice Board Ticker */}
      <NoticeBoard />

      {/* Hero Section with Badges */}
      <HeroSection
        onExploreProducts={() => {
          const section = document.getElementById('products-section');
          if (section) section.scrollIntoView({ behavior: 'smooth' });
        }}
        onOpenSubscription={() => setIsSubscriptionOpen(true)}
      />

      {/* Main Content Area: Products Catalog */}
      <main className="flex-1">
        <ProductCatalog
          products={PRODUCTS}
          cart={cart}
          onAddToCart={handleAddToCart}
          onUpdateQuantity={handleUpdateCartQuantity}
          onDirectOrder={handleDirectOrder}
        />
      </main>

      {/* Reviews Section (Before Footer) */}
      <ReviewSection reviews={reviews} onAddReview={handleAddReview} />

      {/* Report an Issue Section */}
      <ReportIssueSection />

      {/* Footer */}
      <Footer onOpenAdmin={() => setIsAdminOpen(true)} />

      {/* Mobile Bottom Navigation Bar for Phone Optimization */}
      <MobileBottomNav
        cartCount={totalCartCount}
        activeOrdersCount={activeOrdersCount}
        hasActiveSubscription={hasActiveSubscription}
        user={user}
        onOpenOrders={() => setIsOrdersOpen(true)}
        onOpenSubscription={() => setIsSubscriptionOpen(true)}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenProfile={() => (user.isLoggedIn ? setIsProfileOpen(true) : setIsAuthOpen(true))}
        onOpenAuth={() => setIsAuthOpen(true)}
        onScrollToTop={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
      />

      {/* Blinkit Floating Cart Sticky Bar (Visible when cart has items) */}
      <BlinkitFloatingCartBar
        cartItems={cart}
        onOpenCart={() => setIsCartOpen(true)}
      />

      {/* Modals & Overlays */}

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cart}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onClearCart={handleClearCart}
        onProceedToCheckout={() => {
          setDirectOrderTarget(null);
        }}
      />

      {/* Direct Order Modal (For single product direct order OR cart checkout) */}
      <DirectOrderModal
        isOpen={Boolean(directOrderTarget) || (isCartOpen && cart.length > 0)}
        onClose={() => {
          setDirectOrderTarget(null);
          setIsCartOpen(false);
        }}
        directProduct={directOrderTarget}
        cartItems={cart}
        user={user}
        onOrderPlaced={handleOrderPlaced}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
      />

      {/* Address Updater Modal */}
      <AddressModal
        isOpen={isAddressOpen}
        onClose={() => setIsAddressOpen(false)}
        currentAddress={user.address || DEFAULT_ADDRESS}
        onSaveAddress={handleSaveAddress}
      />

      {/* My Orders Receipts Portal */}
      <MyOrdersModal
        isOpen={isOrdersOpen}
        onClose={() => setIsOrdersOpen(false)}
        orders={orders}
        onReorder={(orderToReorder) => {
          orderToReorder.items.forEach((item) => {
            handleAddToCart(
              {
                id: item.productId,
                name: item.productName,
                category: item.category as any,
                subCategory: item.subCategory as any,
                description: '',
                image: item.image,
                variants: [item.variant],
              },
              item.variant,
              item.quantity
            );
          });
          setIsOrdersOpen(false);
          setIsCartOpen(true);
        }}
      />

      {/* My Profile Modal */}
      <MyProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        user={user}
        onLogout={handleLogout}
        onOpenSubscription={() => setIsSubscriptionOpen(true)}
        onOpenOrders={() => setIsOrdersOpen(true)}
        onToggleSubscriptionPause={handleToggleSubscriptionPause}
        onUpdateUserAddress={handleSaveAddress}
      />

      {/* Bulk Order Modal */}
      <BulkOrderModal
        isOpen={isBulkOrderOpen}
        onClose={() => setIsBulkOrderOpen(false)}
      />

      {/* Subscription Portal Modal */}
      <SubscriptionModal
        isOpen={isSubscriptionOpen}
        onClose={() => setIsSubscriptionOpen(false)}
        products={PRODUCTS}
        user={user}
        onSubscribe={handleSubscribe}
      />

      {/* Login / Auth Modal */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onLoginSuccess={handleLoginSuccess}
      />

      {/* Store Admin & Manager Panel Modal */}
      <AdminPanelModal
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        orders={firestoreOrders}
        subscriptions={firestoreSubs}
        onDeleteOrder={(orderId, orderNum) => {
          setOrders((prev) => prev.filter((o) => o.id !== orderId && o.id !== orderNum));
          setFirestoreOrders((prev) => prev.filter((o) => o.id !== orderId && o.orderNumber !== orderNum));
        }}
        onDeleteSubscription={(subId, subNum) => {
          setFirestoreSubs((prev) => prev.filter((s) => s.id !== subId && s.subscriptionNumber !== subNum));
        }}
      />

    </div>
  );
}
