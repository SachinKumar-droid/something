import React from 'react';
import { X, Trash2, Plus, Minus, ShoppingBag, ArrowLeft, Share2, ArrowRight, ShieldCheck, Clock, Sparkles } from 'lucide-react';
import { CartItem } from '../types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (productId: string, variantId: string, delta: number) => void;
  onRemoveItem: (productId: string, variantId: string) => void;
  onClearCart: () => void;
  onProceedToCheckout: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onProceedToCheckout,
}) => {
  if (!isOpen) return null;

  const totalItemCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);
  const subtotal = cartItems.reduce((acc, item) => acc + item.variant.price * item.quantity, 0);
  const totalSavings = Math.round(subtotal * 0.12) || (subtotal > 0 ? 15 : 0);
  const freeDeliveryThreshold = 200;
  const amountNeededForFreeDelivery = Math.max(0, freeDeliveryThreshold - subtotal);
  const deliveryFee = subtotal >= freeDeliveryThreshold || subtotal === 0 ? 0 : 10;
  const grandTotal = subtotal + deliveryFee;

  const handleShareCart = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Uni Milk - My Fresh Cart',
          text: `Check out my fresh milk cart from Uni Milk Hathras! Total: ₹${grandTotal}`,
          url: window.location.href,
        });
      } catch {
        // Fallback or ignore
      }
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert('Cart link copied to clipboard!');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-slate-950/70 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-6 sm:pl-10">
        <div className="w-screen max-w-md bg-[#f4f6fb] shadow-2xl flex flex-col justify-between">
          
          {/* Header - Blinkit Style (My Cart with Back Arrow & Share) */}
          <div className="p-4 sm:p-5 bg-white text-slate-900 flex items-center justify-between border-b border-slate-200/80 shadow-2xs">
            <div className="flex items-center gap-3">
              <button
                onClick={onClose}
                className="p-1.5 rounded-full hover:bg-slate-100 text-slate-700 transition-all cursor-pointer"
                title="Go Back"
              >
                <ArrowLeft className="w-5 h-5 stroke-[2.5]" />
              </button>
              <div>
                <h3 className="font-extrabold text-lg text-slate-900 leading-tight">My Cart</h3>
                <p className="text-[11px] font-semibold text-emerald-700">{totalItemCount} {totalItemCount === 1 ? 'item' : 'items'} in cart</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleShareCart}
                className="flex items-center gap-1 text-emerald-700 hover:text-emerald-800 font-extrabold text-xs bg-emerald-50 hover:bg-emerald-100 px-3 py-1.5 rounded-xl border border-emerald-200/80 transition-all cursor-pointer"
                title="Share Cart"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>Share</span>
              </button>
              <button
                onClick={onClose}
                className="p-1.5 rounded-full hover:bg-slate-100 text-slate-500 hover:text-slate-800 transition-all cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Body Section */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-3.5">
            {cartItems.length === 0 ? (
              <div className="py-20 text-center space-y-4">
                <div className="w-20 h-20 rounded-full bg-emerald-100/70 flex items-center justify-center mx-auto text-emerald-600">
                  <ShoppingBag className="w-10 h-10" />
                </div>
                <h4 className="font-extrabold text-slate-800 text-xl">Your cart is empty</h4>
                <p className="text-slate-500 text-xs max-w-xs mx-auto">
                  Add fresh milk, dahi, paneer, chhach, or desi ghee to get started!
                </p>
                <button
                  onClick={() => {
                    onClose();
                    const el = document.getElementById('products-section');
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="mt-2 px-6 py-3 bg-[#0c831f] hover:bg-[#0a721a] text-white font-extrabold text-xs rounded-2xl shadow-md transition-all cursor-pointer inline-flex items-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  <span>Explore Fresh Products</span>
                </button>
              </div>
            ) : (
              <>
                {/* 1. Blinkit Savings Banner */}
                {totalSavings > 0 && (
                  <div className="bg-[#e8f1ff] text-[#1e40af] rounded-2xl p-3.5 px-4 flex items-center justify-between border border-blue-100 shadow-2xs">
                    <span className="font-extrabold text-xs sm:text-sm text-[#2563eb]">Your total savings</span>
                    <span className="font-black text-sm sm:text-base text-[#1d4ed8]">₹{totalSavings}</span>
                  </div>
                )}

                {/* 2. Blinkit Fast Delivery Badge */}
                <div className="bg-white rounded-2xl border border-slate-200/80 p-3.5 flex items-center gap-3.5 shadow-2xs">
                  <div className="w-11 h-11 rounded-2xl bg-slate-100 flex items-center justify-center text-slate-800 shrink-0 border border-slate-200/60">
                    <Clock className="w-5 h-5 text-slate-700" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-slate-900 text-sm leading-tight">Delivery in 8 minutes</h4>
                    <p className="text-xs font-semibold text-slate-500 mt-0.5">
                      Shipment of {totalItemCount} {totalItemCount === 1 ? 'item' : 'items'}
                    </p>
                  </div>
                </div>

                {/* Free Delivery Threshold Bar */}
                <div className="bg-emerald-50/80 px-4 py-2.5 rounded-xl border border-emerald-100 text-xs">
                  {amountNeededForFreeDelivery > 0 ? (
                    <p className="text-slate-700 font-medium">
                      Add <strong className="text-emerald-800 font-bold">₹{amountNeededForFreeDelivery}</strong> more for <strong className="text-emerald-800 font-bold">FREE Delivery</strong>
                    </p>
                  ) : (
                    <p className="text-emerald-800 font-bold flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                      <span>You unlocked FREE Delivery in Hathras!</span>
                    </p>
                  )}
                  <div className="w-full bg-slate-200/80 h-1.5 rounded-full mt-1.5 overflow-hidden">
                    <div
                      className="bg-[#0c831f] h-full transition-all duration-300 rounded-full"
                      style={{ width: `${Math.min(100, (subtotal / freeDeliveryThreshold) * 100)}%` }}
                    />
                  </div>
                </div>

                {/* Clear All Option if > 1 items */}
                {cartItems.length > 1 && (
                  <div className="flex items-center justify-between pt-1 text-xs px-1">
                    <span className="font-bold text-slate-600">{cartItems.length} Product Types</span>
                    <button
                      onClick={() => {
                        if (window.confirm('Kya aap Cart ke sabhi items ko ek sath hatana chahte hain?')) {
                          onClearCart();
                        }
                      }}
                      className="text-rose-600 hover:text-rose-700 font-bold text-xs flex items-center gap-1 bg-rose-50 hover:bg-rose-100 px-2.5 py-1 rounded-lg border border-rose-200 transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Clear All</span>
                    </button>
                  </div>
                )}

                {/* Cart Items List - Exact Blinkit Card Layout */}
                <div className="space-y-3">
                  {cartItems.map((item) => {
                    const mrp = Math.round(item.variant.price * 1.12);
                    return (
                      <div
                        key={`${item.productId}-${item.variant.id}`}
                        className="bg-white rounded-2xl border border-slate-200/80 p-3.5 flex items-center justify-between shadow-2xs hover:border-emerald-300 transition-all relative group"
                      >
                        {/* Top Right Quick Remove 'X' Badge */}
                        <button
                          onClick={() => onRemoveItem(item.productId, item.variant.id)}
                          className="absolute -top-2 -right-2 w-6 h-6 bg-rose-600 hover:bg-rose-700 active:scale-90 text-white rounded-full flex items-center justify-center shadow-md transition-all cursor-pointer z-10 border-2 border-white"
                          title="Remove item"
                        >
                          <X className="w-3.5 h-3.5 stroke-[2.5]" />
                        </button>

                        {/* Left: Product Image & Details */}
                        <div className="flex items-center gap-3">
                          <div className="w-16 h-16 rounded-xl border border-slate-200/80 bg-white p-1 flex items-center justify-center overflow-hidden shrink-0">
                            <img
                              src={item.image}
                              alt={item.productName}
                              className="w-full h-full object-cover rounded-lg"
                            />
                          </div>
                          <div>
                            <h4 className="font-extrabold text-slate-900 text-sm leading-tight max-w-[180px] sm:max-w-[200px] truncate">
                              {item.productName}
                            </h4>
                            <p className="text-xs font-semibold text-slate-500 mt-0.5">
                              {item.variant.size}
                            </p>
                            <div className="flex items-center gap-1.5 mt-1">
                              <span className="font-black text-slate-900 text-sm">
                                ₹{item.variant.price}
                              </span>
                              {mrp > item.variant.price && (
                                <span className="text-xs text-slate-400 line-through font-medium">
                                  ₹{mrp}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Right: Blinkit Solid Green - QTY + Stepper */}
                        <div className="flex flex-col items-end gap-1.5">
                          <div className="flex items-center bg-[#0c831f] text-white rounded-xl shadow-xs p-0.5 font-black border border-emerald-800">
                            <button
                              onClick={() => {
                                if (item.quantity <= 1) {
                                  onRemoveItem(item.productId, item.variant.id);
                                } else {
                                  onUpdateQuantity(item.productId, item.variant.id, -1);
                                }
                              }}
                              className="w-7 h-7 flex items-center justify-center hover:bg-black/15 active:scale-90 rounded-lg transition-all cursor-pointer text-white"
                              title={item.quantity <= 1 ? "Remove Item" : "Decrease Quantity"}
                            >
                              <Minus className="w-4 h-4 stroke-[3]" />
                            </button>

                            <span className="px-2.5 font-extrabold text-xs sm:text-sm text-white min-w-[20px] text-center">
                              {item.quantity}
                            </span>

                            <button
                              onClick={() => onUpdateQuantity(item.productId, item.variant.id, 1)}
                              className="w-7 h-7 flex items-center justify-center hover:bg-black/15 active:scale-90 rounded-lg transition-all cursor-pointer text-white"
                              title="Increase Quantity"
                            >
                              <Plus className="w-4 h-4 stroke-[3]" />
                            </button>
                          </div>

                          <span className="text-[11px] font-bold text-slate-600">
                            Sub: ₹{item.variant.price * item.quantity}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Add More Items Button */}
                <div className="pt-2">
                  <button
                    onClick={() => {
                      onClose();
                      const el = document.getElementById('products-section');
                      if (el) el.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="w-full py-3 bg-white hover:bg-emerald-50 text-emerald-800 font-extrabold text-xs rounded-2xl border-2 border-dashed border-emerald-300 flex items-center justify-center gap-2 transition-all cursor-pointer shadow-2xs"
                  >
                    <Plus className="w-4 h-4 text-emerald-600 stroke-[3]" />
                    <span>+ Add More Items (Aur Samaan Jodein)</span>
                  </button>
                </div>
              </>
            )}
          </div>

          {/* Footer Checkout Bar */}
          {cartItems.length > 0 && (
            <div className="p-4 sm:p-5 bg-white border-t border-slate-200/90 shadow-lg space-y-3">
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between text-slate-600 font-medium">
                  <span>Subtotal</span>
                  <span className="font-bold text-slate-800">₹{subtotal}</span>
                </div>
                {totalSavings > 0 && (
                  <div className="flex justify-between text-blue-700 font-bold">
                    <span>Discount / Savings</span>
                    <span>-₹{totalSavings}</span>
                  </div>
                )}
                <div className="flex justify-between text-slate-600 font-medium">
                  <span>Delivery Fee (Hathras)</span>
                  <span className={deliveryFee === 0 ? 'text-emerald-700 font-bold' : 'font-bold text-slate-800'}>
                    {deliveryFee === 0 ? 'FREE' : `₹${deliveryFee}`}
                  </span>
                </div>
                <div className="flex justify-between text-base font-black text-slate-900 pt-2 border-t border-slate-100">
                  <span>Grand Total</span>
                  <span className="text-[#0c831f] text-xl">₹{grandTotal}</span>
                </div>
              </div>

              <button
                onClick={() => {
                  onClose();
                  onProceedToCheckout();
                }}
                className="w-full py-3.5 bg-[#0c831f] hover:bg-[#0a721a] text-white font-extrabold text-sm rounded-2xl shadow-lg shadow-emerald-800/20 flex items-center justify-center gap-2 transition-all cursor-pointer active:scale-98"
              >
                <span>Proceed to Order • ₹{grandTotal}</span>
                <ArrowRight className="w-4 h-4 stroke-[3]" />
              </button>

              <div className="flex items-center justify-between text-[11px] text-slate-400">
                <button
                  onClick={onClearCart}
                  className="hover:text-rose-600 underline cursor-pointer"
                >
                  Clear Cart
                </button>
                <span className="flex items-center gap-1 text-slate-500 font-medium">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  100% Fresh & Pure Guarantee
                </span>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};

