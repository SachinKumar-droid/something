import React, { useState, useEffect, useRef } from 'react';
import { ShoppingBag, ArrowRight, Clock } from 'lucide-react';
import { CartItem } from '../types';

interface BlinkitFloatingCartBarProps {
  cartItems: CartItem[];
  onOpenCart: () => void;
}

export const BlinkitFloatingCartBar: React.FC<BlinkitFloatingCartBarProps> = ({
  cartItems,
  onOpenCart,
}) => {
  const [isPopping, setIsPopping] = useState(false);
  const totalItems = cartItems.reduce((acc, item) => acc + item.quantity, 0);
  const totalPrice = cartItems.reduce((acc, item) => acc + item.variant.price * item.quantity, 0);
  const prevCountRef = useRef(totalItems);

  useEffect(() => {
    if (prevCountRef.current !== totalItems && totalItems > 0) {
      setIsPopping(true);
      const timer = setTimeout(() => setIsPopping(false), 450);
      prevCountRef.current = totalItems;
      return () => clearTimeout(timer);
    }
  }, [totalItems]);

  if (totalItems === 0) return null;

  return (
    <div className="fixed bottom-16 md:bottom-6 left-0 right-0 z-40 px-3 max-w-lg mx-auto pointer-events-none transition-all">
      <div
        onClick={onOpenCart}
        className={`pointer-events-auto bg-[#0c831f] hover:bg-[#0a721a] text-white p-3 sm:p-3.5 rounded-2xl shadow-2xl border border-emerald-400/30 flex items-center justify-between cursor-pointer transition-all duration-300 transform active:scale-98 ${
          isPopping ? 'scale-105 ring-4 ring-amber-300 shadow-emerald-900/40 -translate-y-1' : 'scale-100'
        }`}
      >
        {/* Left: Cart Info */}
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center border border-white/30">
              <ShoppingBag className={`w-5 h-5 text-white transition-transform duration-300 ${isPopping ? 'scale-125 rotate-[-12deg]' : ''}`} />
            </div>
            {totalItems > 0 && (
              <span className="absolute -top-1.5 -right-1.5 bg-amber-400 text-emerald-950 font-black text-[10px] w-4 h-4 rounded-full flex items-center justify-center shadow-xs border border-white">
                {totalItems}
              </span>
            )}
          </div>

          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-sm sm:text-base leading-none">
                {totalItems} {totalItems === 1 ? 'Item' : 'Items'} • ₹{totalPrice}
              </span>
            </div>
            <div className="flex items-center gap-1 text-[11px] text-emerald-100 font-medium mt-1">
              <Clock className="w-3 h-3 text-amber-300 animate-pulse" />
              <span>Delivery in 8 mins • Hathras</span>
            </div>
          </div>
        </div>

        {/* Right: View Cart Button */}
        <div className="flex items-center gap-1.5 bg-white/20 hover:bg-white/30 px-3.5 py-2 rounded-xl text-white font-extrabold text-xs sm:text-sm border border-white/20 backdrop-blur-xs transition-all">
          <span>View Cart</span>
          <ArrowRight className="w-4 h-4" />
        </div>
      </div>
    </div>
  );
};
