import React from 'react';
import { ShoppingBag, User, Phone, MessageSquare, MapPin, Sparkles } from 'lucide-react';
import { Address, UserProfile } from '../types';

interface NamasteHeaderProps {
  cartCount: number;
  user: UserProfile;
  currentAddress: Address;
  onOpenCart: () => void;
  onOpenProfile: () => void;
  onOpenAddress: () => void;
  onOpenAuth: () => void;
}

export const NamasteHeader: React.FC<NamasteHeaderProps> = ({
  cartCount,
  user,
  currentAddress,
  onOpenCart,
  onOpenProfile,
  onOpenAddress,
  onOpenAuth,
}) => {
  return (
    <header className="w-full bg-[#2D5A27] text-white shadow-lg relative z-30 border-b border-emerald-800/40">
      {/* 🇮🇳 NAMASTE BHARAT Banner (Frosted Glass #2D5A27 theme style) */}
      <div className="w-full bg-[#2D5A27] py-2.5 px-4 text-center font-black tracking-tighter text-white shadow-inner flex items-center justify-center gap-2 sm:gap-4 text-lg sm:text-2xl md:text-3xl italic border-b border-white/10">
        <span className="text-xl sm:text-2xl not-italic">🇮🇳</span>
        <span className="drop-shadow-md text-white tracking-tight uppercase font-serif">
          NAMASTE BHARAT
        </span>
        <span className="text-xl sm:text-2xl not-italic">🇮🇳</span>
      </div>

      {/* Main Header Bar */}
      <div className="max-w-7xl mx-auto px-4 py-3 sm:py-3.5">
        <div className="flex items-center justify-between gap-3">
          
          {/* Logo & Brand Info */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
            {/* Circular Logo Emblem */}
            <div className="w-12 h-12 rounded-full bg-white p-1 border-2 border-amber-300 shadow-md hover:scale-105 transition-transform shrink-0 overflow-hidden flex items-center justify-center">
              <img
                src="/icon.svg"
                alt="Uni Milk Official Logo"
                className="w-full h-full object-contain"
                referrerPolicy="no-referrer"
              />
            </div>

            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-2xl font-black text-white tracking-tight font-serif">
                  Uni <span className="text-amber-300">Milk</span>
                </span>
                <span className="bg-amber-400/20 border border-amber-300/40 text-amber-300 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider flex items-center gap-1 backdrop-blur-sm">
                  <Sparkles className="w-2.5 h-2.5 text-amber-300" />
                  100% Pure
                </span>
              </div>
              <p className="text-xs text-emerald-100/90 flex items-center gap-1">
                <span>Fresh Dairy Delivery • Hathras</span>
              </p>
            </div>
          </div>

          {/* Quick Call & WhatsApp on Mobile */}
          <div className="flex items-center gap-2 md:hidden">
            <a
              href="https://wa.me/919837854627?text=Hello%20Uni%20Milk!%20I%20want%20to%20place%20an%20order."
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 bg-white/10 border border-white/20 text-emerald-300 rounded-xl flex items-center justify-center"
              title="WhatsApp"
            >
              <MessageSquare className="w-4 h-4 text-emerald-300" />
            </a>
            <a
              href="tel:9837854627"
              className="p-2 bg-amber-400 text-emerald-950 rounded-xl font-bold flex items-center justify-center shadow-xs"
              title="Call Us"
            >
              <Phone className="w-4 h-4" />
            </a>
          </div>

          {/* Desktop Right Action Controls */}
          <div className="hidden md:flex items-center gap-3">
            {/* Quick WhatsApp Link */}
            <a
              href="https://wa.me/919837854627?text=Hello%20Uni%20Milk!%20I%20want%20to%20place%20an%20order."
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-3.5 py-2 bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/25 text-emerald-100 rounded-2xl text-xs font-semibold transition-all"
              title="WhatsApp Order"
            >
              <MessageSquare className="w-4 h-4 text-emerald-300" />
              <span>WhatsApp</span>
            </a>

            {/* Quick Call Link */}
            <a
              href="tel:9837854627"
              className="flex items-center gap-1.5 px-3.5 py-2 bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/25 text-white rounded-2xl text-xs font-semibold transition-all"
              title="Order on Call"
            >
              <Phone className="w-4 h-4 text-amber-300" />
              <span>9837854627</span>
            </a>

            {/* Cart Button (Desktop only) */}
            <button
              onClick={onOpenCart}
              className="relative px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-2xl shadow-md border border-white/30 font-bold text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Cart</span>
              {cartCount > 0 ? (
                <span className="bg-amber-400 text-emerald-950 font-extrabold text-xs px-2 py-0.5 rounded-full shadow-sm">
                  {cartCount}
                </span>
              ) : (
                <span className="text-emerald-200 text-xs">(0)</span>
              )}
            </button>

            {/* Profile / Auth Button */}
            {user.isLoggedIn ? (
              <button
                onClick={onOpenProfile}
                className="flex items-center gap-2 px-3 py-2 bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/25 rounded-2xl text-xs text-white font-medium transition-all"
              >
                <div className="w-6 h-6 rounded-full bg-amber-400 text-emerald-950 flex items-center justify-center font-black text-xs uppercase">
                  {user.name ? user.name.charAt(0) : 'U'}
                </div>
                <span className="max-w-[100px] truncate">{user.name.split(' ')[0]}</span>
              </button>
            ) : (
              <button
                onClick={onOpenAuth}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-amber-400 hover:bg-amber-300 text-emerald-950 rounded-2xl text-xs font-black transition-all shadow-md"
              >
                <User className="w-4 h-4" />
                <span>Login</span>
              </button>
            )}
          </div>

        </div>
      </div>
    </header>
  );
};
