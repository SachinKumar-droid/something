import React from 'react';
import { ShieldCheck, Truck, Percent, Award, Milk, ChevronRight, Phone, MessageSquare } from 'lucide-react';

interface HeroSectionProps {
  onExploreProducts: () => void;
  onOpenSubscription: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onExploreProducts, onOpenSubscription }) => {
  return (
    <section className="relative w-full overflow-hidden bg-gradient-to-b from-[#2D5A27] via-emerald-900 to-emerald-950 text-white py-10 sm:py-16 border-b border-emerald-800/40">
      
      {/* Background Decorative Gradient Orbs */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-emerald-400/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-10 right-10 w-72 h-72 bg-amber-400/15 rounded-full blur-2xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 relative z-10 text-center">
        
        {/* Free Delivery Banner */}
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/15 backdrop-blur-md border border-white/30 text-white text-xs sm:text-sm font-bold mb-6 shadow-md hover:bg-white/20 transition-all">
          <Truck className="w-4 h-4 text-amber-300 animate-pulse" />
          <span>🚚 Free Delivery on Orders Above <strong className="text-amber-300">₹200</strong> in Hathras</span>
        </div>

        {/* Hero Circular Official Logo */}
        <div className="flex justify-center mb-4">
          <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-full bg-white p-1.5 border-4 border-amber-300 shadow-xl overflow-hidden hover:scale-105 transition-transform flex items-center justify-center">
            <img
              src="/icon.svg"
              alt="Uni Milk Official Logo"
              className="w-full h-full object-contain"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>

        {/* Hero Title */}
        <h1 className="text-4xl sm:text-5xl md:text-6xl font-black font-serif tracking-tight text-white mb-4 drop-shadow-md">
          <span className="text-white">
            Uni <span className="text-amber-300">Milk</span>
          </span>
        </h1>

        <p className="max-w-2xl mx-auto text-base sm:text-xl text-emerald-100 font-medium mb-8 leading-relaxed">
          Farm Fresh Milk & Dairy Products Delivered Daily to Your Doorstep in Hathras
        </p>

        {/* Action CTA Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-4 mb-12">
          <button
            onClick={onExploreProducts}
            className="px-6 py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-sm sm:text-base rounded-2xl shadow-lg border border-white/30 flex items-center gap-2 transform hover:-translate-y-0.5 transition-all cursor-pointer"
          >
            <Milk className="w-5 h-5 text-amber-300" />
            <span>Order Fresh Dairy Now</span>
            <ChevronRight className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenSubscription}
            className="px-6 py-3.5 bg-white/20 hover:bg-white/30 backdrop-blur-md border border-white/40 text-white font-extrabold text-sm sm:text-base rounded-2xl shadow-md flex items-center gap-2 transition-all cursor-pointer"
          >
            <span>Start Daily Subscription</span>
          </button>
        </div>

        {/* 4 Feature Badges Grid (Frosted Glass Cards) */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 max-w-4xl mx-auto">
          
          {/* Card 1: 100% Pure */}
          <div className="bg-white/60 backdrop-blur-sm border border-white/80 rounded-2xl p-4 sm:p-5 flex flex-col items-center text-center shadow-sm hover:bg-white/80 transition-all group">
            <div className="w-12 h-12 rounded-2xl bg-emerald-600/20 text-emerald-900 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
              <Milk className="w-6 h-6 text-emerald-800" />
            </div>
            <span className="font-extrabold text-sm sm:text-base text-slate-900">100% Pure</span>
            <span className="text-[11px] text-slate-700 font-semibold mt-0.5">Direct from Farm</span>
          </div>

          {/* Card 2: Daily Delivery */}
          <div className="bg-white/60 backdrop-blur-sm border border-white/80 rounded-2xl p-4 sm:p-5 flex flex-col items-center text-center shadow-sm hover:bg-white/80 transition-all group">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-900 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
              <Truck className="w-6 h-6 text-amber-800" />
            </div>
            <span className="font-extrabold text-sm sm:text-base text-slate-900">Daily Delivery</span>
            <span className="text-[11px] text-slate-700 font-semibold mt-0.5">6:00 AM Doorstep</span>
          </div>

          {/* Card 3: Best Prices */}
          <div className="bg-white/60 backdrop-blur-sm border border-white/80 rounded-2xl p-4 sm:p-5 flex flex-col items-center text-center shadow-sm hover:bg-white/80 transition-all group">
            <div className="w-12 h-12 rounded-2xl bg-yellow-500/20 text-yellow-900 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
              <Percent className="w-6 h-6 text-yellow-800" />
            </div>
            <span className="font-extrabold text-sm sm:text-base text-slate-900">Best Prices</span>
            <span className="text-[11px] text-slate-700 font-semibold mt-0.5">Affordable Every Day</span>
          </div>

          {/* Card 4: Quality Assured */}
          <div className="bg-white/60 backdrop-blur-sm border border-white/80 rounded-2xl p-4 sm:p-5 flex flex-col items-center text-center shadow-sm hover:bg-white/80 transition-all group">
            <div className="w-12 h-12 rounded-2xl bg-teal-500/20 text-teal-900 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
              <Award className="w-6 h-6 text-teal-800" />
            </div>
            <span className="font-extrabold text-sm sm:text-base text-slate-900">Quality Assured</span>
            <span className="text-[11px] text-slate-700 font-semibold mt-0.5">Hygienic Sealed</span>
          </div>

        </div>

      </div>
    </section>
  );
};
