import React from 'react';
import { Milk, Sparkles } from 'lucide-react';

interface LoadingOverlayProps {
  isLoading: boolean;
}

export const LoadingOverlay: React.FC<LoadingOverlayProps> = ({ isLoading }) => {
  if (!isLoading) return null;

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-slate-950 text-white transition-opacity">
      <div className="relative flex flex-col items-center space-y-4 text-center px-4">
        
        {/* Animated Milk Emblem */}
        <div className="relative">
          <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-amber-400 via-emerald-400 to-amber-300 p-1 shadow-2xl shadow-emerald-500/40 animate-pulse">
            <div className="w-full h-full bg-white rounded-full p-2 flex items-center justify-center overflow-hidden">
              <img
                src="/icon.svg"
                alt="Uni Milk Logo"
                className="w-full h-full object-contain"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
          <Sparkles className="w-6 h-6 text-amber-300 absolute -top-1 -right-1 animate-bounce" />
        </div>

        <div>
          <h2 className="text-2xl font-black tracking-wider text-white font-serif uppercase">
            Uni <span className="text-emerald-400">Milk</span>
          </h2>
          
          {/* EXACT REQUIRED LOADING MESSAGE: "100% fresh product" */}
          <div className="mt-3 inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 font-bold text-sm tracking-wide shadow-lg">
            <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
            <span>100% fresh product</span>
          </div>
        </div>

        <p className="text-slate-400 text-xs animate-pulse max-w-xs">
          Loading pure farm-fresh dairy catalog for Hathras...
        </p>

      </div>
    </div>
  );
};
