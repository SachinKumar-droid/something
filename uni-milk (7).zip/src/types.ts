export type MilkCategory = 'regular' | 'premium';

export interface ProductVariant {
  id: string;
  size: string; // e.g., "1 Ltr", "500 ml", "250 ml", "1 kg", "100 gm"
  price: number;
}

export interface Product {
  id: string;
  name: string;
  category: 'milk' | 'dahi' | 'paneer' | 'chhach' | 'ghee';
  subCategory?: MilkCategory | 'plain' | 'masala' | 'family';
  description: string;
  image: string;
  badge?: string;
  variants: ProductVariant[];
}

export interface CartItem {
  productId: string;
  productName: string;
  category: string;
  subCategory?: string;
  variant: ProductVariant;
  quantity: number;
  image: string;
}

export interface Address {
  fullName: string;
  phone: string;
  area: string; // e.g., "Kanchan Nagar", "Sasni Gate", "Mendu Road", "City Center"
  streetAddress: string;
  landmark: string;
  city: string; // Default: Hathras
  pincode: string;
}

export type OrderStatus = 'Order Placed' | 'Quality Checked & Packed' | 'Out for Delivery' | 'Delivered';

export interface Order {
  id: string;
  date: string;
  items: CartItem[];
  totalAmount: number;
  deliveryFee: number;
  grandTotal: number;
  status: OrderStatus;
  deliveryAddress: Address;
  paymentMethod: 'Cash on Delivery' | 'Online on Delivery';
  deliverySlot: string; // e.g., '6:00 AM - 7:00 AM', '7:00 AM - 8:00 AM', '8:00 AM - 9:00 AM'
  estimatedTime: string;
  driverName?: string;
  driverPhone?: string;
}

export interface Subscription {
  id: string;
  productName: string;
  variantSize: string;
  pricePerUnit: number;
  dailyQuantity: number;
  planDurationDays: 5 | 6 | 7 | 30;
  startDate: string;
  endDate: string;
  deliverySlot: 'Morning (6:00 AM - 7:30 AM)' | 'Evening (5:00 PM - 6:30 PM)';
  status: 'Active' | 'Paused' | 'Completed';
  totalPrice: number;
}

export interface UserProfile {
  name: string;
  email: string;
  phone: string;
  isLoggedIn: boolean;
  authMethod: 'email' | 'google' | 'guest';
  address: Address;
  subscriptions: Subscription[];
}

export interface Review {
  id: string;
  name: string;
  rating: number; // 1 to 5
  comment: string;
  date: string;
  location: string;
}
