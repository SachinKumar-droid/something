/**
 * UNI MILK OFFICIAL LOGO CONFIGURATION
 * 
 * To use your logo from GitHub:
 * Set GITHUB_LOGO_URL below to your raw GitHub image link.
 * Example: 'https://raw.githubusercontent.com/username/repository/main/logo.png'
 */
export const GITHUB_LOGO_URL = 'https://raw.githubusercontent.com/SachinKumar-droid/something/main/IMG-20260729-WA0017.jpg';

export const DEFAULT_LOGO_URL = '/icon.svg';

export const UNI_MILK_LOGO_URL = GITHUB_LOGO_URL.trim() !== '' ? GITHUB_LOGO_URL : DEFAULT_LOGO_URL;
