import { Review } from '../types';

export const INITIAL_REVIEWS: Review[] = [
  {
    id: 'rev-1',
    name: 'Rajesh Sharma',
    rating: 5,
    comment: 'The regular milk quality in Hathras is unmatched! Delivered right at 6:15 AM every single morning. Purity guaranteed.',
    date: 'Yesterday',
    location: 'Kanchan Nagar, Hathras',
  },
  {
    id: 'rev-2',
    name: 'Pooja Verma',
    rating: 5,
    comment: 'Subscribed to 1L Premium Milk and 250g Paneer daily for 30 days. The paneer is super soft and the milk tea tastes heavenly!',
    date: '2 days ago',
    location: 'Mendu Road, Hathras',
  },
  {
    id: 'rev-3',
    name: 'Amit Agarwal',
    rating: 5,
    comment: 'Desi Ghee aroma is pure nostalgia. Excellent service and superfast delivery in Hathras city radius.',
    date: '3 days ago',
    location: 'Sasni Gate, Hathras',
  },
];
