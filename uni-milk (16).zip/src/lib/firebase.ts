import { initializeApp, getApps } from 'firebase/app';
import {
  getFirestore,
  collection,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  onSnapshot,
  query,
  where,
  getDocs,
  orderBy,
  serverTimestamp,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];

export const db = getFirestore(
  app,
  firebaseConfig.firestoreDatabaseId && firebaseConfig.firestoreDatabaseId.trim() !== ''
    ? firebaseConfig.firestoreDatabaseId
    : '(default)'
);

export interface FirestoreOrder {
  id?: string;
  orderNumber: string;
  customerName: string;
  customerPhone: string;
  deliveryAddress: string;
  deliverySlot: string;
  paymentMethod: string;
  status: 'Pending' | 'Accepted (On The Way)' | 'Delivered' | 'Cancelled';
  totalAmount: number;
  items: Array<{
    name: string;
    size: string;
    quantity: number;
    price: number;
  }>;
  createdAt?: any;
  updatedAt?: any;
}

export interface FirestoreSubscription {
  id?: string;
  subscriptionNumber: string;
  customerName: string;
  customerPhone: string;
  deliveryAddress: string;
  deliverySlot: string;
  productName: string;
  variantSize: string;
  dailyQuantity: number;
  planDays: number;
  startDate: string;
  endDate: string;
  totalPrice: number;
  status: 'Pending' | 'Active' | 'Paused' | 'Completed';
  createdAt?: any;
  updatedAt?: any;
}

// Add Order to Firestore
export const saveOrderToFirestore = async (order: Omit<FirestoreOrder, 'id' | 'createdAt' | 'updatedAt'>) => {
  try {
    const ordersCol = collection(db, 'orders');
    const docRef = await addDoc(ordersCol, {
      ...order,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return docRef.id;
  } catch (error) {
    console.error('Error saving order to Firestore:', error);
    return null;
  }
};

// Add Subscription to Firestore
export const saveSubscriptionToFirestore = async (
  sub: Omit<FirestoreSubscription, 'id' | 'createdAt' | 'updatedAt'>
) => {
  try {
    const subsCol = collection(db, 'subscriptions');
    const docRef = await addDoc(subsCol, {
      ...sub,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return docRef.id;
  } catch (error) {
    console.error('Error saving subscription to Firestore:', error);
    return null;
  }
};

// Update Order Status in Firestore
export const updateOrderStatusInFirestore = async (
  orderId: string,
  status: FirestoreOrder['status']
) => {
  try {
    const orderDoc = doc(db, 'orders', orderId);
    await updateDoc(orderDoc, {
      status,
      updatedAt: serverTimestamp(),
    });
    return true;
  } catch (error) {
    console.error('Error updating order status:', error);
    return false;
  }
};

// Update Subscription Status in Firestore
export const updateSubscriptionStatusInFirestore = async (
  subId: string,
  status: FirestoreSubscription['status']
) => {
  try {
    const subDoc = doc(db, 'subscriptions', subId);
    await updateDoc(subDoc, {
      status,
      updatedAt: serverTimestamp(),
    });
    return true;
  } catch (error) {
    console.error('Error updating subscription status:', error);
    return false;
  }
};

// Delete Order from Firestore (by Doc ID and/or Order Number)
export const deleteOrderFromFirestore = async (orderId?: string, orderNumber?: string) => {
  try {
    const ordersCol = collection(db, 'orders');

    // 1. Delete by document ID if provided
    if (orderId) {
      try {
        const orderDoc = doc(db, 'orders', orderId);
        await deleteDoc(orderDoc);
      } catch (e) {
        console.warn('Direct doc delete notice:', e);
      }
    }

    // 2. Also query by orderNumber or targetNum and delete matching docs
    const targetNum = orderNumber || orderId;
    if (targetNum) {
      try {
        const q = query(ordersCol, where('orderNumber', '==', targetNum));
        const querySnap = await getDocs(q);
        const deletePromises: Promise<void>[] = [];
        querySnap.forEach((d) => {
          deletePromises.push(deleteDoc(doc(db, 'orders', d.id)));
        });
        await Promise.all(deletePromises);
      } catch (e) {
        console.warn('Query order delete notice:', e);
      }
    }
    return true;
  } catch (error) {
    console.error('Error deleting order from Firestore:', error);
    return false;
  }
};

// Delete Subscription from Firestore (by Doc ID and/or Subscription Number)
export const deleteSubscriptionFromFirestore = async (subId?: string, subNumber?: string) => {
  try {
    const subsCol = collection(db, 'subscriptions');

    // 1. Delete by document ID if provided
    if (subId) {
      try {
        const subDoc = doc(db, 'subscriptions', subId);
        await deleteDoc(subDoc);
      } catch (e) {
        console.warn('Direct sub delete notice:', e);
      }
    }

    // 2. Also query by subscriptionNumber / targetNum and delete matching docs
    const targetNum = subNumber || subId;
    if (targetNum) {
      try {
        const q = query(subsCol, where('subscriptionNumber', '==', targetNum));
        const querySnap = await getDocs(q);
        const deletePromises: Promise<void>[] = [];
        querySnap.forEach((d) => {
          deletePromises.push(deleteDoc(doc(db, 'subscriptions', d.id)));
        });
        await Promise.all(deletePromises);
      } catch (e) {
        console.warn('Query sub delete notice:', e);
      }
    }
    return true;
  } catch (error) {
    console.error('Error deleting subscription from Firestore:', error);
    return false;
  }
};

// Real-time listener for Orders
export const subscribeToOrders = (callback: (orders: FirestoreOrder[]) => void) => {
  const ordersCol = collection(db, 'orders');

  const processSnapshot = (snapshot: any) => {
    const ordersList: FirestoreOrder[] = [];
    snapshot.forEach((doc: any) => {
      ordersList.push({ id: doc.id, ...doc.data() } as FirestoreOrder);
    });
    // Sort manually by createdAt if available
    ordersList.sort((a, b) => {
      const timeA = a.createdAt?.seconds || 0;
      const timeB = b.createdAt?.seconds || 0;
      return timeB - timeA;
    });
    callback(ordersList);
  };

  return onSnapshot(
    query(ordersCol, orderBy('createdAt', 'desc')),
    processSnapshot,
    (error) => {
      console.warn('Firestore orders snapshot error, using unordered fallback:', error);
      return onSnapshot(ordersCol, processSnapshot);
    }
  );
};

// Real-time listener for Subscriptions
export const subscribeToSubscriptions = (callback: (subs: FirestoreSubscription[]) => void) => {
  const subsCol = collection(db, 'subscriptions');

  const processSnapshot = (snapshot: any) => {
    const subsList: FirestoreSubscription[] = [];
    snapshot.forEach((doc: any) => {
      subsList.push({ id: doc.id, ...doc.data() } as FirestoreSubscription);
    });
    subsList.sort((a, b) => {
      const timeA = a.createdAt?.seconds || 0;
      const timeB = b.createdAt?.seconds || 0;
      return timeB - timeA;
    });
    callback(subsList);
  };

  return onSnapshot(
    query(subsCol, orderBy('createdAt', 'desc')),
    processSnapshot,
    (error) => {
      console.warn('Firestore subscriptions snapshot error, using unordered fallback:', error);
      return onSnapshot(subsCol, processSnapshot);
    }
  );
};
