import React from 'react';
import { Home, PackageCheck, CalendarCheck, ShoppingBag, User, Sparkles } from 'lucide-react';
import { UserProfile } from '../types';

interface MobileBottomNavProps {
  cartCount: number;
  activeOrdersCount: number;
  hasActiveSubscription: boolean;
  user: UserProfile;
  onOpenOrders: () => void;
  onOpenSubscription: () => void;
  onOpenCart: () => void;
  onOpenProfile: () => void;
  onOpenAuth: () => void;
  onScrollToTop: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  cartCount,
  activeOrdersCount,
  hasActiveSubscription,
  user,
  onOpenOrders,
  onOpenSubscription,
  onOpenCart,
  onOpenProfile,
  onOpenAuth,
  onScrollToTop,
}) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-xl border-t border-emerald-100 shadow-[0_-4px_20px_rgba(0,0,0,0.08)] md:hidden pb-safe">
      <div className="grid grid-cols-5 h-16 items-center px-1">
        
        {/* 1. Home / Dairy */}
        <button
          onClick={onScrollToTop}
          className="flex flex-col items-center justify-center py-1 text-slate-700 hover:text-emerald-700 transition-colors cursor-pointer"
        >
          <Home className="w-5 h-5 text-emerald-800" />
          <span className="text-[10px] font-bold mt-0.5">Home</span>
        </button>

        {/* 2. My Orders */}
        <button
          onClick={onOpenOrders}
          className="flex flex-col items-center justify-center py-1 text-slate-700 hover:text-emerald-700 transition-colors relative cursor-pointer"
        >
          <div className="relative">
            <PackageCheck className="w-5 h-5 text-emerald-800" />
            {activeOrdersCount > 0 && (
              <span className="absolute -top-1.5 -right-2 bg-emerald-600 text-white font-extrabold text-[9px] w-4 h-4 rounded-full flex items-center justify-center animate-pulse shadow-xs">
                {activeOrdersCount}
              </span>
            )}
          </div>
          <span className="text-[10px] font-bold mt-0.5">Orders</span>
        </button>

        {/* 3. Subscription */}
        <button
          onClick={onOpenSubscription}
          className="flex flex-col items-center justify-center py-1 text-slate-700 hover:text-emerald-700 transition-colors relative cursor-pointer"
        >
          <div className="relative">
            <CalendarCheck className="w-5 h-5 text-amber-600" />
            {hasActiveSubscription && (
              <span className="absolute -top-1 -right-1 bg-amber-400 text-emerald-950 p-0.5 rounded-full shadow-xs animate-bounce">
                <Sparkles className="w-2.5 h-2.5" />
              </span>
            )}
          </div>
          <span className="text-[10px] font-bold mt-0.5 text-slate-800">Plan</span>
        </button>

        {/* 4. Cart */}
        <button
          onClick={onOpenCart}
          className="flex flex-col items-center justify-center py-1 text-slate-700 hover:text-emerald-700 transition-colors relative cursor-pointer"
        >
          <div className="relative">
            <ShoppingBag className="w-5 h-5 text-emerald-800" />
            {cartCount > 0 && (
              <span className="absolute -top-1.5 -right-2.5 bg-amber-400 text-emerald-950 font-black text-[10px] w-4 h-4 rounded-full flex items-center justify-center shadow-xs">
                {cartCount}
              </span>
            )}
          </div>
          <span className="text-[10px] font-bold mt-0.5">Cart</span>
        </button>

        {/* 5. Profile / Auth */}
        <button
          onClick={user.isLoggedIn ? onOpenProfile : onOpenAuth}
          className="flex flex-col items-center justify-center py-1 text-slate-700 hover:text-emerald-700 transition-colors cursor-pointer"
        >
          {user.isLoggedIn ? (
            <div className="w-5 h-5 rounded-full bg-emerald-700 text-white font-black flex items-center justify-center text-[10px] uppercase shadow-xs">
              {user.name ? user.name.charAt(0) : 'U'}
            </div>
          ) : (
            <User className="w-5 h-5 text-emerald-800" />
          )}
          <span className="text-[10px] font-bold mt-0.5">
            {user.isLoggedIn ? 'Profile' : 'Login'}
          </span>
        </button>

      </div>
    </div>
  );
};
