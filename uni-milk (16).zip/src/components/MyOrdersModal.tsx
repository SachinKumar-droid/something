import React, { useState } from 'react';
import { X, PackageCheck, Clock, MapPin, Phone, MessageSquare, RefreshCw, ShoppingBag, Truck, CheckCircle2, ShieldCheck } from 'lucide-react';
import { Order } from '../types';

interface MyOrdersModalProps {
  isOpen: boolean;
  onClose: () => void;
  orders: Order[];
  onReorder: (order: Order) => void;
}

export const MyOrdersModal: React.FC<MyOrdersModalProps> = ({
  isOpen,
  onClose,
  orders,
  onReorder,
}) => {
  if (!isOpen) return null;

  const [selectedOrderId, setSelectedOrderId] = useState<string>(
    orders.length > 0 ? orders[0].id : ''
  );

  const activeOrder = orders.find((o) => o.id === selectedOrderId) || orders[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-white rounded-3xl w-full max-w-4xl overflow-hidden shadow-2xl border border-white/60 my-auto">
        
        {/* Header */}
        <div className="bg-[#2D5A27] text-white p-4 sm:p-5 flex items-center justify-between border-b border-white/10">
          <div className="flex items-center gap-3">
            <PackageCheck className="w-6 h-6 text-amber-300 shrink-0" />
            <div>
              <h3 className="font-extrabold text-base sm:text-lg">My Orders & Receipts</h3>
              <p className="text-xs text-emerald-100/90">View order history. For any delivery updates, call us directly.</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition-all cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 space-y-4">

          {/* Direct Phone Assistance Call Banner */}
          <div className="bg-gradient-to-r from-emerald-900 to-slate-900 text-white p-4 rounded-2xl border border-emerald-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-md">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-amber-400 text-emerald-950 rounded-xl font-black shrink-0">
                <Phone className="w-5 h-5" />
              </div>
              <div>
                <p className="font-extrabold text-xs sm:text-sm text-white">Direct Phone Call Support</p>
                <p className="text-xs text-emerald-200">
                  For delivery timing or special requests, call us directly at <strong className="text-amber-300 font-mono">+91 9837854627</strong>
                </p>
              </div>
            </div>

            <a
              href="tel:9837854627"
              className="px-4 py-2.5 bg-amber-400 hover:bg-amber-300 text-emerald-950 font-black text-xs rounded-xl shadow-md shrink-0 flex items-center gap-1.5 transition-all"
            >
              <Phone className="w-4 h-4 text-emerald-950" />
              <span>Call 9837854627</span>
            </a>
          </div>

          {orders.length === 0 ? (
            <div className="py-16 text-center space-y-3">
              <ShoppingBag className="w-16 h-16 text-slate-300 mx-auto" />
              <h4 className="font-bold text-slate-800 text-lg">No past orders found</h4>
              <p className="text-slate-500 text-xs max-w-sm mx-auto">
                Place your first order for fresh milk, dahi, or ghee to view your receipts here!
              </p>
              <button
                onClick={onClose}
                className="px-6 py-2.5 bg-emerald-600 text-white font-bold text-xs rounded-xl shadow-md cursor-pointer"
              >
                Start Shopping Now
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* Left Column: Orders List */}
              <div className="space-y-3 border-b lg:border-b-0 lg:border-r border-slate-200 pb-4 lg:pb-0 lg:pr-4 max-h-[40vh] lg:max-h-[60vh] overflow-y-auto">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                  Order History ({orders.length})
                </h4>
                {orders.map((order) => {
                  const isSelected = order.id === activeOrder?.id;
                  return (
                    <button
                      key={order.id}
                      onClick={() => setSelectedOrderId(order.id)}
                      className={`w-full text-left p-3.5 rounded-2xl border transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-emerald-50 border-emerald-500 shadow-xs ring-1 ring-emerald-500/30'
                          : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="font-bold text-slate-900">{order.id}</span>
                        <span className="text-slate-400">{order.date}</span>
                      </div>
                      <p className="text-xs font-semibold text-slate-700 truncate">
                        {order.items.map((i) => `${i.productName} (${i.variant.size})`).join(', ')}
                      </p>
                      <div className="flex items-center justify-between mt-2 text-xs">
                        <span className="font-extrabold text-emerald-700">₹{order.grandTotal}</span>
                        <span
                          className={`px-2 py-0.5 rounded-full font-black text-[10px] uppercase ${
                            order.status === 'Accepted (On The Way)' ||
                            order.status === 'Accepted' ||
                            order.status === 'Out for Delivery'
                              ? 'bg-emerald-600 text-white animate-pulse'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {order.status === 'Accepted (On The Way)' ||
                          order.status === 'Accepted' ||
                          order.status === 'Out for Delivery'
                            ? 'Order Accepted'
                            : order.paymentMethod}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Right Column: Selected Order Receipt Details */}
              {activeOrder && (
                <div className="lg:col-span-2 space-y-4 max-h-[60vh] overflow-y-auto pr-1">
                  
                  {/* LIVE STATUS BANNER ABOVE ORDER DETAILS */}
                  {(activeOrder.status === 'Accepted (On The Way)' ||
                    activeOrder.status === 'Accepted' ||
                    activeOrder.status === 'Out for Delivery') ? (
                    <div className="bg-gradient-to-r from-emerald-800 via-emerald-700 to-teal-800 text-white p-4 rounded-2xl border-2 border-emerald-400 shadow-lg space-y-1 animate-pulse">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-2xl bg-amber-400 text-emerald-950 flex items-center justify-center font-black shadow-inner shrink-0">
                            <Truck className="w-6 h-6" />
                          </div>
                          <div>
                            <h4 className="text-sm font-black text-amber-300 uppercase tracking-wide flex items-center gap-1.5">
                              <span>ORDER ACCEPTED (ON THE WAY)</span>
                              <CheckCircle2 className="w-4 h-4 text-emerald-300" />
                            </h4>
                            <p className="text-xs text-emerald-100 font-bold">
                              Dukaan dwara aapka order accept kar liya gaya hai! Hathras delivery partner raste me hain.
                            </p>
                          </div>
                        </div>
                        <span className="bg-amber-300 text-emerald-950 text-[10px] sm:text-xs font-black px-3 py-1 rounded-full uppercase shadow-xs shrink-0">
                          ACCEPTED
                        </span>
                      </div>
                    </div>
                  ) : activeOrder.status === 'Delivered' ? (
                    <div className="bg-emerald-50 text-emerald-900 p-3.5 rounded-2xl border border-emerald-300 text-xs font-bold flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                        <span>Order Delivered Successfully! Enjoy fresh dairy.</span>
                      </div>
                      <span className="bg-emerald-200 text-emerald-900 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase">
                        DELIVERED
                      </span>
                    </div>
                  ) : (
                    <div className="bg-amber-50 text-amber-900 border border-amber-200 p-3.5 rounded-2xl text-xs font-semibold flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-amber-600 shrink-0" />
                        <span>Order Status: <strong className="text-amber-950">{activeOrder.status || 'Order Placed'}</strong></span>
                      </div>
                      <span className="text-[10px] bg-amber-200 text-amber-950 px-2.5 py-0.5 rounded-full font-extrabold uppercase">
                        PENDING CONFIRMATION
                      </span>
                    </div>
                  )}

                  {/* Order Overview Header */}
                  <div className="bg-[#2D5A27] text-white rounded-2xl p-4 border border-white/20 shadow-md flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-amber-300 font-bold uppercase tracking-wider block">
                        Delivery Time Slot
                      </span>
                      <p className="text-base sm:text-lg font-black text-white flex items-center gap-1.5 mt-0.5">
                        <Clock className="w-4 h-4 text-amber-300" />
                        <span>{activeOrder.deliverySlot || activeOrder.estimatedTime}</span>
                      </p>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-emerald-100 font-semibold block">Order ID</span>
                      <span className="text-xs sm:text-sm font-mono font-bold text-white">{activeOrder.id}</span>
                    </div>
                  </div>

                  {/* Delivery Address Box */}
                  <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 text-xs text-slate-700 space-y-1">
                    <p className="font-bold text-slate-900 flex items-center gap-1.5">
                      <MapPin className="w-4 h-4 text-emerald-600" />
                      <span>Delivery Address:</span>
                    </p>
                    <p className="pl-5 text-slate-600">
                      {activeOrder.deliveryAddress.fullName} ({activeOrder.deliveryAddress.phone})
                    </p>
                    <p className="pl-5 text-slate-600">
                      {activeOrder.deliveryAddress.streetAddress}, {activeOrder.deliveryAddress.area}, Hathras
                    </p>
                  </div>

                  {/* Items Ordered List */}
                  <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2">
                    <h5 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                      Items Ordered
                    </h5>
                    {activeOrder.items.map((item, idx) => (
                      <div key={idx} className="flex items-center justify-between text-xs py-1.5 border-b border-slate-200/60 last:border-0">
                        <div className="flex items-center gap-2.5">
                          <img src={item.image} alt={item.productName} className="w-8 h-8 object-cover rounded-md" />
                          <div>
                            <span className="font-bold text-slate-900">{item.productName}</span>
                            <span className="text-slate-500 ml-2">({item.variant.size} × {item.quantity})</span>
                          </div>
                        </div>
                        <span className="font-black text-slate-900">₹{item.variant.price * item.quantity}</span>
                      </div>
                    ))}

                    <div className="pt-2 flex items-center justify-between text-xs font-black text-slate-900 border-t border-slate-200">
                      <span>Total Paid ({activeOrder.paymentMethod}):</span>
                      <span className="text-emerald-700 text-base">₹{activeOrder.grandTotal}</span>
                    </div>
                  </div>

                  {/* Action Buttons: Re-order, Call, WhatsApp */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-2">
                    <button
                      onClick={() => onReorder(activeOrder)}
                      className="py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-xs flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <RefreshCw className="w-4 h-4" />
                      <span>Re-order Items</span>
                    </button>

                    <a
                      href="tel:9837854627"
                      className="py-3 bg-slate-900 hover:bg-slate-950 text-amber-300 font-extrabold text-xs rounded-xl flex items-center justify-center gap-1.5"
                    >
                      <Phone className="w-4 h-4 text-amber-400" />
                      <span>Call Support</span>
                    </a>

                    <a
                      href={`https://wa.me/919837854627?text=Hi%20Uni%20Milk,%20query%20regarding%20Order%20${activeOrder.id}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="py-3 bg-[#2D5A27] text-white font-bold text-xs rounded-xl border border-white/20 flex items-center justify-center gap-1.5 hover:bg-emerald-800"
                    >
                      <MessageSquare className="w-4 h-4 text-amber-300" />
                      <span>WhatsApp Support</span>
                    </a>
                  </div>

                </div>
              )}

            </div>
          )}
        </div>

      </div>
    </div>
  );
};
