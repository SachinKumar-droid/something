import React, { useState } from 'react';
import { X, Mail, Lock, User, MapPin, Phone, ShieldCheck, Sparkles, CheckCircle2 } from 'lucide-react';
import { Address, UserProfile } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (user: UserProfile) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onLoginSuccess }) => {
  if (!isOpen) return null;

  const [authMode, setAuthMode] = useState<'login' | 'signup'>('signup');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [area, setArea] = useState('Kanchan Nagar');
  const [streetAddress, setStreetAddress] = useState('');
  const [isSuccessMessage, setIsSuccessMessage] = useState(false);

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const loggedInUser: UserProfile = {
      name: name || email.split('@')[0] || 'Uni Milk Member',
      email: email || 'uni.milkofficial2426@gmail.com',
      phone: phone || '9837854627',
      isLoggedIn: true,
      authMethod: 'email',
      address: {
        fullName: name || 'Uni Milk Member',
        phone: phone || '9837854627',
        area: area || 'Kanchan Nagar',
        streetAddress: streetAddress || 'Kanchan Nagar Main St',
        landmark: 'Near Water Tank',
        city: 'Hathras',
        pincode: '204101',
      },
      subscriptions: [],
    };

    setIsSuccessMessage(true);
    setTimeout(() => {
      onLoginSuccess(loggedInUser);
      setIsSuccessMessage(false);
      onClose();
    }, 600);
  };

  const handleGoogleLogin = () => {
    const googleUser: UserProfile = {
      name: 'Sachin Singh (Google)',
      email: 'sachinsingh6396312@gmail.com',
      phone: '9837854627',
      isLoggedIn: true,
      authMethod: 'google',
      address: {
        fullName: 'Sachin Singh',
        phone: '9837854627',
        area: 'Kanchan Nagar',
        streetAddress: 'Plot 12, Kanchan Nagar',
        landmark: 'Near Water Tank',
        city: 'Hathras',
        pincode: '204101',
      },
      subscriptions: [],
    };

    setIsSuccessMessage(true);
    setTimeout(() => {
      onLoginSuccess(googleUser);
      setIsSuccessMessage(false);
      onClose();
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl border border-white/60 my-auto">
        
        {/* Header */}
        <div className="bg-[#2D5A27] text-white p-5 sm:p-6 relative border-b border-white/10">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-all cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-amber-400 text-emerald-950 font-black flex items-center justify-center text-lg shadow-sm">
              U
            </div>
            <div>
              <h3 className="font-extrabold text-lg sm:text-xl text-white">Welcome to Uni Milk</h3>
              <p className="text-xs text-emerald-100/90">Sign up or log in for Hathras daily delivery</p>
            </div>
          </div>
        </div>

        <div className="p-5 sm:p-6 space-y-4">
          
          {isSuccessMessage ? (
            <div className="py-8 text-center space-y-3">
              <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto animate-bounce" />
              <h4 className="font-extrabold text-slate-900 text-base sm:text-lg">Authentication Successful!</h4>
              <p className="text-xs text-slate-600">Syncing your address and order profile...</p>
            </div>
          ) : (
            <>
              {/* Google Sign-In Trigger */}
              <button
                type="button"
                onClick={handleGoogleLogin}
                className="w-full py-3 px-4 bg-white hover:bg-slate-50 border border-slate-300 text-slate-800 font-extrabold text-xs sm:text-sm rounded-2xl flex items-center justify-center gap-2.5 shadow-xs transition-all cursor-pointer active:scale-[0.98]"
              >
                <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span>Continue with Google Sign-In</span>
              </button>

              <div className="relative flex items-center justify-center my-3">
                <div className="border-t border-slate-200 w-full" />
                <span className="bg-white px-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest absolute">
                  OR USE EMAIL & PASSWORD
                </span>
              </div>

              {/* Email / Password Form */}
              <form onSubmit={handleEmailSubmit} className="space-y-3">
                {authMode === 'signup' && (
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">Full Name</label>
                    <div className="relative">
                      <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="e.g. Ramesh Sharma"
                        className="w-full pl-9 pr-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                      />
                    </div>
                  </div>
                )}

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Email Address</label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="your.email@example.com"
                      className="w-full pl-9 pr-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Password</label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-9 pr-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Phone Number</label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="10-digit mobile number"
                      className="w-full pl-9 pr-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                    />
                  </div>
                </div>

                {authMode === 'signup' && (
                  <>
                    <div>
                      <label className="text-xs font-bold text-slate-700 block mb-1">Area / Colony in Hathras</label>
                      <div className="relative">
                        <MapPin className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                          type="text"
                          value={area}
                          onChange={(e) => setArea(e.target.value)}
                          placeholder="e.g. Kanchan Nagar, Hathras"
                          className="w-full pl-9 pr-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-xs font-bold text-slate-700 block mb-1">Street Address</label>
                      <input
                        type="text"
                        value={streetAddress}
                        onChange={(e) => setStreetAddress(e.target.value)}
                        placeholder="House No / Street details"
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                      />
                    </div>
                  </>
                )}

                <button
                  type="submit"
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs sm:text-sm rounded-xl shadow-md transition-all cursor-pointer mt-3"
                >
                  {authMode === 'signup' ? 'Create Account & Log In' : 'Log In to Profile'}
                </button>
              </form>

              <div className="text-center text-xs text-slate-500 pt-1">
                {authMode === 'signup' ? (
                  <p>
                    Already have an account?{' '}
                    <button
                      type="button"
                      onClick={() => setAuthMode('login')}
                      className="text-emerald-700 font-bold underline cursor-pointer"
                    >
                      Log In
                    </button>
                  </p>
                ) : (
                  <p>
                    Need a new account?{' '}
                    <button
                      type="button"
                      onClick={() => setAuthMode('signup')}
                      className="text-emerald-700 font-bold underline cursor-pointer"
                    >
                      Sign Up
                    </button>
                  </p>
                )}
              </div>
            </>
          )}

        </div>

      </div>
    </div>
  );
};

