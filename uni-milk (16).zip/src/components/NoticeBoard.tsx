import React from 'react';
import { BellRing, Clock, MapPin, Sparkles } from 'lucide-react';

export const NoticeBoard: React.FC = () => {
  return (
    <div className="mx-2 sm:mx-6 my-2 bg-emerald-600 text-white rounded-full flex items-center justify-between px-4 sm:px-6 py-2 shadow-sm backdrop-blur-md border border-white/30 text-xs sm:text-sm overflow-hidden">
      <div className="flex items-center justify-between w-full max-w-7xl mx-auto gap-2">
        
        {/* Left Notice Text */}
        <div className="flex items-center gap-2 text-white font-medium truncate">
          <span className="bg-amber-400 text-emerald-950 p-1 sm:p-1.5 rounded-full shrink-0 shadow-xs font-black">
            <BellRing className="w-3.5 h-3.5 sm:w-4 sm:h-4 animate-bounce" />
          </span>
          <p className="leading-snug truncate">
            <strong className="text-amber-300 font-extrabold uppercase tracking-wider mr-1">📢 Notice:</strong> 
            New fresh milk arrives every morning at <strong className="text-white font-black underline">6:00 AM</strong>. Order before 10 PM for next day delivery. Enjoy our best prices every day!
          </p>
        </div>

        {/* Right Badges */}
        <div className="hidden md:flex items-center gap-3 shrink-0 text-xs">
          <div className="flex items-center gap-1.5 bg-white/20 px-3 py-1 rounded-full border border-white/30 text-white font-semibold">
            <Clock className="w-3.5 h-3.5 text-amber-300" />
            <span>Best Prices Every Day</span>
          </div>
          <div className="flex items-center gap-1.5 bg-amber-400 text-emerald-950 px-3 py-1 rounded-full font-black shadow-xs">
            <MapPin className="w-3.5 h-3.5 text-emerald-900" />
            <span>Hathras Delivery</span>
          </div>
        </div>

      </div>
    </div>
  );
};
