import React from 'react';
import { UNI_MILK_LOGO_URL } from '../config/logo';

interface UniMilkLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  className?: string;
}

export const UniMilkLogo: React.FC<UniMilkLogoProps> = ({
  size = 'md',
  showText = true,
  className = '',
}) => {
  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-11 h-11',
    lg: 'w-16 h-16',
    xl: 'w-24 h-24',
  };

  const textSizeClasses = {
    sm: 'text-lg',
    md: 'text-2xl',
    lg: 'text-3xl',
    xl: 'text-4xl',
  };

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      {/* Circular Frame for Logo */}
      <div className={`${sizeClasses[size]} rounded-full bg-white/20 backdrop-blur-md p-0.5 border border-white/40 shadow-md flex items-center justify-center shrink-0 overflow-hidden relative group hover:scale-105 transition-transform`}>
        <img
          src={UNI_MILK_LOGO_URL}
          alt="Uni Milk Official Logo"
          className="w-full h-full object-contain p-0.5 drop-shadow-sm"
          referrerPolicy="no-referrer"
        />
      </div>

      {showText && (
        <div>
          <div className="flex items-center gap-1.5">
            <span className={`${textSizeClasses[size]} font-black text-white tracking-tight font-serif drop-shadow-xs`}>
              Uni <span className="text-amber-300">Milk</span>
            </span>
          </div>
          <p className="text-[11px] text-emerald-100/90 font-medium">
            100% Pure & Fresh Dairy
          </p>
        </div>
      )}
    </div>
  );
};
