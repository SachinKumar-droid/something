import React, { useState } from 'react';
import { AlertCircle, MessageSquare, Send, CheckCircle2 } from 'lucide-react';
import { sendEmailNotification, OFFICIAL_STORE_EMAIL } from '../utils/notification';

export const ReportIssueSection: React.FC = () => {
  const [issueText, setIssueText] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [sentSuccess, setSentSuccess] = useState(false);

  const handleReportIssue = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!issueText.trim()) return;

    setIsSending(true);

    // 1. Dispatch Formspree email
    await sendEmailNotification(
      'New Customer Issue Report',
      `Customer reported issue:\n${issueText.trim()}`,
      OFFICIAL_STORE_EMAIL,
      { officialStoreEmail: OFFICIAL_STORE_EMAIL, issueText: issueText.trim() }
    );

    // 2. Open WhatsApp as well for instant chat
    const message = `*ISSUE REPORT - UNI MILK HATHRAS*%0A%0A*Customer Issue Description:*%0A${encodeURIComponent(
      issueText.trim()
    )}%0A%0A_Please resolve my query as soon as possible._`;

    window.open(`https://wa.me/919837854627?text=${message}`, '_blank');

    setIsSending(false);
    setSentSuccess(true);
    setIssueText('');
    setTimeout(() => setSentSuccess(false), 4000);
  };

  return (
    <div className="bg-[#2D5A27] border-t border-emerald-800/40 text-white py-8 px-4">
      <div className="max-w-4xl mx-auto bg-white/10 backdrop-blur-md p-6 sm:p-8 rounded-2xl border border-white/20 shadow-lg">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          
          <div className="space-y-2 text-center md:text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/20 border border-amber-300/40 text-amber-300 text-xs font-bold uppercase tracking-wider">
              <AlertCircle className="w-4 h-4" />
              <span>Report An Issue / Instant Resolution</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-black text-white font-serif">
              Facing Any Issue With Delivery Or Product Quality?
            </h3>
            <p className="text-emerald-100 text-xs sm:text-sm max-w-md">
              Type your issue below. A direct ticket will be emailed to <strong className="text-amber-300 font-mono">uni.milkofficial2426@gmail.com</strong> and routed to Uni Milk support.
            </p>
          </div>

          <form onSubmit={handleReportIssue} className="w-full md:w-auto flex-1 max-w-md space-y-3">
            <textarea
              required
              rows={2}
              value={issueText}
              onChange={(e) => setIssueText(e.target.value)}
              placeholder="Type your issue here (e.g. delivery query, packaging query)..."
              className="w-full px-4 py-3 bg-white/15 backdrop-blur-md border border-white/30 rounded-2xl text-xs text-white placeholder-emerald-100/70 focus:outline-none focus:border-amber-300"
            />
            
            {sentSuccess && (
              <div className="p-2 bg-emerald-500/30 border border-emerald-300 rounded-xl text-xs font-bold text-amber-200 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-300" />
                <span>Issue report emailed to support & opened on WhatsApp!</span>
              </div>
            )}

            <button
              type="submit"
              disabled={isSending}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs sm:text-sm rounded-2xl shadow-md border border-white/30 flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
            >
              {isSending ? (
                <span>Sending Email & Ticket...</span>
              ) : (
                <>
                  <MessageSquare className="w-4 h-4 text-amber-300" />
                  <span>Report Issue (Email & WhatsApp)</span>
                </>
              )}
            </button>
          </form>

        </div>
      </div>
    </div>
  );
};

