import React, { useState } from 'react';
import { Product, ProductVariant, CartItem } from '../types';
import { ShoppingBag, Zap, Check, Sparkles, Filter, Minus, Plus } from 'lucide-react';

interface ProductCatalogProps {
  products: Product[];
  cart?: CartItem[];
  onAddToCart: (product: Product, variant: ProductVariant, quantity?: number) => void;
  onUpdateQuantity?: (productId: string, variantId: string, delta: number) => void;
  onDirectOrder: (product: Product, variant: ProductVariant) => void;
}

export const ProductCatalog: React.FC<ProductCatalogProps> = ({
  products,
  cart = [],
  onAddToCart,
  onUpdateQuantity,
  onDirectOrder,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedVariants, setSelectedVariants] = useState<Record<string, ProductVariant>>({});
  const [addedAnimation, setAddedAnimation] = useState<string | null>(null);

  // Filter products by category
  const filteredProducts = products.filter((p) => {
    return selectedCategory === 'all' || p.category === selectedCategory;
  });

  const getActiveVariant = (product: Product): ProductVariant => {
    return selectedVariants[product.id] || product.variants[0];
  };

  const handleSelectVariant = (productId: string, variant: ProductVariant) => {
    setSelectedVariants((prev) => ({ ...prev, [productId]: variant }));
  };

  const handleAddToCartClick = (product: Product) => {
    const variant = getActiveVariant(product);
    onAddToCart(product, variant, 1);
    setAddedAnimation(`${product.id}-${variant.id}`);
    setTimeout(() => setAddedAnimation(null), 1200);
  };

  return (
    <section id="products-section" className="py-12 px-4 max-w-7xl mx-auto">
      
      {/* Category Heading & Filter Pills */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold uppercase tracking-wider mb-2">
          <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
          <span>Farm Fresh Dairy Products</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight font-serif">
          Our Fresh <span className="text-emerald-600">Milk & Dairy</span> Selection
        </h2>
        <div className="w-20 h-1 bg-emerald-500 mx-auto mt-2 rounded-full" />
      </div>

      {/* Filter Tabs (5 Main Categories) */}
      <div className="flex items-center justify-center gap-2 flex-wrap mb-8">
        <button
          onClick={() => setSelectedCategory('all')}
          className={`px-4 py-2 rounded-full font-bold text-xs sm:text-sm transition-all cursor-pointer ${
            selectedCategory === 'all'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'bg-white/60 backdrop-blur-md text-slate-800 hover:bg-white/90 border border-white/80'
          }`}
        >
          All Products
        </button>

        <button
          onClick={() => setSelectedCategory('milk')}
          className={`px-4 py-2 rounded-full font-bold text-xs sm:text-sm transition-all cursor-pointer flex items-center gap-1.5 ${
            selectedCategory === 'milk'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'bg-white/60 backdrop-blur-md text-slate-800 hover:bg-white/90 border border-white/80'
          }`}
        >
          <span>🥛 Pure Milk</span>
        </button>

        <button
          onClick={() => setSelectedCategory('dahi')}
          className={`px-4 py-2 rounded-full font-bold text-xs sm:text-sm transition-all cursor-pointer ${
            selectedCategory === 'dahi'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'bg-white/60 backdrop-blur-md text-slate-800 hover:bg-white/90 border border-white/80'
          }`}
        >
          🏺 Fresh Dahi
        </button>

        <button
          onClick={() => setSelectedCategory('paneer')}
          className={`px-4 py-2 rounded-full font-bold text-xs sm:text-sm transition-all cursor-pointer ${
            selectedCategory === 'paneer'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'bg-white/60 backdrop-blur-md text-slate-800 hover:bg-white/90 border border-white/80'
          }`}
        >
          🧀 Malai Paneer
        </button>

        <button
          onClick={() => setSelectedCategory('chhach')}
          className={`px-4 py-2 rounded-full font-bold text-xs sm:text-sm transition-all cursor-pointer ${
            selectedCategory === 'chhach'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'bg-white/60 backdrop-blur-md text-slate-800 hover:bg-white/90 border border-white/80'
          }`}
        >
          🥛 Cool Chhach
        </button>

        <button
          onClick={() => setSelectedCategory('ghee')}
          className={`px-4 py-2 rounded-full font-bold text-xs sm:text-sm transition-all cursor-pointer ${
            selectedCategory === 'ghee'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'bg-white/60 backdrop-blur-md text-slate-800 hover:bg-white/90 border border-white/80'
          }`}
        >
          🏺 Desi Ghee
        </button>
      </div>

      {/* No products found */}
      {filteredProducts.length === 0 && (
        <div className="bg-white/60 backdrop-blur-md rounded-2xl p-12 text-center max-w-md mx-auto border border-white/80 shadow-sm">
          <Filter className="w-12 h-12 text-slate-400 mx-auto mb-3" />
          <h3 className="text-lg font-bold text-slate-800">No products found</h3>
          <p className="text-slate-600 text-sm mt-1">Try adjusting your search query or category filter.</p>
          <button
            onClick={() => {
              setSelectedCategory('all');
            }}
            className="mt-4 px-4 py-2 bg-emerald-600 text-white font-bold text-xs rounded-xl"
          >
            Show All Products
          </button>
        </div>
      )}

      {/* Product Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredProducts.map((product) => {
          const activeVariant = getActiveVariant(product);
          const isAdded = addedAnimation === `${product.id}-${activeVariant.id}`;
          const cartItem = cart.find(
            (item) => item.productId === product.id && item.variant.id === activeVariant.id
          );

          return (
            <div
              key={product.id}
              className="bg-white/70 backdrop-blur-md rounded-2xl overflow-hidden border border-white/90 shadow-sm hover:shadow-md hover:bg-white/85 transition-all duration-300 flex flex-col group relative"
            >
              {/* Badge */}
              {product.badge && (
                <span className="absolute top-3 left-3 z-10 bg-emerald-600 text-white font-bold text-[11px] px-3 py-1 rounded-full shadow-sm uppercase tracking-wider">
                  {product.badge}
                </span>
              )}

              {/* Product Image Container */}
              <div className="relative h-52 sm:h-56 w-full bg-slate-100/50 overflow-hidden">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  loading="lazy"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 via-transparent to-transparent opacity-80" />
                
                {/* Category tag on image */}
                <span className="absolute bottom-3 left-3 text-white text-xs font-semibold bg-slate-900/70 backdrop-blur-sm px-2.5 py-1 rounded-lg border border-white/20">
                  {product.category === 'milk'
                    ? product.subCategory === 'regular'
                      ? 'Regular Milk'
                      : 'Premium Milk'
                    : product.category.toUpperCase()}
                </span>
              </div>

              {/* Card Body */}
              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="text-xl font-bold text-slate-900 tracking-tight group-hover:text-emerald-700 transition-colors">
                    {product.name}
                  </h3>
                  <p className="text-slate-600 text-xs mt-1.5 line-clamp-2 leading-relaxed">
                    {product.description}
                  </p>

                  {/* Quantity / Variant selector pills */}
                  <div className="mt-4">
                    <label className="text-[11px] font-bold uppercase tracking-wider text-slate-500 block mb-1.5">
                      Select Quantity / Size:
                    </label>
                    <div className="flex flex-wrap gap-1.5">
                      {product.variants.map((v) => {
                        const isSelected = activeVariant.id === v.id;
                        return (
                          <button
                            key={v.id}
                            onClick={() => handleSelectVariant(product.id, v)}
                            className={`px-3 py-1.5 rounded-xl font-bold text-xs transition-all cursor-pointer ${
                              isSelected
                                ? 'bg-emerald-600 text-white shadow-xs'
                                : 'bg-white/80 text-slate-700 hover:bg-white border border-slate-200/80'
                            }`}
                          >
                            <span>{v.size}</span>
                            <span className="ml-1 opacity-80">₹{v.price}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* Price Display & Actions */}
                <div className="mt-6 pt-4 border-t border-slate-200/60 flex items-center justify-between gap-3">
                  <div>
                    <span className="text-[10px] text-slate-500 font-semibold uppercase block">Price</span>
                    <span className="text-2xl font-black text-emerald-700">
                      ₹{activeVariant.price}
                    </span>
                  </div>

                  <div className="flex items-center">
                    {/* Blinkit Style Stepper or ADD Button */}
                    {cartItem && cartItem.quantity > 0 ? (
                      <div className="flex items-center bg-emerald-600 text-white rounded-xl shadow-sm border border-emerald-700 p-0.5">
                        <button
                          onClick={() => onUpdateQuantity && onUpdateQuantity(product.id, activeVariant.id, -1)}
                          className="w-8 h-8 flex items-center justify-center bg-emerald-700 hover:bg-emerald-800 active:scale-95 text-white rounded-lg transition-all cursor-pointer"
                          title="Reduce Quantity (-)"
                        >
                          <Minus className="w-4 h-4 stroke-[3]" />
                        </button>
                        <span className="px-3 font-black text-sm text-white min-w-[28px] text-center">
                          {cartItem.quantity}
                        </span>
                        <button
                          onClick={() => handleAddToCartClick(product)}
                          className="w-8 h-8 flex items-center justify-center bg-emerald-700 hover:bg-emerald-800 active:scale-95 text-white rounded-lg transition-all cursor-pointer"
                          title="Increase Quantity (+)"
                        >
                          <Plus className="w-4 h-4 stroke-[3]" />
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => handleAddToCartClick(product)}
                        className={`px-5 py-2.5 rounded-xl font-black text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-sm active:scale-95 uppercase tracking-wider ${
                          isAdded
                            ? 'bg-emerald-800 text-white scale-105'
                            : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-600/20'
                        }`}
                        title="Add to Cart"
                      >
                        {isAdded ? (
                          <>
                            <Check className="w-4 h-4 text-emerald-300" />
                            <span>Added!</span>
                          </>
                        ) : (
                          <>
                            <ShoppingBag className="w-4 h-4 text-emerald-100" />
                            <span>ADD +</span>
                          </>
                        )}
                      </button>
                    )}
                  </div>
                </div>

              </div>
            </div>
          );
        })}
      </div>

    </section>
  );
};
