import React from 'react';
import { X, Trash2, Plus, Minus, ShoppingBag, ArrowRight, ShieldCheck, Sparkles } from 'lucide-react';
import { CartItem } from '../types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (productId: string, variantId: string, delta: number) => void;
  onRemoveItem: (productId: string, variantId: string) => void;
  onClearCart: () => void;
  onProceedToCheckout: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onProceedToCheckout,
}) => {
  if (!isOpen) return null;

  const subtotal = cartItems.reduce((acc, item) => acc + item.variant.price * item.quantity, 0);
  const freeDeliveryThreshold = 200;
  const amountNeededForFreeDelivery = Math.max(0, freeDeliveryThreshold - subtotal);
  const deliveryFee = subtotal >= freeDeliveryThreshold || subtotal === 0 ? 0 : 10;
  const grandTotal = subtotal + deliveryFee;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-slate-950/70 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col justify-between">
          
          {/* Header */}
          <div className="p-5 bg-gradient-to-r from-emerald-900 to-slate-900 text-white flex items-center justify-between border-b border-emerald-800">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-emerald-400" />
              <h3 className="font-extrabold text-lg">Your Fresh Cart</h3>
              <span className="bg-emerald-500/20 text-emerald-300 font-bold text-xs px-2 py-0.5 rounded-full border border-emerald-400/30">
                {cartItems.length} items
              </span>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-white/10 text-slate-300 hover:text-white transition-all"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Free Delivery Bar */}
          <div className="bg-emerald-50 px-5 py-3 border-b border-emerald-100 text-xs">
            {amountNeededForFreeDelivery > 0 ? (
              <p className="text-slate-700 font-medium">
                Add <strong className="text-emerald-700 font-bold">₹{amountNeededForFreeDelivery}</strong> more to unlock <strong className="text-emerald-700 font-bold">FREE Delivery</strong> in Hathras!
              </p>
            ) : (
              <p className="text-emerald-800 font-bold flex items-center gap-1">
                <Sparkles className="w-4 h-4 text-emerald-600" />
                <span>Congratulations! You qualify for FREE Delivery!</span>
              </p>
            )}
            <div className="w-full bg-slate-200 h-2 rounded-full mt-2 overflow-hidden">
              <div
                className="bg-emerald-600 h-full transition-all duration-300 rounded-full"
                style={{ width: `${Math.min(100, (subtotal / freeDeliveryThreshold) * 100)}%` }}
              />
            </div>
          </div>

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {cartItems.length === 0 ? (
              <div className="py-16 text-center space-y-3">
                <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-300">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <h4 className="font-bold text-slate-700 text-lg">Your cart is empty</h4>
                <p className="text-slate-500 text-xs max-w-xs mx-auto">
                  Add fresh milk, dahi, paneer, chhach, or desi ghee to get started!
                </p>
                <button
                  onClick={() => {
                    onClose();
                    const el = document.getElementById('products-section');
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="mt-3 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-md transition-all cursor-pointer inline-flex items-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>+ Add Products Now</span>
                </button>
              </div>
            ) : (
              <>
                {/* Clear All Items Header if > 1 items */}
                {cartItems.length > 1 && (
                  <div className="flex items-center justify-between pb-1 text-xs">
                    <span className="font-extrabold text-slate-700">{cartItems.length} Selected Items</span>
                    <button
                      onClick={() => {
                        if (window.confirm('Kya aap Cart ke sabhi items ko ek sath hatana chahte hain?')) {
                          cartItems.forEach((it) => onRemoveItem(it.productId, it.variant.id));
                        }
                      }}
                      className="text-red-600 hover:text-red-700 font-bold text-[11px] flex items-center gap-1 bg-red-50 hover:bg-red-100 px-2.5 py-1 rounded-lg border border-red-200 transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Clear All (Sare Hatao)</span>
                    </button>
                  </div>
                )}

                {cartItems.map((item) => (
                  <div
                    key={`${item.productId}-${item.variant.id}`}
                    className="relative flex items-center justify-between p-3.5 bg-slate-50 rounded-2xl border border-slate-200/80 hover:border-emerald-200 transition-all group"
                  >
                    {/* Item Remove 'X' Sign at top right corner */}
                    <button
                      onClick={() => onRemoveItem(item.productId, item.variant.id)}
                      className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center shadow-md transition-all cursor-pointer z-10"
                      title="Remove Item (Hatao)"
                    >
                      <X className="w-3.5 h-3.5 stroke-[2.5]" />
                    </button>

                    <div className="flex items-center gap-3">
                      <img
                        src={item.image}
                        alt={item.productName}
                        className="w-14 h-14 object-cover rounded-xl border border-slate-200"
                      />
                      <div>
                        <h4 className="font-bold text-slate-900 text-sm leading-tight">
                          {item.productName}
                        </h4>
                        <p className="text-xs font-semibold text-emerald-700 mt-0.5">
                          {item.variant.size} • ₹{item.variant.price} each
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-col items-end gap-2">
                      {/* Quantity Selector */}
                      <div className="flex items-center gap-1.5 bg-white border border-slate-200 rounded-lg p-0.5 shadow-xs">
                        <button
                          onClick={() => onUpdateQuantity(item.productId, item.variant.id, -1)}
                          className="p-1 hover:bg-slate-100 text-slate-600 rounded cursor-pointer"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="font-bold text-xs px-2 text-slate-900">{item.quantity}</span>
                        <button
                          onClick={() => onUpdateQuantity(item.productId, item.variant.id, 1)}
                          className="p-1 hover:bg-slate-100 text-slate-600 rounded cursor-pointer"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="font-black text-sm text-slate-900">
                          ₹{item.variant.price * item.quantity}
                        </span>
                        <button
                          onClick={() => onRemoveItem(item.productId, item.variant.id)}
                          className="text-red-500 hover:text-red-700 font-bold text-xs flex items-center gap-0.5 bg-red-50 hover:bg-red-100 px-2 py-0.5 rounded-md border border-red-200 transition-colors cursor-pointer"
                          title="Remove item"
                        >
                          <X className="w-3 h-3" />
                          <span>Hatao</span>
                        </button>
                      </div>
                    </div>
                  </div>
                ))}

                {/* Add More Items Option */}
                <div className="pt-2">
                  <button
                    onClick={() => {
                      onClose();
                      const el = document.getElementById('products-section');
                      if (el) el.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="w-full py-2.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-extrabold text-xs rounded-xl border border-emerald-300 border-dashed flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <Plus className="w-4 h-4 text-emerald-600" />
                    <span>+ Add More Items (Aur Samaan Jodein)</span>
                  </button>
                </div>
              </>
            )}
          </div>

          {/* Footer Checkout Bar */}
          {cartItems.length > 0 && (
            <div className="p-5 bg-white border-t border-slate-200 space-y-3">
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>Subtotal</span>
                  <span>₹{subtotal}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Delivery Fee (Hathras Radius)</span>
                  <span className={deliveryFee === 0 ? 'text-emerald-700 font-bold' : ''}>
                    {deliveryFee === 0 ? 'FREE' : `₹${deliveryFee}`}
                  </span>
                </div>
                <div className="flex justify-between text-base font-black text-slate-900 pt-2 border-t border-slate-100">
                  <span>Total Payable</span>
                  <span className="text-emerald-700 text-xl">₹{grandTotal}</span>
                </div>
              </div>

              <button
                onClick={() => {
                  onClose();
                  onProceedToCheckout();
                }}
                className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-sm rounded-xl shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <span>Proceed to Order (₹{grandTotal})</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="flex items-center justify-between text-[11px] text-slate-400">
                <button
                  onClick={onClearCart}
                  className="hover:text-red-500 underline cursor-pointer"
                >
                  Clear Cart
                </button>
                <span className="flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-emerald-600" />
                  Purity & Freshness Guarantee
                </span>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
