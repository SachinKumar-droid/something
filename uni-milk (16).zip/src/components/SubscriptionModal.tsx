import React, { useState } from 'react';
import { X, CalendarCheck, Sparkles, Check, Clock, Mail, ShieldCheck, User, Phone, MapPin } from 'lucide-react';
import { Product, Subscription, UserProfile } from '../types';
import { sendEmailNotification, OFFICIAL_STORE_EMAIL } from '../utils/notification';
import { saveSubscriptionToFirestore } from '../lib/firebase';

interface SubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  user: UserProfile;
  onSubscribe: (subscription: Subscription) => void;
}

const PLAN_DURATIONS: { days: 5 | 6 | 7 | 30; label: string; discount: number }[] = [
  { days: 5, label: '5 Days Trial Plan', discount: 0 },
  { days: 6, label: '6 Days Weekly Plan', discount: 2 },
  { days: 7, label: '7 Days Full Week', discount: 5 },
  { days: 30, label: '1 Month (30 Days Saver)', discount: 10 },
];

export const SubscriptionModal: React.FC<SubscriptionModalProps> = ({
  isOpen,
  onClose,
  products,
  user,
  onSubscribe,
}) => {
  if (!isOpen) return null;

  // Selected product & variant
  const [selectedProductId, setSelectedProductId] = useState<string>(products[0]?.id || 'milk-regular');
  const selectedProduct = products.find((p) => p.id === selectedProductId) || products[0];
  const [selectedVariantIndex, setSelectedVariantIndex] = useState<number>(0);
  const selectedVariant = selectedProduct.variants[selectedVariantIndex] || selectedProduct.variants[0];

  const [dailyQuantity, setDailyQuantity] = useState<number>(1);
  const [planDays, setPlanDays] = useState<5 | 6 | 7 | 30>(30);
  const [customTimeText, setCustomTimeText] = useState<string>('7:00 AM');

  // Customer Contact & Delivery Details
  const [fullName, setFullName] = useState<string>(user.name || '');
  const [phone, setPhone] = useState<string>(user.phone || '');
  const [email, setEmail] = useState<string>(user.email || '');
  const [streetAddress, setStreetAddress] = useState<string>(user.address?.streetAddress || '');
  const [area, setArea] = useState<string>(user.address?.area || 'Hathras City');
  const [landmark, setLandmark] = useState<string>(user.address?.landmark || '');

  const activePlan = PLAN_DURATIONS.find((p) => p.days === planDays) || PLAN_DURATIONS[3];
  const basePrice = selectedVariant.price * dailyQuantity * planDays;
  const discountAmount = Math.round((basePrice * activePlan.discount) / 100);
  const finalPrice = basePrice - discountAmount;

  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [successMsg, setSuccessMsg] = useState<boolean>(false);

  const handleSubscribeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!fullName.trim() || !phone.trim() || !streetAddress.trim()) {
      alert('Kripya apna Naam, Mobile Number, aur Delivery Address zaroor bharein.');
      return;
    }

    setIsSubmitting(true);

    const startDate = new Date().toLocaleDateString('en-IN');
    const endDateObj = new Date();
    endDateObj.setDate(endDateObj.getDate() + planDays);
    const endDate = endDateObj.toLocaleDateString('en-IN');

    const fullDeliveryAddress = `${streetAddress}${landmark ? ', Near ' + landmark : ''}, ${area}, Hathras`;
    const finalDeliverySlot = `Custom Time: ${customTimeText.trim() || '7:00 AM'}`;

    const emailContent = 
      `🥛 NEW DAILY MILK SUBSCRIPTION ACTIVATED - UNI MILK HATHRAS\n\n` +
      `👤 Customer Name: ${fullName}\n` +
      `📞 Mobile Number: ${phone}\n` +
      `📧 Customer Email: ${email || 'Not Provided'}\n` +
      `📍 Doorstep Delivery Address: ${fullDeliveryAddress}\n\n` +
      `📦 Subscribed Product: ${selectedProduct.name} (${selectedVariant.size})\n` +
      `🥛 Daily Quantity: ${dailyQuantity} bottle(s)/pack(s)\n` +
      `🗓️ Plan Duration: ${planDays} Days (${activePlan.label})\n` +
      `⏰ Delivery Slot: ${finalDeliverySlot}\n` +
      `💰 Total Plan Price: ₹${finalPrice}\n` +
      `📅 Start Date: ${startDate}\n` +
      `📅 End Date: ${endDate}\n` +
      `🏬 Store Email: ${OFFICIAL_STORE_EMAIL}`;

    // Dispatch Formspree email notification to OFFICIAL_STORE_EMAIL & customer email
    await sendEmailNotification(
      `New Subscription from ${fullName} (${planDays} Days Plan)`,
      emailContent,
      email || OFFICIAL_STORE_EMAIL,
      {
        type: 'New Subscription Plan',
        officialStoreEmail: OFFICIAL_STORE_EMAIL,
        customerName: fullName,
        customerPhone: phone,
        customerEmail: email || 'Not Provided',
        deliveryAddress: fullDeliveryAddress,
        product: `${selectedProduct.name} (${selectedVariant.size})`,
        dailyQuantity: `${dailyQuantity} bottle(s)/day`,
        duration: `${planDays} Days`,
        deliverySlot: finalDeliverySlot,
        totalPrice: `₹${finalPrice}`,
        startDate,
        endDate,
      }
    );

    const newSub: Subscription = {
      id: `SUB-${Date.now()}`,
      productName: selectedProduct.name,
      variantSize: selectedVariant.size,
      pricePerUnit: selectedVariant.price,
      dailyQuantity,
      planDurationDays: planDays,
      startDate,
      endDate,
      deliverySlot: finalDeliverySlot,
      status: 'Active',
      totalPrice: finalPrice,
    };

    // Save to Firestore Database
    await saveSubscriptionToFirestore({
      subscriptionNumber: newSub.id,
      customerName: fullName,
      customerPhone: phone,
      deliveryAddress: fullDeliveryAddress,
      deliverySlot: finalDeliverySlot,
      productName: selectedProduct.name,
      variantSize: selectedVariant.size,
      dailyQuantity,
      planDays,
      startDate,
      endDate,
      totalPrice: finalPrice,
      status: 'Active',
    });

    onSubscribe(newSub);
    setIsSubmitting(false);
    setSuccessMsg(true);

    setTimeout(() => {
      setSuccessMsg(false);
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl border border-slate-200 my-8">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-amber-400/20 border border-amber-300/40 flex items-center justify-center text-amber-300">
              <CalendarCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-lg">Uni Milk Daily Subscription Portal</h3>
              <p className="text-xs text-emerald-200">5-Day, 6-Day, 7-Day & 30-Day Automated Doorstep Plans</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/10 text-slate-300 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Subscription Form */}
        <form onSubmit={handleSubscribeSubmit} className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
          
          {/* Customer Details & Delivery Address */}
          <div className="bg-emerald-50/80 p-4 rounded-2xl border border-emerald-200/80 space-y-3">
            <div className="flex items-center gap-2 text-emerald-900 font-extrabold text-xs uppercase tracking-wider">
              <User className="w-4 h-4 text-emerald-600" />
              <span>Customer & Doorstep Delivery Details (Grahak Jankari)</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">
                  Full Name <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <User className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    required
                    placeholder="Enter your full name"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full pl-8 pr-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">
                  Mobile Number (WhatsApp) <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <Phone className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="tel"
                    required
                    placeholder="10-digit mobile number"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full pl-8 pr-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="sm:col-span-2">
                <label className="text-[11px] font-bold text-slate-700 block mb-1">
                  Delivery Address / House No. / Colony <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <MapPin className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    required
                    placeholder="House/Flat No., Street, Colony"
                    value={streetAddress}
                    onChange={(e) => setStreetAddress(e.target.value)}
                    className="w-full pl-8 pr-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">
                  Landmark (Optional)
                </label>
                <input
                  type="text"
                  placeholder="Near temple/school"
                  value={landmark}
                  onChange={(e) => setLandmark(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500 outline-none"
                />
              </div>
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-700 block mb-1">
                Customer Email (For confirmation & receipts)
              </label>
              <div className="relative">
                <Mail className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="email"
                  placeholder="your.email@gmail.com (Optional)"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-8 pr-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500 outline-none"
                />
              </div>
            </div>
          </div>

          {/* 1. Choose Product */}
          <div>
            <label className="text-xs font-extrabold uppercase tracking-wider text-slate-500 block mb-2">
              1. Select Product for Daily Delivery:
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {products.map((p) => {
                const isSelected = p.id === selectedProductId;
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => {
                      setSelectedProductId(p.id);
                      setSelectedVariantIndex(0);
                    }}
                    className={`p-2.5 rounded-2xl border text-left flex items-center gap-2 transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-emerald-50 border-emerald-500 ring-2 ring-emerald-500/20'
                        : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <img src={p.image} alt={p.name} className="w-9 h-9 object-cover rounded-lg" />
                    <div>
                      <span className="font-bold text-xs text-slate-900 block truncate max-w-[100px]">
                        {p.name}
                      </span>
                      <span className="text-[10px] text-emerald-700 font-semibold">
                        from ₹{p.variants[0].price}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Variant Selector */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-500 block mb-1.5">
              Select Package Size:
            </label>
            <div className="flex flex-wrap gap-2">
              {selectedProduct.variants.map((v, idx) => (
                <button
                  key={v.id}
                  type="button"
                  onClick={() => setSelectedVariantIndex(idx)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    selectedVariantIndex === idx
                      ? 'bg-emerald-600 text-white shadow-md'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200'
                  }`}
                >
                  {v.size} — ₹{v.price}
                </button>
              ))}
            </div>
          </div>

          {/* Daily Quantity Selector */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-slate-500 block mb-1.5">
                Daily Quantity needed:
              </label>
              <div className="flex items-center gap-2">
                {[1, 2, 3, 4, 5].map((q) => (
                  <button
                    key={q}
                    type="button"
                    onClick={() => setDailyQuantity(q)}
                    className={`w-10 h-10 rounded-xl font-extrabold text-sm transition-all ${
                      dailyQuantity === q
                        ? 'bg-emerald-600 text-white shadow-md'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200'
                    }`}
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block mb-1.5 flex items-center gap-1.5">
                <span>⏰ Custom Delivery Time (Apni pasand ka samay):</span>
              </label>
              <div className="bg-emerald-50/80 p-3 rounded-2xl border border-emerald-200/80 space-y-2.5">
                <input
                  type="text"
                  required
                  placeholder="Jaise: 6:30 AM, 7:15 AM, ya 6:00 PM"
                  value={customTimeText}
                  onChange={(e) => setCustomTimeText(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-emerald-300 rounded-xl text-xs font-extrabold text-slate-900 focus:ring-2 focus:ring-emerald-500 outline-none shadow-xs"
                />
                <p className="text-[10px] text-emerald-800 font-bold">Suggestions (Click to select delivery time):</p>
                <div className="flex flex-wrap gap-1.5">
                  {['6:00 AM', '6:30 AM', '7:00 AM', '7:30 AM', '8:00 AM', '5:30 PM', '6:00 PM', '6:30 PM'].map((slot) => (
                    <button
                      key={slot}
                      type="button"
                      onClick={() => setCustomTimeText(slot)}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                        customTimeText === slot
                          ? 'bg-emerald-600 text-white shadow-xs scale-105'
                          : 'bg-white text-emerald-800 border border-emerald-200 hover:bg-emerald-100'
                      }`}
                    >
                      {slot}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Plan Duration Selector (5d, 6d, 7d, 30d) */}
          <div>
            <label className="text-xs font-extrabold uppercase tracking-wider text-slate-500 block mb-2">
              Select Subscription Plan Duration:
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {PLAN_DURATIONS.map((plan) => {
                const isSelected = planDays === plan.days;
                return (
                  <button
                    key={plan.days}
                    type="button"
                    onClick={() => setPlanDays(plan.days)}
                    className={`p-3 rounded-2xl border text-center transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-emerald-600 text-white shadow-lg ring-2 ring-emerald-500/30'
                        : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <span className="font-black text-sm block">{plan.days} Days</span>
                    <span className={`text-[10px] block mt-0.5 font-bold ${isSelected ? 'text-amber-300' : 'text-emerald-700'}`}>
                      {plan.discount > 0 ? `${plan.discount}% Discount` : 'Regular Rate'}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Pricing Calculation Summary */}
          <div className="bg-slate-900 text-white p-4 rounded-2xl border border-slate-800 space-y-2 text-xs">
            <div className="flex justify-between text-slate-300">
              <span>{dailyQuantity} × {selectedProduct.name} ({selectedVariant.size}) × {planDays} days</span>
              <span>₹{basePrice}</span>
            </div>
            {discountAmount > 0 && (
              <div className="flex justify-between text-amber-300 font-bold">
                <span>Plan Discount ({activePlan.discount}%)</span>
                <span>- ₹{discountAmount}</span>
              </div>
            )}
            <div className="flex justify-between items-center pt-2 border-t border-slate-800 text-base font-black">
              <span>Total Subscription Cost:</span>
              <span className="text-2xl text-emerald-400">₹{finalPrice}</span>
            </div>
          </div>

          {/* Submit Action */}
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-4 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-base rounded-2xl shadow-xl shadow-emerald-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
          >
            {isSubmitting ? (
              <span>Activating Subscription...</span>
            ) : successMsg ? (
              <span className="flex items-center gap-2 text-amber-300">
                <Check className="w-5 h-5" />
                Subscription Activated & Email Sent!
              </span>
            ) : (
              <>
                <Sparkles className="w-5 h-5 text-amber-300" />
                <span>Activate Subscription & Get Animated Badge</span>
              </>
            )}
          </button>

          <p className="text-[11px] text-slate-400 text-center flex items-center justify-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>Pause, resume, or skip deliveries anytime directly from your profile</span>
          </p>

        </form>

      </div>
    </div>
  );
};
