import React, { useState } from 'react';
import { X, PhoneCall, MessageSquare, Calculator, Building2, Calendar, ShieldCheck } from 'lucide-react';
import { sendEmailNotification, OFFICIAL_STORE_EMAIL } from '../utils/notification';

interface BulkOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const BULK_ITEMS = [
  { name: 'Bulk Pure Milk (Liters)', unit: 'Liters', pricePerUnit: 60, minQty: 20 },
  { name: 'Bulk Fresh Paneer (Kg)', unit: 'Kg', pricePerUnit: 240, minQty: 5 },
  { name: 'Bulk Dahi Matka (Kg)', unit: 'Kg', pricePerUnit: 80, minQty: 10 },
  { name: 'Bulk Chhach Can (Liters)', unit: 'Liters', pricePerUnit: 22, minQty: 20 },
  { name: 'Bulk Desi Ghee Tin (15 Kg)', unit: 'Tin (15kg)', pricePerUnit: 11000, minQty: 1 },
];

export const BulkOrderModal: React.FC<BulkOrderModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const [selectedItemIndex, setSelectedItemIndex] = useState<number>(0);
  const [quantity, setQuantity] = useState<number>(BULK_ITEMS[0].minQty);
  const [eventDate, setEventDate] = useState<string>('');
  const [customerName, setCustomerName] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [address, setAddress] = useState<string>('');

  const currentItem = BULK_ITEMS[selectedItemIndex];
  const estimatedTotal = currentItem.pricePerUnit * quantity;

  const handleWhatsAppBulk = async () => {
    // Send Formspree email notification to sachinsingh6396312@gmail.com
    await sendEmailNotification(
      'Bulk Dairy Wholesale Inquiry',
      `Bulk Inquiry Details:\n` +
      `Item: ${currentItem.name}\n` +
      `Quantity: ${quantity} ${currentItem.unit}\n` +
      `Estimated Total: ₹${estimatedTotal}\n` +
      `Customer Name: ${customerName || 'Valued Customer'}\n` +
      `Phone: ${phone || '9837854627'}\n` +
      `Address: ${address || 'Hathras City'}\n` +
      `Event/Delivery Date: ${eventDate || 'Urgent'}`,
      OFFICIAL_STORE_EMAIL,
      {
        officialStoreEmail: OFFICIAL_STORE_EMAIL,
        item: currentItem.name,
        quantity: `${quantity} ${currentItem.unit}`,
        estimatedTotal: `₹${estimatedTotal}`,
        customerName: customerName || 'Valued Customer',
        phone: phone || '9837854627',
        address: address || 'Hathras City',
        eventDate: eventDate || 'Urgent',
      }
    );

    const message = `*BULK DAIRY ORDER INQUIRY - UNI MILK HATHRAS*%0A%0A👤 Name: ${customerName || 'Valued Customer'}%0A📞 Phone: ${phone || '9837854627'}%0A📍 Address: ${address || 'Hathras City'}%0A📅 Event/Delivery Date: ${eventDate || 'Urgent'}%0A%0A📦 *Bulk Item:* ${currentItem.name}%0A🔢 *Quantity:* ${quantity} ${currentItem.unit}%0A💰 *Estimated Total:* ₹${estimatedTotal}%0A%0A_Please confirm wholesale rates & availability!_`;

    window.open(`https://wa.me/919837854627?text=${message}`, '_blank');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white rounded-3xl w-full max-w-xl overflow-hidden shadow-2xl border border-slate-200 my-8">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-amber-900 via-amber-800 to-slate-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-amber-400/20 border border-amber-300/40 flex items-center justify-center text-amber-300">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-lg">Bulk Dairy Orders for Hathras</h3>
              <p className="text-xs text-amber-200">Wholesale rates for Halwai, Caterers, Weddings & Events</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-full hover:bg-white/10 text-slate-300 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          
          {/* Select Bulk Item */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-500 block mb-2">
              Select Bulk Product Needed:
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {BULK_ITEMS.map((item, idx) => (
                <button
                  key={item.name}
                  type="button"
                  onClick={() => {
                    setSelectedItemIndex(idx);
                    setQuantity(item.minQty);
                  }}
                  className={`p-3 rounded-2xl border text-left transition-all ${
                    selectedItemIndex === idx
                      ? 'bg-amber-50 border-amber-500 ring-2 ring-amber-500/20'
                      : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <span className="font-bold text-xs text-slate-900 block">{item.name}</span>
                  <span className="text-[11px] text-amber-800 font-semibold">
                    ₹{item.pricePerUnit} / {item.unit} (Min: {item.minQty})
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Quantity & Date Inputs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Quantity Required ({currentItem.unit}) *
              </label>
              <input
                type="number"
                min={currentItem.minQty}
                value={quantity}
                onChange={(e) => setQuantity(Math.max(currentItem.minQty, parseInt(e.target.value) || currentItem.minQty))}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-bold focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Event / Delivery Date</label>
              <input
                type="date"
                value={eventDate}
                onChange={(e) => setEventDate(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
          </div>

          {/* Customer Details */}
          <div className="space-y-3">
            <input
              type="text"
              placeholder="Your / Business Name *"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
            <input
              type="tel"
              placeholder="10-digit Phone Number *"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
            <input
              type="text"
              placeholder="Delivery Location / Venue in Hathras *"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>

          {/* Estimated Wholesale Total */}
          <div className="bg-slate-900 text-white p-4 rounded-2xl border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-xs text-slate-400 block font-semibold">Estimated Bulk Price</span>
              <span className="text-xs text-amber-300">Wholesale Special Discount Included</span>
            </div>
            <span className="text-2xl font-black text-amber-400">₹{estimatedTotal}</span>
          </div>

          {/* Action buttons */}
          <div className="grid grid-cols-2 gap-3 pt-2">
            <button
              onClick={handleWhatsAppBulk}
              className="py-3.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs sm:text-sm rounded-2xl shadow-lg flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <MessageSquare className="w-4 h-4" />
              <span>Send WhatsApp Quote</span>
            </button>

            <a
              href="tel:9837854627"
              className="py-3.5 px-4 bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs sm:text-sm rounded-2xl shadow-lg flex items-center justify-center gap-2 transition-all cursor-pointer text-center"
            >
              <PhoneCall className="w-4 h-4" />
              <span>Call 9837854627</span>
            </a>
          </div>

        </div>

      </div>
    </div>
  );
};
