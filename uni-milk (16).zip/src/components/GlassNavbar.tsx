import React from 'react';
import { MapPin, ShoppingBag, User, PackageCheck, CalendarCheck, Sparkles, PhoneCall, ShieldCheck } from 'lucide-react';
import { Address, UserProfile } from '../types';

interface GlassNavbarProps {
  currentAddress: Address;
  user: UserProfile;
  activeOrdersCount: number;
  hasActiveSubscription: boolean;
  onOpenAddress: () => void;
  onOpenOrders: () => void;
  onOpenProfile: () => void;
  onOpenBulkOrder: () => void;
  onOpenSubscription: () => void;
  onOpenAdmin: () => void;
  onOpenAuth: () => void;
}

export const GlassNavbar: React.FC<GlassNavbarProps> = ({
  currentAddress,
  user,
  activeOrdersCount,
  hasActiveSubscription,
  onOpenAddress,
  onOpenOrders,
  onOpenProfile,
  onOpenBulkOrder,
  onOpenSubscription,
  onOpenAdmin,
  onOpenAuth,
}) => {
  return (
    <nav className="sticky top-2 z-30 mx-2 sm:mx-6 my-2 backdrop-blur-md bg-white/50 border border-white/60 rounded-2xl shadow-sm transition-all">
      <div className="max-w-7xl mx-auto px-2 sm:px-4">
        <div className="flex items-center justify-between h-14 overflow-x-auto no-scrollbar gap-2 sm:gap-4">
          
          {/* 1. Address Section */}
          <button
            onClick={onOpenAddress}
            className="flex items-center gap-2 px-3 py-1.5 rounded-2xl bg-white/60 hover:bg-white/80 border border-white/80 text-emerald-950 transition-all shrink-0 group cursor-pointer shadow-xs"
            title="Update Delivery Address"
          >
            <div className="w-7 h-7 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform shadow-xs">
              <MapPin className="w-3.5 h-3.5" />
            </div>
            <div className="text-left leading-tight">
              <span className="text-[10px] uppercase font-bold text-emerald-800 tracking-wider block">Deliver To</span>
              <span className="text-xs font-semibold text-slate-800 max-w-[130px] sm:max-w-[180px] truncate block">
                {currentAddress.area || 'Kanchan Nagar'}, {currentAddress.city || 'Hathras'}
              </span>
            </div>
          </button>

          {/* Navigation Items Center */}
          <div className="flex items-center gap-1 sm:gap-2 shrink-0">
            
            {/* 2. My Orders */}
            <button
              onClick={onOpenOrders}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-slate-800 hover:text-emerald-800 hover:bg-white/60 font-semibold text-xs sm:text-sm transition-all cursor-pointer relative"
            >
              <PackageCheck className="w-4 h-4 text-emerald-700" />
              <span>My Orders</span>
              {activeOrdersCount > 0 && (
                <span className="bg-emerald-600 text-white font-bold text-[10px] px-1.5 py-0.2 rounded-full animate-pulse">
                  {activeOrdersCount}
                </span>
              )}
            </button>

            {/* 4. Bulk Order */}
            <button
              onClick={onOpenBulkOrder}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-slate-800 hover:text-emerald-800 hover:bg-white/60 font-semibold text-xs sm:text-sm transition-all cursor-pointer"
            >
              <PhoneCall className="w-4 h-4 text-amber-700" />
              <span>Bulk Order</span>
            </button>

            {/* 5. Subscription Portal */}
            <button
              onClick={onOpenSubscription}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm transition-all shadow-sm border border-emerald-500/30 hover:scale-[1.02] cursor-pointer"
            >
              <CalendarCheck className="w-4 h-4 text-amber-300" />
              <span>Subscription</span>
              {hasActiveSubscription && (
                <span className="bg-amber-400 text-emerald-950 font-black text-[9px] px-1.5 py-0.5 rounded-full uppercase tracking-widest flex items-center gap-0.5">
                  <Sparkles className="w-2.5 h-2.5" />
                  Active
                </span>
              )}
            </button>
          </div>

          {/* 3. My Profile Right Corner */}
          <div className="shrink-0 flex items-center">
            {user.isLoggedIn ? (
              <button
                onClick={onOpenProfile}
                className="flex items-center gap-2 px-3 py-1.5 rounded-2xl bg-white/70 hover:bg-white/90 text-slate-900 border border-white/80 transition-all text-xs font-semibold cursor-pointer shadow-xs"
              >
                <div className="w-6 h-6 rounded-full bg-emerald-600 text-white font-black flex items-center justify-center text-[11px] uppercase">
                  {user.name ? user.name.charAt(0) : 'U'}
                </div>
                <span className="hidden sm:inline max-w-[90px] truncate">{user.name.split(' ')[0]}</span>
                {hasActiveSubscription && (
                  <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" title="Active Subscription Member" />
                )}
              </button>
            ) : (
              <button
                onClick={onOpenAuth}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
              >
                <User className="w-3.5 h-3.5" />
                <span>My Profile</span>
              </button>
            )}
          </div>

        </div>
      </div>
    </nav>
  );
};
