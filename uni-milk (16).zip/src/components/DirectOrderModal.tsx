import React, { useState } from 'react';
import { X, CheckCircle, MessageSquare, PhoneCall, ShieldCheck, MapPin, User, Mail, Sparkles, Send, Clock, Sun } from 'lucide-react';
import { Address, CartItem, Product, ProductVariant, UserProfile } from '../types';
import { sendEmailNotification, DEFAULT_RECIPIENT_EMAIL, OFFICIAL_STORE_EMAIL } from '../utils/notification';

interface DirectOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  directProduct?: { product: Product; variant: ProductVariant } | null;
  cartItems?: CartItem[];
  user: UserProfile;
  onOrderPlaced: (orderData: {
    items: CartItem[];
    address: Address;
    paymentMethod: 'Cash on Delivery' | 'Online on Delivery';
    deliverySlot: string;
    customerName: string;
    customerEmail: string;
    customerPhone: string;
  }) => void;
}

export const DirectOrderModal: React.FC<DirectOrderModalProps> = ({
  isOpen,
  onClose,
  directProduct,
  cartItems = [],
  user,
  onOrderPlaced,
}) => {
  if (!isOpen) return null;

  // Prepare order items
  const orderItems: CartItem[] = directProduct
    ? [
        {
          productId: directProduct.product.id,
          productName: directProduct.product.name,
          category: directProduct.product.category,
          subCategory: directProduct.product.subCategory,
          variant: directProduct.variant,
          quantity: 1,
          image: directProduct.product.image,
        },
      ]
    : cartItems;

  const subtotal = orderItems.reduce((acc, item) => acc + item.variant.price * item.quantity, 0);

  // Form states with auto-fill from user profile
  const [fullName, setFullName] = useState(user.name || '');
  const [email, setEmail] = useState(user.email || '');
  const [phone, setPhone] = useState(user.phone || '');
  const [area, setArea] = useState(user.address?.area || 'Kanchan Nagar');
  const [streetAddress, setStreetAddress] = useState(user.address?.streetAddress || '');
  const [landmark, setLandmark] = useState(user.address?.landmark || '');
  const [paymentMethod, setPaymentMethod] = useState<'Cash on Delivery' | 'Online on Delivery'>('Cash on Delivery');
  
  // Custom Delivery Time Selector States
  const [selectedHour, setSelectedHour] = useState<string>('7');
  const [selectedMinute, setSelectedMinute] = useState<string>('00');
  const [selectedAmpm, setSelectedAmpm] = useState<'AM' | 'PM'>('AM');

  // Calculate delivery fee & night charges
  const getDeliveryCalculation = () => {
    let hourNum = parseInt(selectedHour, 10);
    if (isNaN(hourNum) || hourNum < 1) hourNum = 7;
    if (hourNum > 12) hourNum = 12;

    let hour24 = hourNum % 12;
    if (selectedAmpm === 'PM') hour24 += 12;

    // Night time: 9 PM (21:00) or later, OR before 5 AM (05:00)
    const isNight = hour24 >= 21 || hour24 < 5;
    
    // Day delivery fee: ₹10 for orders < ₹200, ₹0 for orders >= ₹200
    // Night delivery fee: Flat ₹30 (day delivery charge is removed for night orders)
    const totalDeliveryFee = isNight ? 30 : (subtotal >= 200 || subtotal === 0 ? 0 : 10);
    const grandTotal = subtotal + totalDeliveryFee;

    const activeDeliverySlot = `Custom Time (${hourNum}:${selectedMinute} ${selectedAmpm})`;

    return {
      hourNum,
      minuteStr: selectedMinute,
      ampm: selectedAmpm,
      isNight,
      totalDeliveryFee,
      grandTotal,
      activeDeliverySlot,
    };
  };

  const calc = getDeliveryCalculation();
  const activeDeliverySlot = calc.activeDeliverySlot;
  const grandTotal = calc.grandTotal;
  
  const [formspreeStatus, setFormspreeStatus] = useState<'idle' | 'submitting' | 'success'>('idle');

  const handleStandardSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormspreeStatus('submitting');

    // Dispatch Formspree email notification to official store email uni.milkofficial2426@gmail.com
    const recipient = OFFICIAL_STORE_EMAIL;
    const itemsSummary = orderItems
      .map((i) => `${i.productName} (${i.variant.size}) x${i.quantity} = ₹${i.variant.price * i.quantity}`)
      .join('\n');

    const deliveryFeeLabel = calc.isNight 
      ? '₹30 (Night Delivery Charge)' 
      : (calc.totalDeliveryFee === 0 ? '₹0 (FREE Delivery)' : '₹10 (Day Delivery Charge)');

    const emailContent = 
      `🥛 NEW ORDER - UNI MILK HATHRAS\n\n` +
      `👤 Customer Name: ${fullName}\n` +
      `📞 Phone: ${phone}\n` +
      `📧 Customer Email: ${email || 'Not Provided'}\n` +
      `⏰ Selected Delivery Time Slot: ${activeDeliverySlot}\n` +
      `📍 Delivery Address: ${streetAddress}, ${landmark ? landmark + ', ' : ''}${area}, Hathras\n\n` +
      `🛒 Ordered Items:\n${itemsSummary}\n\n` +
      `💵 Subtotal: ₹${subtotal}\n` +
      `🚚 Delivery Fee: ${deliveryFeeLabel}\n` +
      `💰 Grand Total: ₹${grandTotal}\n` +
      `💳 Payment Method: ${paymentMethod}\n` +
      `🏬 Store Email: ${OFFICIAL_STORE_EMAIL}`;

    // Send email dispatch
    await sendEmailNotification(
      `New Order from ${fullName} (Slot: ${activeDeliverySlot})`,
      emailContent,
      email || recipient,
      {
        officialStoreEmail: OFFICIAL_STORE_EMAIL,
        customerName: fullName,
        customerEmail: email || 'Not Provided',
        customerPhone: phone,
        deliverySlot: activeDeliverySlot,
        deliveryAddress: `${streetAddress}, ${landmark ? landmark + ', ' : ''}${area}, Hathras`,
        itemsOrdered: itemsSummary,
        subtotal: `₹${subtotal}`,
        deliveryFee: deliveryFeeLabel,
        grandTotal: `₹${grandTotal}`,
        paymentMethod,
      }
    );

    setFormspreeStatus('success');

    setTimeout(() => {
      onOrderPlaced({
        items: orderItems,
        address: {
          fullName,
          phone,
          area,
          streetAddress,
          landmark,
          city: 'Hathras',
          pincode: '204101',
        },
        paymentMethod,
        deliverySlot: activeDeliverySlot,
        customerName: fullName,
        customerEmail: email,
        customerPhone: phone,
      });
      setFormspreeStatus('idle');
      onClose();
    }, 1200);
  };

  const handleWhatsAppOrder = async () => {
    const itemsText = orderItems
      .map((i) => `• ${i.productName} (${i.variant.size}) x${i.quantity} = ₹${i.variant.price * i.quantity}`)
      .join('%0A');

    const addressText = `${streetAddress || 'Kanchan Nagar'}, ${landmark ? landmark + ', ' : ''}${area}, Hathras`;

    const message = `*NEW ORDER - UNI MILK HATHRAS*%0A%0A*Customer Details:*%0A👤 Name: ${fullName || 'Valued Customer'}%0A📞 Phone: ${phone || '9837854627'}%0A📍 Address: ${addressText}%0A⏰ *Delivery Time Slot:* ${activeDeliverySlot}%0A%0A*Items Ordered:*%0A${itemsText}%0A%0A💰 *Total Amount:* ₹${grandTotal} (${paymentMethod})%0A%0A_Please confirm my delivery for slot ${activeDeliverySlot}!_`;

    window.open(`https://wa.me/919837854627?text=${message}`, '_blank');

    // Also send email alert to uni.milkofficial2426@gmail.com
    const itemsSummary = orderItems
      .map((i) => `${i.productName} (${i.variant.size}) x${i.quantity} = ₹${i.variant.price * i.quantity}`)
      .join('\n');

    const deliveryFeeLabel = calc.isNight 
      ? '₹30 (Night Delivery Charge)' 
      : (calc.totalDeliveryFee === 0 ? '₹0 (FREE Delivery)' : '₹10 (Day Delivery Charge)');

    const emailContent = 
      `🥛 NEW WHATSAPP ORDER - UNI MILK HATHRAS\n\n` +
      `👤 Customer Name: ${fullName || 'Valued Customer'}\n` +
      `📞 Phone: ${phone || '9837854627'}\n` +
      `📧 Customer Email: ${email || 'Not Provided'}\n` +
      `⏰ Selected Delivery Time Slot: ${activeDeliverySlot}\n` +
      `📍 Delivery Address: ${addressText}\n\n` +
      `🛒 Ordered Items:\n${itemsSummary}\n\n` +
      `💵 Subtotal: ₹${subtotal}\n` +
      `🚚 Delivery Fee: ${deliveryFeeLabel}\n` +
      `💰 Grand Total: ₹${grandTotal}\n` +
      `💳 Payment Method: ${paymentMethod}`;

    sendEmailNotification(
      `WhatsApp Order from ${fullName || 'Valued Customer'} (${activeDeliverySlot})`,
      emailContent,
      email || OFFICIAL_STORE_EMAIL,
      {
        officialStoreEmail: OFFICIAL_STORE_EMAIL,
        customerName: fullName || 'Valued Customer',
        customerPhone: phone || '9837854627',
        deliverySlot: activeDeliverySlot,
        deliveryAddress: addressText,
        itemsOrdered: itemsSummary,
        grandTotal: `₹${grandTotal}`,
        paymentMethod,
      }
    );

    onOrderPlaced({
      items: orderItems,
      address: {
        fullName: fullName || 'Valued Customer',
        phone: phone || '9837854627',
        area: area || 'Kanchan Nagar',
        streetAddress: streetAddress || 'Kanchan Nagar Main St',
        landmark: landmark || '',
        city: 'Hathras',
        pincode: '204101',
      },
      paymentMethod,
      deliverySlot: activeDeliverySlot,
      customerName: fullName || 'Valued Customer',
      customerEmail: email || 'uni.milkofficial2426@gmail.com',
      customerPhone: phone || '9837854627',
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl border border-slate-200 my-8">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-800 via-teal-800 to-slate-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-amber-300">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold">Complete Your Uni Milk Order</h3>
              <p className="text-xs text-emerald-200">100% Fresh Dairy Delivered to Your Doorstep in Hathras</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-300 hover:text-white hover:bg-white/10 rounded-full transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <form onSubmit={handleStandardSubmit} className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
          
          {/* Order Summary Box */}
          <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200">
            <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-500 mb-3">
              Order Summary ({orderItems.length} {orderItems.length === 1 ? 'item' : 'items'})
            </h4>
            <div className="space-y-2 divide-y divide-slate-200/80">
              {orderItems.map((item, idx) => (
                <div key={idx} className="pt-2 first:pt-0 flex items-center justify-between text-sm">
                  <div className="flex items-center gap-3">
                    <img src={item.image} alt={item.productName} className="w-10 h-10 object-cover rounded-lg" />
                    <div>
                      <p className="font-bold text-slate-900">{item.productName}</p>
                      <p className="text-xs text-slate-500">{item.variant.size} × {item.quantity}</p>
                    </div>
                  </div>
                  <span className="font-extrabold text-slate-900">₹{item.variant.price * item.quantity}</span>
                </div>
              ))}
            </div>

            <div className="mt-4 pt-3 border-t border-slate-200 space-y-1.5 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal</span>
                <span className="font-bold text-slate-900">₹{subtotal}</span>
              </div>

              {!calc.isNight ? (
                <div className="flex justify-between text-slate-600">
                  <span>Day Delivery Charge (Orders under ₹200)</span>
                  <span className={calc.totalDeliveryFee === 0 ? 'text-emerald-700 font-bold' : 'font-bold text-slate-900'}>
                    {calc.totalDeliveryFee === 0 ? 'FREE (Order ≥ ₹200)' : `₹${calc.totalDeliveryFee}`}
                  </span>
                </div>
              ) : (
                <div className="flex justify-between text-indigo-950 font-extrabold bg-indigo-50 px-2.5 py-1.5 rounded-lg border border-indigo-200">
                  <span className="flex items-center gap-1 text-indigo-900">
                    <span>🌙</span> Night Delivery Charge (9 PM to 5 AM)
                  </span>
                  <span className="text-indigo-950">₹30</span>
                </div>
              )}

              <div className="flex justify-between items-center text-sm font-black text-slate-900 pt-2 border-t border-slate-200">
                <span>Total Payable</span>
                <span className="text-2xl font-black text-emerald-700">₹{grandTotal}</span>
              </div>
            </div>
          </div>

          {/* Custom Delivery Time Selector */}
          <div className="bg-amber-50/70 p-4 rounded-2xl border border-amber-200 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-black uppercase tracking-wider text-amber-950 flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-amber-600" />
                <span>Select Custom Delivery Time *</span>
              </label>
              <span className="text-[10px] font-bold bg-amber-200 text-amber-950 px-2 py-0.5 rounded-full">
                Custom Time Only
              </span>
            </div>

            <div className="bg-white p-3.5 rounded-xl border border-amber-300 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-3">
              {/* Hour and Minute Pickers */}
              <div className="flex items-center gap-2 w-full sm:w-auto">
                <div className="flex flex-col">
                  <span className="text-[10px] font-bold text-slate-500 mb-0.5">Hour</span>
                  <select
                    value={selectedHour}
                    onChange={(e) => setSelectedHour(e.target.value)}
                    className="px-3 py-2 bg-amber-50/60 border border-amber-300 rounded-xl text-sm font-black text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 cursor-pointer"
                  >
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((h) => (
                      <option key={h} value={h}>{h < 10 ? `0${h}` : h}</option>
                    ))}
                  </select>
                </div>

                <span className="text-xl font-black text-amber-900 mt-3">:</span>

                <div className="flex flex-col">
                  <span className="text-[10px] font-bold text-slate-500 mb-0.5">Minute</span>
                  <select
                    value={selectedMinute}
                    onChange={(e) => setSelectedMinute(e.target.value)}
                    className="px-3 py-2 bg-amber-50/60 border border-amber-300 rounded-xl text-sm font-black text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 cursor-pointer"
                  >
                    {['00', '15', '30', '45'].map((m) => (
                      <option key={m} value={m}>{m}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* AM / PM Toggle directly on the right */}
              <div className="flex flex-col w-full sm:w-auto">
                <span className="text-[10px] font-bold text-slate-500 mb-0.5">AM / PM Option</span>
                <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-300">
                  <button
                    type="button"
                    onClick={() => setSelectedAmpm('AM')}
                    className={`flex-1 sm:flex-initial px-4 py-1.5 rounded-lg font-black text-xs transition-all cursor-pointer flex items-center justify-center gap-1 ${
                      selectedAmpm === 'AM'
                        ? 'bg-amber-500 text-white shadow-md'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <span>🌅</span>
                    <span>AM</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedAmpm('PM')}
                    className={`flex-1 sm:flex-initial px-4 py-1.5 rounded-lg font-black text-xs transition-all cursor-pointer flex items-center justify-center gap-1 ${
                      selectedAmpm === 'PM'
                        ? 'bg-indigo-950 text-amber-300 shadow-md'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <span>🌙</span>
                    <span>PM</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Night Charge / Day Delivery Information Banner */}
            {calc.isNight ? (
              <div className="p-2.5 rounded-xl bg-indigo-950 text-amber-200 border border-indigo-800 flex items-center justify-between text-xs font-bold">
                <span className="flex items-center gap-1.5">
                  <span className="text-base">🌙</span>
                  <span>Night Delivery Time Selected (9 PM - 5 AM)</span>
                </span>
                <span className="bg-amber-400 text-indigo-950 px-2.5 py-0.5 rounded-lg font-black text-xs shadow-xs">
                  ₹30 Night Delivery Charge
                </span>
              </div>
            ) : (
              <div className="p-2.5 rounded-xl bg-emerald-50 text-emerald-950 border border-emerald-200 flex items-center justify-between text-xs font-bold">
                <span className="flex items-center gap-1.5">
                  <span className="text-base">☀️</span>
                  <span>Day Delivery Time (5 AM - 9 PM)</span>
                </span>
                <span className="text-emerald-800 font-extrabold">
                  {calc.totalDeliveryFee === 0 ? 'FREE Delivery (Orders ≥ ₹200)' : '₹10 Delivery Fee (Orders < ₹200)'}
                </span>
              </div>
            )}

            <p className="text-[11px] text-amber-900 font-semibold">
              ⚡ Selected Custom Time: <strong className="font-black text-amber-950">{activeDeliverySlot}</strong>
            </p>
          </div>

          {/* User Address & Contact Inputs */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                <User className="w-4 h-4 text-emerald-600" />
                <span>Customer & Delivery Details</span>
              </h4>
              {user.isLoggedIn && (
                <span className="text-xs text-emerald-700 bg-emerald-100 font-bold px-2.5 py-0.5 rounded-full">
                  Auto-filled from Profile
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Full Name *</label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Enter your name"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Phone Number *</label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="10-digit mobile number"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="text-xs font-semibold text-slate-700 block mb-1">Email Address (Order copy sent here & to Uni Milk)</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your.email@example.com"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="text-xs font-semibold text-slate-700 block mb-1">Street Address / House No. *</label>
                <input
                  type="text"
                  required
                  value={streetAddress}
                  onChange={(e) => setStreetAddress(e.target.value)}
                  placeholder="House/Flat No., Colony name"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Area / Colony in Hathras *</label>
                <input
                  type="text"
                  required
                  value={area}
                  onChange={(e) => setArea(e.target.value)}
                  placeholder="e.g. Kanchan Nagar, Sasni Gate"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Landmark (Optional)</label>
                <input
                  type="text"
                  value={landmark}
                  onChange={(e) => setLandmark(e.target.value)}
                  placeholder="e.g. Near Shiv Temple"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>
          </div>

          {/* Payment Method Selector (Cash on Delivery & Online on Delivery Only) */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-500 block mb-2">
              Payment Method:
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setPaymentMethod('Cash on Delivery')}
                className={`p-3.5 rounded-xl border text-sm font-bold text-center transition-all cursor-pointer flex items-center justify-center gap-2 ${
                  paymentMethod === 'Cash on Delivery'
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-800 ring-2 ring-emerald-500/20'
                    : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                <span>💵</span>
                <span>Cash on Delivery</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMethod('Online on Delivery')}
                className={`p-3.5 rounded-xl border text-sm font-bold text-center transition-all cursor-pointer flex items-center justify-center gap-2 ${
                  paymentMethod === 'Online on Delivery'
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-800 ring-2 ring-emerald-500/20'
                    : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                <span>💳</span>
                <span>Online on Delivery</span>
              </button>
            </div>
          </div>

          {/* Actions: Website Order, WhatsApp Order, Call Order */}
          <div className="pt-2 border-t border-slate-200 space-y-3">
            
            {/* Primary Direct Order button */}
            <button
              type="submit"
              disabled={formspreeStatus === 'submitting'}
              className="w-full py-4 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-base rounded-2xl shadow-xl shadow-emerald-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              {formspreeStatus === 'submitting' ? (
                <span>Sending Order Details to Uni Milk...</span>
              ) : formspreeStatus === 'success' ? (
                <span className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-amber-300" />
                  Order Sent Successfully!
                </span>
              ) : (
                <>
                  <Send className="w-5 h-5" />
                  <span>Confirm & Place Order (₹{grandTotal})</span>
                </>
              )}
            </button>

            <div className="grid grid-cols-2 gap-3">
              {/* WhatsApp Order Button */}
              <button
                type="button"
                onClick={handleWhatsAppOrder}
                className="py-3 px-4 bg-emerald-900 hover:bg-emerald-950 text-emerald-300 font-bold text-xs sm:text-sm rounded-xl border border-emerald-700 flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <MessageSquare className="w-4 h-4 text-emerald-400" />
                <span>Order on WhatsApp</span>
              </button>

              {/* Call Order Button */}
              <a
                href="tel:9837854627"
                className="py-3 px-4 bg-slate-900 hover:bg-slate-950 text-amber-300 font-bold text-xs sm:text-sm rounded-xl border border-slate-800 flex items-center justify-center gap-2 transition-all cursor-pointer text-center"
              >
                <PhoneCall className="w-4 h-4 text-amber-400" />
                <span>Call 9837854627</span>
              </a>
            </div>

            <p className="text-[11px] text-slate-500 text-center flex items-center justify-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Orders dispatched for slot: <strong>{activeDeliverySlot}</strong> in Hathras</span>
            </p>
          </div>

        </form>
      </div>
    </div>
  );
};
