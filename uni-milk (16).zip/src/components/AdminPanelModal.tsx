import React, { useState } from 'react';
import {
  X,
  Store,
  Clock,
  CheckCircle2,
  Truck,
  XCircle,
  Phone,
  MessageSquare,
  MapPin,
  Calendar,
  ShoppingBag,
  RefreshCw,
  Search,
  Check,
  AlertCircle,
  Mail,
  SlidersHorizontal,
  DollarSign,
  Trash2,
} from 'lucide-react';
import {
  FirestoreOrder,
  FirestoreSubscription,
  updateOrderStatusInFirestore,
  updateSubscriptionStatusInFirestore,
  deleteOrderFromFirestore,
  deleteSubscriptionFromFirestore,
} from '../lib/firebase';
import { sendEmailNotification, OFFICIAL_STORE_EMAIL } from '../utils/notification';

interface AdminPanelModalProps {
  isOpen: boolean;
  onClose: () => void;
  orders: FirestoreOrder[];
  subscriptions: FirestoreSubscription[];
  onDeleteOrder?: (orderId?: string, orderNum?: string) => void;
  onDeleteSubscription?: (subId?: string, subNum?: string) => void;
}

export const AdminPanelModal: React.FC<AdminPanelModalProps> = ({
  isOpen,
  onClose,
  orders,
  subscriptions,
  onDeleteOrder,
  onDeleteSubscription,
}) => {
  const [activeTab, setActiveTab] = useState<'orders' | 'subscriptions'>('orders');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  if (!isOpen) return null;

  // Calculate statistics
  const pendingOrders = orders.filter((o) => o.status === 'Pending' || o.status === 'Order Placed');
  const onTheWayOrders = orders.filter((o) => o.status === 'Accepted (On The Way)');
  const totalRevenue = orders
    .filter((o) => o.status !== 'Cancelled')
    .reduce((acc, o) => acc + (o.totalAmount || 0), 0);

  const activeSubs = subscriptions.filter((s) => s.status === 'Active');

  // Filtered Orders
  const filteredOrders = orders.filter((o) => {
    const matchesStatus =
      statusFilter === 'all'
        ? true
        : statusFilter === 'pending'
        ? o.status === 'Pending' || o.status === 'Order Placed'
        : statusFilter === 'ontheway'
        ? o.status === 'Accepted (On The Way)'
        : statusFilter === 'delivered'
        ? o.status === 'Delivered'
        : statusFilter === 'cancelled'
        ? o.status === 'Cancelled'
        : true;

    const query = searchQuery.toLowerCase().trim();
    const matchesSearch =
      !query ||
      (o.customerName && o.customerName.toLowerCase().includes(query)) ||
      (o.customerPhone && o.customerPhone.includes(query)) ||
      (o.orderNumber && o.orderNumber.toLowerCase().includes(query)) ||
      (o.deliveryAddress && o.deliveryAddress.toLowerCase().includes(query));

    return matchesStatus && matchesSearch;
  });

  // Filtered Subscriptions
  const filteredSubs = subscriptions.filter((s) => {
    const query = searchQuery.toLowerCase().trim();
    return (
      !query ||
      (s.customerName && s.customerName.toLowerCase().includes(query)) ||
      (s.customerPhone && s.customerPhone.includes(query)) ||
      (s.productName && s.productName.toLowerCase().includes(query))
    );
  });

  // Handle Accept Order & Mark On The Way
  const handleAcceptOrder = async (order: FirestoreOrder) => {
    if (!order.id) return;
    setActionLoading(order.id);

    // 1. Update status in Firestore database
    const success = await updateOrderStatusInFirestore(order.id, 'Accepted (On The Way)');

    if (success) {
      // 2. Send email notification to customer & store
      const itemsListStr = order.items
        ?.map((i) => `${i.name} (${i.size}) x${i.quantity} = ₹${i.price * i.quantity}`)
        .join('\n') || '';

      const emailContent =
        `🎉 YOUR UNI MILK ORDER HAS BEEN ACCEPTED & IS ON THE WAY!\n\n` +
        `Order Number: #${order.orderNumber}\n` +
        `Customer Name: ${order.customerName}\n` +
        `Delivery Slot: ${order.deliverySlot}\n` +
        `Delivery Address: ${order.deliveryAddress}\n\n` +
        `🛒 Items:\n${itemsListStr}\n\n` +
        `💰 Total Amount: ₹${order.totalAmount}\n` +
        `💳 Payment Method: ${order.paymentMethod}\n\n` +
        `🚚 Our Hathras delivery partner Ramesh is on the way to deliver fresh dairy to your doorstep!`;

      await sendEmailNotification(
        `🎉 Order #${order.orderNumber} Accepted & On The Way! - Uni Milk`,
        emailContent,
        OFFICIAL_STORE_EMAIL,
        {
          officialStoreEmail: OFFICIAL_STORE_EMAIL,
          customerName: order.customerName,
          customerPhone: order.customerPhone,
          orderNumber: order.orderNumber,
          status: 'Accepted (On The Way)',
          deliverySlot: order.deliverySlot,
        }
      );
    }

    setActionLoading(null);
  };

  // Handle Change Order Status
  const handleUpdateStatus = async (orderId: string, status: FirestoreOrder['status']) => {
    setActionLoading(orderId);
    await updateOrderStatusInFirestore(orderId, status);
    setActionLoading(null);
  };

  // Handle Change Subscription Status
  const handleUpdateSubStatus = async (subId: string, status: FirestoreSubscription['status']) => {
    setActionLoading(subId);
    await updateSubscriptionStatusInFirestore(subId, status);
    setActionLoading(null);
  };

  // Handle Delete Order from Database
  const handleDeleteOrder = async (orderId: string | undefined, orderNum: string) => {
    const loadingKey = orderId || orderNum;
    setActionLoading(loadingKey);

    // 1. Instantly trigger parent state update / optimistic removal
    if (onDeleteOrder) {
      onDeleteOrder(orderId, orderNum);
    }

    // 2. Delete from Firestore database
    await deleteOrderFromFirestore(orderId, orderNum);
    setActionLoading(null);
  };

  // Handle Delete Subscription from Database
  const handleDeleteSubscription = async (subId: string | undefined, subNum: string) => {
    const loadingKey = subId || subNum;
    setActionLoading(loadingKey);

    // 1. Instantly trigger parent state update / optimistic removal
    if (onDeleteSubscription) {
      onDeleteSubscription(subId, subNum);
    }

    // 2. Delete from Firestore database
    await deleteSubscriptionFromFirestore(subId, subNum);
    setActionLoading(null);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4">
      <div className="bg-white w-full max-w-6xl rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-900 p-4 sm:p-6 text-white flex items-center justify-between shrink-0 border-b border-emerald-700/50">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-amber-300 font-bold shadow-inner">
              <Store className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-black tracking-tight text-white">
                  Store Admin & Manager Panel
                </h2>
                <span className="bg-emerald-500/30 text-emerald-200 border border-emerald-400/30 text-[10px] font-extrabold px-2 py-0.5 rounded-full flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  Live Sync
                </span>
              </div>
              <p className="text-xs text-emerald-200/90 font-medium">
                Uni Milk Hathras — Real-time Firestore Database & Email Integration
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Stats Row */}
        <div className="bg-emerald-50/60 p-4 border-b border-emerald-100 grid grid-cols-2 sm:grid-cols-4 gap-3 shrink-0">
          <div className="bg-white p-3.5 rounded-2xl border border-emerald-100 shadow-xs">
            <div className="flex items-center justify-between text-amber-600 mb-1">
              <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-500">Pending Orders</span>
              <Clock className="w-4 h-4" />
            </div>
            <p className="text-2xl font-black text-slate-900">{pendingOrders.length}</p>
            <p className="text-[10px] text-amber-700 font-semibold">Needs Acceptance</p>
          </div>

          <div className="bg-white p-3.5 rounded-2xl border border-emerald-100 shadow-xs">
            <div className="flex items-center justify-between text-blue-600 mb-1">
              <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-500">On The Way</span>
              <Truck className="w-4 h-4" />
            </div>
            <p className="text-2xl font-black text-slate-900">{onTheWayOrders.length}</p>
            <p className="text-[10px] text-blue-700 font-semibold">Active Deliveries</p>
          </div>

          <div className="bg-white p-3.5 rounded-2xl border border-emerald-100 shadow-xs">
            <div className="flex items-center justify-between text-emerald-600 mb-1">
              <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-500">Active Subs</span>
              <Calendar className="w-4 h-4" />
            </div>
            <p className="text-2xl font-black text-slate-900">{activeSubs.length}</p>
            <p className="text-[10px] text-emerald-700 font-semibold">Daily Deliveries</p>
          </div>

          <div className="bg-white p-3.5 rounded-2xl border border-emerald-100 shadow-xs">
            <div className="flex items-center justify-between text-emerald-800 mb-1">
              <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-500">Total Revenue</span>
              <DollarSign className="w-4 h-4" />
            </div>
            <p className="text-2xl font-black text-emerald-900">₹{totalRevenue}</p>
            <p className="text-[10px] text-emerald-600 font-semibold">Store Orders Total</p>
          </div>
        </div>

        {/* Tab & Search Navigation */}
        <div className="p-3 sm:p-4 bg-white border-b border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-2xl w-full sm:w-auto">
            <button
              onClick={() => setActiveTab('orders')}
              className={`flex-1 sm:flex-none px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                activeTab === 'orders'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>Store Orders ({orders.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('subscriptions')}
              className={`flex-1 sm:flex-none px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                activeTab === 'subscriptions'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>Daily Subscriptions ({subscriptions.length})</span>
            </button>
          </div>

          {/* Search bar & Filters */}
          <div className="flex items-center gap-2 w-full sm:w-auto">
            {activeTab === 'orders' && (
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 outline-none"
              >
                <option value="all">All Status</option>
                <option value="pending">Pending Only</option>
                <option value="ontheway">On The Way Only</option>
                <option value="delivered">Delivered</option>
                <option value="cancelled">Cancelled</option>
              </select>
            )}

            <div className="relative flex-1 sm:w-64">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search name, phone, order #..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 placeholder-slate-400 outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-6 space-y-4 bg-slate-50/50">
          {activeTab === 'orders' ? (
            filteredOrders.length === 0 ? (
              <div className="py-16 text-center space-y-3">
                <div className="w-16 h-16 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <h3 className="text-base font-extrabold text-slate-800">No Orders Found in Database</h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  When customers place an order, it will appear here in real-time.
                </p>
              </div>
            ) : (
              filteredOrders.map((order) => {
                const isPending = order.status === 'Pending' || order.status === 'Order Placed';
                const isOnTheWay = order.status === 'Accepted (On The Way)';
                const isDelivered = order.status === 'Delivered';
                const isCancelled = order.status === 'Cancelled';

                return (
                  <div
                    key={order.id || order.orderNumber}
                    className={`bg-white rounded-2xl border transition-all p-4 sm:p-5 shadow-xs space-y-4 ${
                      isPending
                        ? 'border-amber-300 ring-2 ring-amber-400/20'
                        : isOnTheWay
                        ? 'border-blue-300 ring-2 ring-blue-400/20'
                        : 'border-slate-200'
                    }`}
                  >
                    {/* Top Order Row */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                      <div className="flex items-center gap-3">
                        <span className="font-black text-sm text-slate-900 bg-slate-100 px-3 py-1 rounded-xl">
                          #{order.orderNumber}
                        </span>
                        <span
                          className={`text-xs font-black px-3 py-1 rounded-full flex items-center gap-1.5 ${
                            isPending
                              ? 'bg-amber-100 text-amber-900 border border-amber-300'
                              : isOnTheWay
                              ? 'bg-blue-100 text-blue-900 border border-blue-300 animate-pulse'
                              : isDelivered
                              ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                              : 'bg-red-100 text-red-900 border border-red-300'
                          }`}
                        >
                          {isPending && <Clock className="w-3.5 h-3.5" />}
                          {isOnTheWay && <Truck className="w-3.5 h-3.5" />}
                          {isDelivered && <CheckCircle2 className="w-3.5 h-3.5" />}
                          {isCancelled && <XCircle className="w-3.5 h-3.5" />}
                          <span>{order.status}</span>
                        </span>
                      </div>

                      <div className="text-xs text-slate-500 font-semibold flex items-center gap-2">
                        <span>Payment: <strong className="text-slate-800">{order.paymentMethod}</strong></span>
                      </div>
                    </div>

                    {/* Customer Info & Address */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50/80 p-3.5 rounded-2xl border border-slate-200/80 text-xs">
                      <div className="space-y-1.5">
                        <p className="font-extrabold text-slate-900 text-sm flex items-center gap-1.5">
                          <span>👤 {order.customerName}</span>
                        </p>
                        <div className="flex items-center gap-3 pt-1">
                          <a
                            href={`tel:${order.customerPhone}`}
                            className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-2.5 py-1 rounded-lg flex items-center gap-1"
                          >
                            <Phone className="w-3 h-3" />
                            <span>Call ({order.customerPhone})</span>
                          </a>
                          <a
                            href={`https://wa.me/91${order.customerPhone.replace(/[^0-9]/g, '')}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="bg-emerald-500 hover:bg-emerald-600 text-white font-bold px-2.5 py-1 rounded-lg flex items-center gap-1"
                          >
                            <MessageSquare className="w-3 h-3" />
                            <span>WhatsApp</span>
                          </a>
                        </div>
                      </div>

                      <div className="space-y-1">
                        <p className="text-slate-700 font-bold flex items-start gap-1">
                          <MapPin className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                          <span>{order.deliveryAddress}</span>
                        </p>
                        <p className="text-emerald-900 font-bold flex items-center gap-1 bg-emerald-100/60 px-2 py-0.5 rounded-md w-fit">
                          <Clock className="w-3 h-3 text-emerald-700" />
                          <span>Delivery Slot: {order.deliverySlot}</span>
                        </p>
                      </div>
                    </div>

                    {/* Ordered Items Breakdown */}
                    <div className="space-y-2">
                      <p className="text-xs font-extrabold text-slate-700 uppercase tracking-wider">
                        Ordered Items ({order.items?.length || 0}):
                      </p>
                      <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden bg-white">
                        {order.items?.map((item, idx) => (
                          <div key={idx} className="p-2.5 flex items-center justify-between text-xs">
                            <span className="font-bold text-slate-800">
                              {item.name} <span className="text-slate-500 font-normal">({item.size})</span>
                            </span>
                            <div className="flex items-center gap-4">
                              <span className="text-slate-600">Qty: <strong>{item.quantity}</strong></span>
                              <span className="font-black text-slate-900">₹{item.price * item.quantity}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Order Total & Admin Action Buttons */}
                    <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 border-t border-slate-100">
                      <div className="text-slate-900 font-black text-base">
                        Total Amount: <span className="text-emerald-700 text-xl">₹{order.totalAmount}</span>
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center gap-2 w-full sm:w-auto">
                        {isPending && (
                          <button
                            disabled={actionLoading === order.id}
                            onClick={() => handleAcceptOrder(order)}
                            className="flex-1 sm:flex-none px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-extrabold text-xs rounded-xl shadow-md shadow-emerald-600/30 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                          >
                            {actionLoading === order.id ? (
                              <RefreshCw className="w-4 h-4 animate-spin" />
                            ) : (
                              <>
                                <Check className="w-4 h-4 text-emerald-200 stroke-[3]" />
                                <span>Accept Order (Mark On The Way)</span>
                              </>
                            )}
                          </button>
                        )}

                        {isOnTheWay && (
                          <button
                            disabled={actionLoading === order.id}
                            onClick={() => order.id && handleUpdateStatus(order.id, 'Delivered')}
                            className="flex-1 sm:flex-none px-4 py-2.5 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-extrabold text-xs rounded-xl shadow-md shadow-blue-600/30 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                          >
                            <CheckCircle2 className="w-4 h-4" />
                            <span>Mark Delivered</span>
                          </button>
                        )}

                        {!isCancelled && !isDelivered && (
                          <button
                            disabled={actionLoading === order.id}
                            onClick={() => order.id && handleUpdateStatus(order.id, 'Cancelled')}
                            className="px-3 py-2.5 bg-red-50 hover:bg-red-100 text-red-700 font-bold text-xs rounded-xl border border-red-200 transition-colors cursor-pointer"
                          >
                            Cancel
                          </button>
                        )}

                        {/* Delete Order from Database */}
                        <button
                          disabled={actionLoading === (order.id || order.orderNumber)}
                          onClick={() => handleDeleteOrder(order.id, order.orderNumber)}
                          className="px-3 py-2.5 bg-rose-600 hover:bg-rose-700 active:scale-95 text-white font-extrabold text-xs rounded-xl shadow-xs flex items-center gap-1 transition-all cursor-pointer"
                          title="Database se Order Permanent Delete karein"
                        >
                          {actionLoading === (order.id || order.orderNumber) ? (
                            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          ) : (
                            <>
                              <Trash2 className="w-3.5 h-3.5" />
                              <span>Delete</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
            )
          ) : (
            /* Subscriptions Tab */
            filteredSubs.length === 0 ? (
              <div className="py-16 text-center space-y-3">
                <div className="w-16 h-16 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
                  <Calendar className="w-8 h-8" />
                </div>
                <h3 className="text-base font-extrabold text-slate-800">No Subscriptions Found</h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  Customer daily milk subscriptions will show up here.
                </p>
              </div>
            ) : (
              filteredSubs.map((sub) => (
                <div
                  key={sub.id || sub.subscriptionNumber}
                  className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 shadow-xs space-y-3"
                >
                  <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                    <span className="font-black text-sm text-slate-900 bg-emerald-50 text-emerald-900 px-3 py-1 rounded-xl">
                      #{sub.subscriptionNumber}
                    </span>
                    <span
                      className={`text-xs font-extrabold px-3 py-1 rounded-full ${
                        sub.status === 'Active'
                          ? 'bg-emerald-100 text-emerald-800'
                          : sub.status === 'Paused'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {sub.status}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs bg-slate-50 p-3 rounded-xl">
                    <div>
                      <p className="font-bold text-slate-900">👤 Customer: {sub.customerName}</p>
                      <p className="text-slate-600">📞 Phone: {sub.customerPhone}</p>
                      <p className="text-slate-600">📍 Address: {sub.deliveryAddress}</p>
                    </div>
                    <div>
                      <p className="font-bold text-emerald-900">🥛 Product: {sub.productName} ({sub.variantSize})</p>
                      <p className="text-slate-700">📦 Daily Qty: {sub.dailyQuantity} pack(s)/day</p>
                      <p className="text-slate-700">⏰ Delivery Time: {sub.deliverySlot}</p>
                      <p className="text-slate-700">🗓️ Duration: {sub.planDays} Days ({sub.startDate} to {sub.endDate})</p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <span className="font-black text-slate-900 text-sm">
                      Total Plan Price: <strong className="text-emerald-700">₹{sub.totalPrice}</strong>
                    </span>

                    <div className="flex items-center gap-2">
                      {sub.status !== 'Active' && (
                        <button
                          onClick={() => sub.id && handleUpdateSubStatus(sub.id, 'Active')}
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg"
                        >
                          Set Active
                        </button>
                      )}
                      {sub.status === 'Active' && (
                        <button
                          onClick={() => sub.id && handleUpdateSubStatus(sub.id, 'Paused')}
                          className="px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs rounded-lg"
                        >
                          Pause
                        </button>
                      )}
                      <button
                        disabled={actionLoading === (sub.id || sub.subscriptionNumber)}
                        onClick={() => handleDeleteSubscription(sub.id, sub.subscriptionNumber)}
                        className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-lg flex items-center gap-1 cursor-pointer"
                        title="Delete Subscription from Database"
                      >
                        {actionLoading === (sub.id || sub.subscriptionNumber) ? (
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        ) : (
                          <>
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Delete</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )
          )}
        </div>
      </div>
    </div>
  );
};
