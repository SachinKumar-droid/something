import React, { useState } from 'react';
import { Phone, Mail, MapPin, MessageSquare, Instagram, ShieldCheck, Heart, Code2, X, ChevronRight, FileText, Info, Lock, KeyRound, AlertTriangle } from 'lucide-react';
import { UNI_MILK_LOGO_URL } from '../config/logo';

interface FooterProps {
  onOpenAdmin?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenAdmin }) => {
  const [activeModal, setActiveModal] = useState<'about' | 'terms' | 'privacy' | 'contact' | null>(null);

  // 3-Click Address Secret Admin Trigger
  const [clickCount, setClickCount] = useState(0);
  const [clickTimer, setClickTimer] = useState<any>(null);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [passwordError, setPasswordError] = useState('');

  const handleAddressClick = () => {
    setClickCount((prev) => {
      const newCount = prev + 1;
      if (newCount >= 3) {
        // 3 clicks reached! Open Password Prompt
        setShowPasswordModal(true);
        setPasswordInput('');
        setPasswordError('');
        return 0;
      }
      return newCount;
    });

    if (clickTimer) clearTimeout(clickTimer);
    const timer = setTimeout(() => {
      setClickCount(0);
    }, 1500); // Reset click counter after 1.5 seconds if 3 clicks not completed
    setClickTimer(timer);
  };

  const handleVerifyPassword = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanPass = passwordInput.trim();
    // Accept valid password: DREAMUNISH@2426
    if (cleanPass === 'DREAMUNISH@2426' || cleanPass.toUpperCase() === 'DREAMUNISH@2426') {
      setShowPasswordModal(false);
      setPasswordInput('');
      setPasswordError('');
      if (onOpenAdmin) {
        onOpenAdmin();
      }
    } else {
      setPasswordError('❌ Galat Password! Admin Panel nahi khulega.');
    }
  };

  return (
    <footer className="bg-[#2D5A27] text-emerald-100 border-t border-emerald-800/40 text-xs sm:text-sm">
      
      {/* Main Footer Links & Info */}
      <div className="max-w-7xl mx-auto px-4 py-12 grid grid-cols-1 md:grid-cols-4 gap-8">
        
        {/* Brand Column */}
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-white p-1 border-2 border-amber-300 shadow-md overflow-hidden shrink-0 flex items-center justify-center">
              <img
                src={UNI_MILK_LOGO_URL}
                alt="Uni Milk Official Logo"
                className="w-full h-full object-contain"
                referrerPolicy="no-referrer"
              />
            </div>
            <span className="text-2xl font-black text-white tracking-tight font-serif">
              Uni <span className="text-amber-300">Milk</span>
            </span>
          </div>
          <p className="text-emerald-100/80 text-xs leading-relaxed">
            India's most loved online milk and dairy products delivery service in Hathras city. Delivering purity, freshness, and trust every single morning.
          </p>

          <div className="pt-2 flex items-center gap-3">
            {/* Instagram Link */}
            <a
              href="https://instagram.com/uni.milk_official"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2.5 bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/20 text-white rounded-2xl transition-all flex items-center gap-1.5 font-bold text-xs"
              title="Instagram @uni.milk_official"
            >
              <Instagram className="w-4 h-4 text-pink-300" />
              <span>@uni.milk_official</span>
            </a>
          </div>
        </div>

        {/* Quick Links Column */}
        <div className="space-y-3">
          <h4 className="text-white font-extrabold uppercase text-xs tracking-wider">Quick Information</h4>
          <ul className="space-y-2 text-xs">
            <li>
              <button
                onClick={() => setActiveModal('about')}
                className="hover:text-emerald-400 transition-colors flex items-center gap-1 text-slate-400 cursor-pointer"
              >
                <ChevronRight className="w-3 h-3 text-emerald-500" /> About Us
              </button>
            </li>
            <li>
              <button
                onClick={() => setActiveModal('terms')}
                className="hover:text-emerald-400 transition-colors flex items-center gap-1 text-slate-400 cursor-pointer"
              >
                <ChevronRight className="w-3 h-3 text-emerald-500" /> Terms & Conditions
              </button>
            </li>
            <li>
              <button
                onClick={() => setActiveModal('privacy')}
                className="hover:text-emerald-400 transition-colors flex items-center gap-1 text-slate-400 cursor-pointer"
              >
                <ChevronRight className="w-3 h-3 text-emerald-500" /> Privacy Policy
              </button>
            </li>
            <li>
              <button
                onClick={() => setActiveModal('contact')}
                className="hover:text-emerald-400 transition-colors flex items-center gap-1 text-slate-400 cursor-pointer"
              >
                <ChevronRight className="w-3 h-3 text-emerald-500" /> Contact & Support
              </button>
            </li>
          </ul>
        </div>

        {/* Official Contact Column */}
        <div className="space-y-3">
          <h4 className="text-white font-extrabold uppercase text-xs tracking-wider">Shop & Contact Details</h4>
          <ul className="space-y-2 text-xs text-slate-400">
            <li
              onClick={handleAddressClick}
              className="flex items-start gap-2 cursor-pointer group hover:bg-emerald-900/50 p-1.5 rounded-xl transition-all select-none border border-transparent hover:border-emerald-700/50"
              title="Click 3 times to open Admin Panel"
            >
              <MapPin className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5 group-hover:scale-110 transition-transform" />
              <span className="group-hover:text-amber-200 transition-colors">
                Kanchan Nagar, Hathras, Uttar Pradesh (10-12 km Radius)
              </span>
            </li>
            <li className="flex items-center gap-2">
              <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
              <a href="tel:9837854627" className="hover:text-emerald-300 font-bold">
                9837854627
              </a>
            </li>
            <li className="flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-emerald-400 shrink-0" />
              <a
                href="https://wa.me/919837854627"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-emerald-300 font-bold"
              >
                WhatsApp: 9837854627
              </a>
            </li>
            <li className="flex items-center gap-2">
              <Mail className="w-4 h-4 text-emerald-400 shrink-0" />
              <a href="mailto:uni.milkofficial2426@gmail.com" className="hover:text-emerald-300">
                uni.milkofficial2426@gmail.com
              </a>
            </li>
          </ul>
        </div>

        {/* Developer Contact Section (Required by User Prompt) */}
        <div className="bg-slate-900/90 p-5 rounded-2xl border border-slate-800 space-y-3">
          <div className="flex items-center gap-2 text-amber-400 font-extrabold uppercase text-xs tracking-wider">
            <Code2 className="w-4 h-4" />
            <span>Developer Contact</span>
          </div>
          <p className="text-[11px] text-slate-400">
            For technical updates or app inquiries, connect with developer directly:
          </p>
          <div className="space-y-2 text-xs">
            {/* Direct Call Click */}
            <a
              href="tel:7983048450"
              className="flex items-center gap-2 p-2 rounded-xl bg-slate-950 border border-slate-800 text-emerald-300 font-bold hover:bg-slate-800 transition-all"
            >
              <Phone className="w-3.5 h-3.5 text-emerald-400" />
              <span>Call: 7983048450</span>
            </a>

            {/* Direct Message Click */}
            <a
              href="https://wa.me/917983048450?text=Hello%20Developer,%20inquiry%20regarding%20Uni%20Milk%20Website"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 p-2 rounded-xl bg-slate-950 border border-slate-800 text-amber-300 font-bold hover:bg-slate-800 transition-all"
            >
              <MessageSquare className="w-3.5 h-3.5 text-amber-400" />
              <span>Message: 7983048450</span>
            </a>
          </div>
        </div>

      </div>

      {/* Bottom Bar */}
      <div className="border-t border-slate-900 bg-slate-950 py-4 px-4 text-center text-xs text-slate-500">
        <p className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>© {new Date().getFullYear()} Uni Milk. All Rights Reserved. Kanchan Nagar, Hathras.</span>
          <span className="flex items-center gap-1 text-emerald-400 font-semibold">
            WE BELIEVE IN YOUR HEALTH, OUR CONCERN <Heart className="w-3 h-3 text-red-500 fill-red-500" />
          </span>
        </p>
      </div>

      {/* Modal Dialogs for About Us, Terms, Privacy, Contact */}
      {activeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white text-slate-900 rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl border border-slate-200 my-8">
            
            <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
              <h3 className="font-extrabold text-lg flex items-center gap-2">
                {activeModal === 'about' && <Info className="w-5 h-5 text-emerald-400" />}
                {activeModal === 'terms' && <FileText className="w-5 h-5 text-amber-400" />}
                {activeModal === 'privacy' && <ShieldCheck className="w-5 h-5 text-teal-400" />}
                {activeModal === 'contact' && <Phone className="w-5 h-5 text-emerald-400" />}
                <span className="capitalize">{activeModal} Section</span>
              </h3>
              <button
                onClick={() => setActiveModal(null)}
                className="p-1 rounded-full hover:bg-white/10 text-slate-300"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto text-xs sm:text-sm text-slate-700 leading-relaxed">
              
              {/* ABOUT US EXACT TEXT FROM USER PROMPT */}
              {activeModal === 'about' && (
                <div className="space-y-3">
                  <p className="text-base font-bold text-slate-900">
                    Uni Milk — India's Most Loved Online Milk & Dairy Platform
                  </p>
                  <p>
                    Uni milk is India's most loved online milk and it's dairy products shopping platform. Our app is changing the way customers approach their daily essentials.
                  </p>
                  <p>
                    You can now shop online for fresh milk, curd(dahee), paneer, chhach and desi ghee. Imagine if you could get anything delivered to you in minutes. Milk for your morning tea and coffee. The perfect ghee and other products for your health and everything on time when you need them.
                  </p>
                  <p>
                    Our superfast delivery service aims to help consumers in India, save time and fulfil their needs in a way that is frictionless. We will make healthy high quality and life improving products available to everyone instantly. So that people can have time for the things that matter to them.
                  </p>
                  <p className="font-bold text-emerald-800 bg-emerald-50 p-3 rounded-xl border border-emerald-200 uppercase">
                    Uni milk delivers trust and guarantee of purity and freshness, you are valuable for us and WE BELIEVE IN YOUR HEALTH , OUR CONCERN.
                  </p>
                </div>
              )}

              {/* TERMS & CONDITIONS EXACT 10 POINTS FROM USER PROMPT */}
              {activeModal === 'terms' && (
                <div className="space-y-3">
                  <h4 className="font-extrabold text-slate-900 text-sm">Terms & Conditions of Service</h4>
                  <ul className="space-y-2.5 list-disc pl-5">
                    <li><strong>Product Quality:</strong> All milk and dairy products are prepared and packed under hygienic conditions and are quality checked before delivery.</li>
                    <li><strong>Fresh Products:</strong> Milk and dairy products are perishable. Customers should refrigerate products immediately after delivery and consume them before the expiry date.</li>
                    <li><strong>Orders & Delivery:</strong> Orders are confirmed only after acceptance by Uni Milk. Delivery times may vary due to weather, traffic, or other unavoidable circumstances.</li>
                    <li><strong>Payment Policy:</strong> Payment must be made as per the agreed method (Cash, UPI, or Bank Transfer). Delayed payments may result in suspension of future deliveries.</li>
                    <li><strong>Cancellation Policy:</strong> Order cancellations must be made before the daily cut-off time. Orders cancelled after dispatch may not be eligible for a refund.</li>
                    <li><strong>Return & Refund:</strong> Returns are accepted only if the product is damaged, leaking, spoiled, or delivered incorrectly. Complaints should be reported within 24 hours with photos, if possible.</li>
                    <li><strong>Pricing:</strong> Prices are subject to change without prior notice due to market conditions, raw milk costs, or government regulations.</li>
                    <li><strong>Customer Responsibility:</strong> Customers must provide the correct delivery address and contact details. Uni Milk is not responsible for delays caused by incorrect information.</li>
                    <li><strong>Food Safety:</strong> Products should be stored as instructed. Uni Milk is not responsible for spoilage caused by improper storage after delivery.</li>
                    <li><strong>Legal Jurisdiction:</strong> These terms are governed by the laws of India. Any disputes will be subject to the jurisdiction of the local courts where Uni Milk operates.</li>
                  </ul>
                </div>
              )}

              {/* PRIVACY POLICY */}
              {activeModal === 'privacy' && (
                <div className="space-y-3">
                  <h4 className="font-extrabold text-slate-900 text-sm">Privacy & Data Security Policy</h4>
                  <p>
                    At Uni Milk, we respect your privacy. All customer data, phone numbers, delivery addresses, and subscription details are stored locally on your browser and processed securely.
                  </p>
                  <p>
                    We never sell or share your personal contact details with third-party advertisers. Information collected is exclusively used to fulfill your fresh milk deliveries in Hathras city.
                  </p>
                </div>
              )}

              {/* CONTACT & SUPPORT */}
              {activeModal === 'contact' && (
                <div className="space-y-3">
                  <h4 className="font-extrabold text-slate-900 text-sm">Contact Uni Milk Official Support</h4>
                  <p><strong>Shop Address:</strong> Kanchan Nagar, Hathras, Uttar Pradesh</p>
                  <p><strong>Official Phone:</strong> <a href="tel:9837854627" className="text-emerald-700 font-bold">9837854627</a></p>
                  <p><strong>WhatsApp Support:</strong> <a href="https://wa.me/919837854627" className="text-emerald-700 font-bold">9837854627</a></p>
                  <p><strong>Official Email:</strong> <a href="mailto:uni.milkofficial2426@gmail.com" className="text-emerald-700 font-bold">uni.milkofficial2426@gmail.com</a></p>
                  <p><strong>Instagram:</strong> <a href="https://instagram.com/uni.milk_official" className="text-emerald-700 font-bold">@uni.milk_official</a></p>
                </div>
              )}

              <div className="pt-4 border-t border-slate-200 text-right">
                <button
                  onClick={() => setActiveModal(null)}
                  className="px-5 py-2 bg-slate-900 text-white font-bold text-xs rounded-xl"
                >
                  Close
                </button>
              </div>

            </div>

          </div>
        </div>
      )}

      {/* Secret Admin Password Dialog */}
      {showPasswordModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
          <div className="bg-white text-slate-900 rounded-3xl w-full max-w-md overflow-hidden shadow-2xl border border-slate-200 animate-in fade-in zoom-in duration-200">
            {/* Header */}
            <div className="bg-gradient-to-r from-emerald-900 to-slate-900 text-white p-5 flex items-center justify-between border-b border-emerald-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-amber-400 text-emerald-950 flex items-center justify-center font-black shadow-inner">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-black text-base text-white">Store Admin Password</h3>
                  <p className="text-xs text-emerald-200">Uni Milk Hathras Secret Security Portal</p>
                </div>
              </div>

              <button
                onClick={() => setShowPasswordModal(false)}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleVerifyPassword} className="p-6 space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-extrabold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                  <KeyRound className="w-4 h-4 text-emerald-600" />
                  <span>Admin Access Pin / Password:</span>
                </label>
                <div className="relative">
                  <input
                    type="password"
                    autoFocus
                    placeholder="Enter Store Admin Password..."
                    value={passwordInput}
                    onChange={(e) => {
                      setPasswordInput(e.target.value);
                      setPasswordError('');
                    }}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-300 rounded-2xl text-sm font-mono font-bold text-slate-900 outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition-all placeholder-slate-400"
                  />
                </div>
              </div>

              {passwordError && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-2xl text-xs font-bold text-red-700 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
                  <span>{passwordError}</span>
                </div>
              )}

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowPasswordModal(false)}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl cursor-pointer transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-md shadow-emerald-600/30 flex items-center gap-1.5 cursor-pointer transition-all active:scale-95"
                >
                  <Lock className="w-4 h-4" />
                  <span>Enter Admin Panel</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </footer>
  );
};
