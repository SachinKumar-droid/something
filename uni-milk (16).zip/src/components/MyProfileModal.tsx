import React, { useState } from 'react';
import { X, User, Mail, Phone, MapPin, Sparkles, CalendarCheck, LogOut, ShieldCheck, Pause, Play, Bell, PackageCheck, Edit2, Save } from 'lucide-react';
import { UserProfile, Address } from '../types';

interface MyProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  onLogout: () => void;
  onOpenSubscription: () => void;
  onOpenOrders: () => void;
  onToggleSubscriptionPause: (subId: string) => void;
  onUpdateUserAddress?: (address: Address) => void;
}

export const MyProfileModal: React.FC<MyProfileModalProps> = ({
  isOpen,
  onClose,
  user,
  onLogout,
  onOpenSubscription,
  onOpenOrders,
  onToggleSubscriptionPause,
  onUpdateUserAddress,
}) => {
  if (!isOpen) return null;

  const [isEditingAddress, setIsEditingAddress] = useState(false);
  const [street, setStreet] = useState(user.address?.streetAddress || 'Kanchan Nagar Main St');
  const [area, setArea] = useState(user.address?.area || 'Kanchan Nagar');
  const [phone, setPhone] = useState(user.phone || '9837854627');

  const activeSubs = user.subscriptions?.filter((s) => s.status !== 'Completed') || [];
  const hasActiveSub = activeSubs.length > 0;

  const handleSaveAddress = () => {
    if (onUpdateUserAddress) {
      onUpdateUserAddress({
        fullName: user.name || 'Uni Milk Member',
        phone,
        area,
        streetAddress: street,
        landmark: 'Near Water Tank',
        city: 'Hathras',
        pincode: '204101',
      });
    }
    setIsEditingAddress(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-white rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl border border-white/60 my-auto">
        
        {/* Header */}
        <div className="bg-[#2D5A27] text-white p-5 sm:p-6 relative border-b border-white/10">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 text-white hover:bg-white/10 rounded-full transition-all cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-4">
            {/* Avatar Circle */}
            <div className="relative">
              <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-amber-400 text-emerald-950 font-black text-2xl flex items-center justify-center shadow-md border-2 border-white">
                {user.name ? user.name.charAt(0) : 'U'}
              </div>
              {hasActiveSub && (
                <div className="absolute -bottom-1 -right-1 bg-amber-400 text-emerald-950 p-1 rounded-full shadow-md animate-bounce">
                  <Sparkles className="w-3.5 h-3.5" />
                </div>
              )}
            </div>

            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-lg sm:text-xl font-black text-white">{user.name || 'Uni Milk Member'}</h3>
                
                {hasActiveSub && (
                  <span className="bg-amber-400 text-emerald-950 font-black text-[10px] px-2.5 py-0.5 rounded-full uppercase tracking-wider shadow-sm flex items-center gap-1 border border-amber-300">
                    <Sparkles className="w-3 h-3 text-emerald-950" />
                    SUBSCRIBED MEMBER
                  </span>
                )}
              </div>

              <p className="text-xs text-emerald-100 mt-1 flex items-center gap-1">
                <Mail className="w-3.5 h-3.5 text-amber-300" />
                <span>{user.email || 'uni.milkofficial2426@gmail.com'}</span>
              </p>
            </div>
          </div>
        </div>

        {/* Profile Content */}
        <div className="p-5 sm:p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          
          {/* Quick Orders Button */}
          <button
            onClick={() => {
              onClose();
              onOpenOrders();
            }}
            className="w-full p-3.5 bg-emerald-50 hover:bg-emerald-100/80 border border-emerald-200 rounded-2xl flex items-center justify-between transition-all cursor-pointer group"
          >
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-emerald-600 text-white rounded-xl shadow-xs">
                <PackageCheck className="w-5 h-5" />
              </div>
              <div className="text-left">
                <p className="font-extrabold text-slate-900 text-xs sm:text-sm">My Orders & Order History</p>
                <p className="text-[11px] text-slate-600">Track current deliveries or view past orders</p>
              </div>
            </div>
            <span className="text-xs font-bold text-emerald-700 group-hover:translate-x-1 transition-transform">
              View All →
            </span>
          </button>

          {/* User Contact & Address Info */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/80 space-y-3 text-xs sm:text-sm">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Contact & Saved Delivery Address
              </h4>
              {!isEditingAddress ? (
                <button
                  onClick={() => setIsEditingAddress(true)}
                  className="text-xs font-bold text-emerald-700 flex items-center gap-1 hover:underline cursor-pointer"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                  <span>Edit Address</span>
                </button>
              ) : (
                <button
                  onClick={handleSaveAddress}
                  className="text-xs font-extrabold text-white bg-emerald-600 px-3 py-1 rounded-lg flex items-center gap-1 shadow-xs cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save</span>
                </button>
              )}
            </div>

            {!isEditingAddress ? (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-slate-700">
                  <span className="flex items-center gap-2 text-slate-500">
                    <Phone className="w-4 h-4 text-emerald-600" /> Phone:
                  </span>
                  <span className="font-bold text-slate-900">{phone}</span>
                </div>
                <div className="flex items-center justify-between text-slate-700">
                  <span className="flex items-center gap-2 text-slate-500">
                    <MapPin className="w-4 h-4 text-emerald-600" /> Saved Address:
                  </span>
                  <span className="font-bold text-slate-900 text-right max-w-[220px] truncate">
                    {street}, {area}, Hathras
                  </span>
                </div>
                <div className="flex items-center justify-between text-slate-700">
                  <span className="flex items-center gap-2 text-slate-500">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" /> Auth Method:
                  </span>
                  <span className="font-bold text-slate-900 uppercase text-xs bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-md">
                    {user.authMethod === 'google' ? 'Google Account' : 'Email & Password'}
                  </span>
                </div>
              </div>
            ) : (
              <div className="space-y-2.5 pt-1">
                <div>
                  <label className="text-[11px] font-bold text-slate-600 block mb-1">Phone Number</label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-600 block mb-1">Area / Colony in Hathras</label>
                  <input
                    type="text"
                    value={area}
                    onChange={(e) => setArea(e.target.value)}
                    className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-600 block mb-1">Street / House Address</label>
                  <input
                    type="text"
                    value={street}
                    onChange={(e) => setStreet(e.target.value)}
                    className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Active Subscriptions Section */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs sm:text-sm font-extrabold text-slate-900 flex items-center gap-1.5">
                <CalendarCheck className="w-4 h-4 text-emerald-600" />
                <span>My Active Daily Subscriptions</span>
              </h4>
              <button
                onClick={() => {
                  onClose();
                  onOpenSubscription();
                }}
                className="text-xs font-bold text-emerald-700 hover:underline cursor-pointer"
              >
                + Add New Plan
              </button>
            </div>

            {activeSubs.length === 0 ? (
              <div className="bg-amber-50/60 p-4 rounded-2xl border border-amber-200/80 text-center space-y-2">
                <p className="text-xs text-amber-900 font-semibold">No active milk subscription found.</p>
                <button
                  onClick={() => {
                    onClose();
                    onOpenSubscription();
                  }}
                  className="px-4 py-2 bg-emerald-600 text-white font-bold text-xs rounded-xl shadow-md cursor-pointer"
                >
                  Subscribe for 5, 6, 7 or 30 Days
                </button>
              </div>
            ) : (
              activeSubs.map((sub) => (
                <div
                  key={sub.id}
                  className="p-4 bg-gradient-to-r from-emerald-50 via-teal-50 to-white rounded-2xl border border-emerald-200 shadow-xs space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h5 className="font-extrabold text-slate-900 text-xs sm:text-sm">{sub.productName}</h5>
                      <p className="text-xs text-emerald-700 font-semibold">
                        {sub.variantSize} × {sub.dailyQuantity} bottle daily • {sub.planDurationDays} Days Plan
                      </p>
                    </div>
                    <span
                      className={`text-[10px] font-extrabold px-2.5 py-1 rounded-full uppercase ${
                        sub.status === 'Active'
                          ? 'bg-emerald-600 text-white animate-pulse'
                          : 'bg-amber-100 text-amber-900'
                      }`}
                    >
                      {sub.status}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-xs text-slate-600 pt-2 border-t border-emerald-100">
                    <span>Slot: {sub.deliverySlot}</span>
                    <button
                      onClick={() => onToggleSubscriptionPause(sub.id)}
                      className="flex items-center gap-1 text-slate-700 hover:text-emerald-800 font-bold bg-white px-2.5 py-1 rounded-lg border border-slate-200 cursor-pointer"
                    >
                      {sub.status === 'Active' ? (
                        <>
                          <Pause className="w-3 h-3 text-amber-600" />
                          <span>Pause Daily</span>
                        </>
                      ) : (
                        <>
                          <Play className="w-3 h-3 text-emerald-600" />
                          <span>Resume Daily</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Email Notification Notice with Test Email Trigger */}
          <div className="bg-[#2D5A27] text-white p-3.5 sm:p-4 rounded-2xl border border-white/20 space-y-2 text-xs">
            <div className="flex items-start gap-3">
              <Bell className="w-5 h-5 text-amber-300 shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="text-emerald-100 leading-relaxed">
                  Instant Formspree email confirmations & delivery logs are sent to official store <strong className="text-amber-300 font-mono">{user.email || 'uni.milkofficial2426@gmail.com'}</strong>.
                </p>
                <div className="mt-2 flex items-center justify-between">
                  <button
                    onClick={async () => {
                      const { sendEmailNotification } = await import('../utils/notification');
                      await sendEmailNotification(
                        'Test Email Notification',
                        'Hello! This is a test email from Uni Milk Hathras confirming your Formspree email notification delivery is active.',
                        user.email || 'uni.milkofficial2426@gmail.com'
                      );
                      alert(`Test email dispatched to ${user.email || 'uni.milkofficial2426@gmail.com'}! Please check your inbox / spam folder.`);
                    }}
                    className="px-3 py-1.5 bg-amber-400 hover:bg-amber-300 text-emerald-950 font-extrabold text-[11px] rounded-xl shadow-xs transition-all cursor-pointer flex items-center gap-1.5"
                  >
                    <Mail className="w-3.5 h-3.5" />
                    <span>Send Test Email To My Inbox</span>
                  </button>
                  <span className="text-[10px] text-emerald-200">Instant Delivery</span>
                </div>
              </div>
            </div>
          </div>

          {/* Logout Option */}
          <div className="pt-2 border-t border-slate-200">
            <button
              onClick={() => {
                onLogout();
                onClose();
              }}
              className="w-full py-3 bg-red-50 hover:bg-red-100 text-red-600 font-extrabold text-xs sm:text-sm rounded-2xl border border-red-200 flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              <span>Log Out of Profile</span>
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};

