// Push & Email Notification helper utility for Uni Milk website

export type NotificationPermissionState = 'default' | 'granted' | 'denied';

export const OFFICIAL_STORE_EMAIL = 'uni.milkofficial2426@gmail.com';
export const DEFAULT_RECIPIENT_EMAIL = 'uni.milkofficial2426@gmail.com';

export const checkNotificationSupport = (): boolean => {
  return typeof window !== 'undefined' && 'Notification' in window;
};

export const getNotificationPermission = (): NotificationPermissionState => {
  if (!checkNotificationSupport()) return 'denied';
  return Notification.permission as NotificationPermissionState;
};

export const requestNotificationPermission = async (): Promise<boolean> => {
  if (!checkNotificationSupport()) {
    console.warn('Browser does not support notifications.');
    return false;
  }

  try {
    const permission = await Notification.requestPermission();
    return permission === 'granted';
  } catch (err) {
    console.error('Error requesting notification permission:', err);
    return false;
  }
};

/**
 * Formspree Email Dispatch Handler
 * Sends real email notifications to sachinsingh6396312@gmail.com or configured user email
 */
export const sendEmailNotification = async (
  subject: string,
  message: string,
  recipientEmail: string = DEFAULT_RECIPIENT_EMAIL,
  details?: Record<string, any>
): Promise<boolean> => {
  const formspreeKey = typeof localStorage !== 'undefined' 
    ? localStorage.getItem('uni_milk_formspree_key') || 'mlgqvwzd'
    : 'mlgqvwzd';

  const envEndpoint = typeof import.meta !== 'undefined' ? (import.meta as any).env?.VITE_FORMSPREE_ENDPOINT : undefined;
  const formspreeEndpoint = envEndpoint || `https://formspree.io/f/${formspreeKey}`;

  try {
    const response = await fetch(formspreeEndpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      body: JSON.stringify({
        email: OFFICIAL_STORE_EMAIL,
        _to: OFFICIAL_STORE_EMAIL,
        storeEmail: OFFICIAL_STORE_EMAIL,
        officialStoreEmail: OFFICIAL_STORE_EMAIL,
        _replyto: recipientEmail || OFFICIAL_STORE_EMAIL,
        _subject: `🥛 Uni Milk Hathras Order: ${subject}`,
        message: message,
        customerEmail: recipientEmail,
        storeLocation: 'Hathras City, Uttar Pradesh',
        sentAt: new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }),
        ...details,
      }),
    });

    if (response.ok) {
      console.log('✅ Formspree Email dispatched successfully to:', OFFICIAL_STORE_EMAIL);
      return true;
    } else {
      console.warn('Formspree returned status:', response.status);
    }
  } catch (error) {
    console.error('Failed to send Formspree email:', error);
  }
  return false;
};

export const sendPushNotification = (
  title: string,
  options?: {
    body?: string;
    icon?: string;
    badge?: string;
    tag?: string;
    data?: any;
  }
) => {
  // Always trigger in-app custom event for UI toast backup
  if (typeof window !== 'undefined') {
    const event = new CustomEvent('uni-milk-toast', {
      detail: {
        title,
        body: options?.body || '',
        timestamp: new Date().toISOString(),
      },
    });
    window.dispatchEvent(event);
  }

  // Native Browser Push Notification
  if (checkNotificationSupport() && Notification.permission === 'granted') {
    try {
      const notification = new Notification(title, {
        body: options?.body || '',
        icon: options?.icon || 'https://images.unsplash.com/photo-1550583724-b2692b85b150?auto=format&fit=crop&w=200&q=80',
        badge: options?.badge || 'https://images.unsplash.com/photo-1550583724-b2692b85b150?auto=format&fit=crop&w=200&q=80',
        tag: options?.tag || 'order-status',
        vibrate: [200, 100, 200],
      } as any);

      notification.onclick = () => {
        window.focus();
        notification.close();
      };
    } catch (e) {
      console.warn('Native notification creation failed, fallback toast used.', e);
    }
  }
};

export const notifyOrderStatusChange = (
  orderId: string,
  status: string,
  estimatedTime?: string,
  recipientEmail: string = DEFAULT_RECIPIENT_EMAIL
) => {
  let body = `Your order #${orderId} status is now: ${status}.`;
  if (status === 'Order Placed') {
    body = `Order #${orderId} received! Preparing fresh dairy items for delivery.`;
  } else if (status === 'Quality Checked & Packed') {
    body = `Order #${orderId} quality checked and packed in thermal insulated seals.`;
  } else if (status === 'Out for Delivery') {
    body = `🚚 Order #${orderId} is out for delivery in Hathras! Agent Ramesh is on the way. ${estimatedTime ? `ETA: ${estimatedTime}` : ''}`;
  } else if (status === 'Delivered') {
    body = `🎉 Order #${orderId} delivered successfully! Enjoy fresh Uni Milk dairy.`;
  }

  // 1. Send Push / In-App Toast Notification
  sendPushNotification(`🥛 Uni Milk Update: ${status}`, {
    body,
    tag: `order-${orderId}`,
  });

  // 2. Dispatch Formspree Email Notification
  sendEmailNotification(
    `Order #${orderId} Status Update: ${status}`,
    body,
    recipientEmail,
    { orderId, status, estimatedTime }
  );
};
